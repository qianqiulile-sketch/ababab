# 灵犀 Dia — 本地构建与部署指南

## 项目简介
Dia 是基于 Google LiteRT-LM 的本地 AI 助手 Android 应用，支持：
- ✅ **GPU 加速**（自动 GPU→CPU 降级）
- ✅ **图像理解**（Lens Live 摄像头 + AI）
- ✅ **多轮思考**（Gemma 4 thinking mode）
- ✅ **模型自由切换**（.litertlm 文件扫描）
- ✅ **语音输入/输出**
- ✅ **手机控制 Pilot**（无障碍服务）

## 推荐模型
`gemma-4-E4B-it-gpu.litertlm` — 本项目针对此模型优化

---

## 构建环境要求

| 工具 | 版本 | 下载 |
|------|------|------|
| Android Studio | Meerkat 2024.3+ | https://developer.android.com/studio |
| JDK | 17（Studio 自带） | Studio 内置 |
| Android SDK | API 36 | SDK Manager |
| Gradle | 9.1.0（自动下载） | 无需手动 |
| 手机系统 | Android 8.0+ (API 26) | — |

---

## 方法 A：Android Studio（推荐）

1. 打开 Android Studio
2. `File → Open` → 选择本目录
3. 等待 Gradle 同步（首次约 5 分钟）
4. 点击 ▶ **Run** 按钮直接安装到手机

---

## 方法 B：命令行

### macOS / Linux
```bash
cd dia-main
bash build_app.sh
# APK 输出：app/build/outputs/apk/debug/app-debug.apk
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

### Windows
```cmd
cd dia-main
build_app.bat
adb install -r app\build\outputs\apk\debug\app-debug.apk
```

---

## 模型部署

### 方式 1：脚本推送（推荐）
```bash
# 将 gemma-4-E4B-it-gpu.litertlm 放在同目录下
bash deploy_model.sh

# 或指定完整路径
bash deploy_model.sh /path/to/gemma-4-E4B-it-gpu.litertlm
```

### 方式 2：手动复制
用数据线或 Android 文件传输工具，将模型文件复制到手机任一位置：
- `/sdcard/Download/`
- `/sdcard/Models/`
- `/sdcard/litertlm/`

---

## 首次启动

1. 安装 APK 后打开「灵犀 Dia」，完成权限引导（可跳过）
2. 直接进入对话页 → 点顶部标题选择模型（或「导入模型」）
3. 等待加载完成（首次 GPU 初始化约 10–60 秒），状态点变绿即可对话
4. 输入框左侧 ＋ 打开百宝箱，或输入 `/帮助` 查看命令

## 权限说明

| 权限 | 用途 |
|------|------|
| 摄像头 | 拍照发送、实时镜头 |
| 麦克风 | 语音消息 |
| 无障碍服务 | 操控手机、屏幕引导、悬浮气泡框选 |
| 悬浮窗 | 悬浮气泡、屏幕引导 |
| 所有文件访问（可选） | 让 AI 浏览手机目录；不开也可以用「文件」按钮选择文件 |

## 常见问题

**Q: GPU 加载失败？** 引擎会自动降级到 CPU；也可在 选择模型 面板里手动切换。
**Q: 回答被截断 / 提示上下文不够？** 设置 → 本地模型 → 上下文长度调到 8K，重新加载模型。
**Q: 生图失败？** 设置 → 生图 AI 换一种方式（在线 Pollinations / OpenAI 兼容接口 / 局域网 SD WebUI / 本机）。
**Q: 不想自己配环境？** 用 GitHub 自动打包，见 `GITHUB_打包说明.md`。
