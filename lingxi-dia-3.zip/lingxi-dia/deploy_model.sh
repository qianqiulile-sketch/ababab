#!/bin/bash
# ============================================================
# Dia AI - 模型部署脚本
# 将 gemma-4-E4B-it-gpu.litertlm 推送到 Android 设备
# ============================================================

MODEL_FILE="${1:-gemma-4-E4B-it-gpu.litertlm}"
TARGET_DIR="/sdcard/Download"

echo "=========================================="
echo "   Dia AI - 模型部署脚本"
echo "=========================================="
echo ""

# 检查 adb
if ! command -v adb &>/dev/null; then
    echo "❌ 未找到 adb，请安装 Android Platform Tools"
    echo "   下载: https://developer.android.com/tools/releases/platform-tools"
    exit 1
fi

# 检查设备连接
DEVICE=$(adb devices | grep -v "List" | grep "device$" | head -1 | cut -f1)
if [ -z "$DEVICE" ]; then
    echo "❌ 未检测到 Android 设备"
    echo "   请确保:"
    echo "   1. 手机已通过 USB 连接"
    echo "   2. 已开启 USB 调试模式"
    exit 1
fi
echo "✅ 设备: $DEVICE"

# 检查模型文件
if [ ! -f "$MODEL_FILE" ]; then
    echo "❌ 模型文件不存在: $MODEL_FILE"
    echo ""
    echo "请将 gemma-4-E4B-it-gpu.litertlm 放在与本脚本相同的目录"
    echo "或执行: bash deploy_model.sh /path/to/your/model.litertlm"
    exit 1
fi

MODEL_SIZE=$(du -sh "$MODEL_FILE" | cut -f1)
echo "📦 模型: $MODEL_FILE ($MODEL_SIZE)"
echo ""
echo "正在推送到设备 $TARGET_DIR/ ..."
echo "（大文件可能需要几分钟）"
echo ""

# 推送文件
adb push "$MODEL_FILE" "$TARGET_DIR/"
if [ $? -eq 0 ]; then
    echo ""
    echo "=========================================="
    echo "  ✅ 模型部署成功!"
    echo "  设备路径: $TARGET_DIR/$(basename $MODEL_FILE)"
    echo "=========================================="
    echo ""
    echo "在 Dia app 中:"
    echo "  1. 打开 Chat 页面"
    echo "  2. 点击底部模型选择器"
    echo "  3. 选择 gemma-4-E4B-it-gpu"
    echo "  4. 等待 GPU 初始化完成"
else
    echo "❌ 推送失败"
    exit 1
fi
