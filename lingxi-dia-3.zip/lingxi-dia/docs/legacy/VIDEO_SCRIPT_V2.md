# Dia — Demo Video Script (V2)
## Gemma 4 Good Hackathon · 3 to 4 minutes · Read-aloud narration

---

> **How to use this:** Just read the lines under **[NARRATE]**. Everything in `< >` brackets is what plays on screen at that moment. Pause for half a beat between sections — let the visuals breathe.
>
> **Tone:** Calm. Honest. A little vulnerable at the start, then confident and warm. Like you're talking to one person, not a crowd.

---

## SCENE 1 — THE HOOK
### (0:00–0:35) · slow, sincere

`<Black screen. Soft ambient music starts. Slow text fade-ins, one line at a time.>`

**[NARRATE]**

> So many people don't have access to the internet.

`<Stock footage: a remote village, a kid holding a phone with no signal bars.>`

> There are outages.
> There are remote areas.
> There are entire regions where, in this world of AI…
> AI just isn't available.

`<Stock footage: an elderly woman squinting at a phone screen, looking confused.>`

> And then there are the people right next to us.
> Grandma, who can't figure out how to video call her grandkids.
> A first-time smartphone user, who's afraid to tap the wrong thing.

`<Quick cut: a phone screen flashing "No internet connection".>`

> And honestly?
> Even people like you and me need our phones to work…
> when the signal drops.
> When we're travelling. When something goes wrong.

`<Pause. Black screen.>`

> *(softer)*
> So I tried to fix all of that.

---

## SCENE 2 — INTRODUCING DIA
### (0:35–0:55) · proud, warm

`<Logo reveal: the Dia "D" mark fades in over deep navy. Then transitions to the home screen with the mascot greeting.>`

**[NARRATE]**

> This is Dia.
> An offline-first AI companion.
> Powered by Gemma 4 from Google — running entirely on your phone.
> No cloud. No account. No data leaving your device.

`<Show Settings → "✓ Gemma 4 loaded · Local only" badge. Then airplane mode icon visible in the status bar.>`

> Eight ways to use it. One offline brain. Zero internet required.

---

## SCENE 3 — CHAT
### (0:55–1:20) · casual

`<Chat mode screen recording — type a question, Gemma responds. Quick cut to thinking mode toggle showing reasoning. Quick cut to audio scribe / voice input.>`

**[NARRATE]**

> You can chat with it.
> *(small pause)*
> Ask anything. Brainstorm. Vent. Plan your week.

`<Cut to: thinking mode visible, Gemma's reasoning unfolding.>`

> Watch it think out loud, if you want to.

`<Cut to: voice input — mic animation, then transcribed text appearing.>`

> Or just talk. Dia listens.

---

## SCENE 4 — LENS LIVE
### (1:20–2:00) · curious, demonstrative

`<Live Lens — Watch mode. Camera pointed at a desk. Bounding boxes appearing around objects with labels.>`

**[NARRATE]**

> You can show it things.

`<Cut to: Lens Live Question mode — point at a math problem on paper, ask "solve this".>`

> It solves things for you.

`<Cut to: Live Translate mode — camera on foreign-language text, English captions appearing live.>`

> It translates the world around you, in real time.

`<Cut to: Live Lens Guide mode — point at a complex appliance, say "where's the power button?", a yellow highlight appears on the actual button.>`

> And it guides you — physically pointing at exactly what you're looking for.

---

## SCENE 5 — BUBBLE
### (2:00–2:25) · matter-of-fact

`<Floating Dia bubble drifting over a news article on screen. Tap the bubble.>`

**[NARRATE]**

> And what about everywhere else? Every other app on your phone?

`<Bubble mode menu opens — "Ask about screen", "Summarise", "Translate".>`

> Dia floats over them too.

`<Quick cuts: bubble summarising a long article, bubble translating a foreign WhatsApp message, bubble answering a question about a screenshot.>`

> Ask a question about whatever's on screen.
> Summarise a long article.
> Translate any app, instantly.
> *(small pause)*
> All of it, offline.

---

## SCENE 6 — GUIDE
### (2:25–2:55) · emotional reset

`<Stock footage: an elderly person holding a phone with their family on the other end of a failed video call. They look frustrated.>`

**[NARRATE]**

> *(softer, slower)*
> But what if you don't even know which button to tap?
> What if every app feels like a maze?

`<Cut to: Dia home screen → tap Guide mode → user says "Help me video call my daughter on WhatsApp".>`

> You can ask Dia to guide you.

`<Guide overlay appearing over WhatsApp — yellow highlight on the call button, finger pointer pulsing, big text caption: "Tap the green call button". Step advances automatically.>`

> Step by step. Pointing at the screen, with a real finger that follows you through.
> Big text. High contrast. Voice instructions.
> Built for the people technology forgot.

---

## SCENE 7 — PILOT
### (2:55–3:20) · confident, magical

`<Pilot mode screen recording. User says: "Order biryani on Swiggy" or "Message Lakshya I'll be 10 minutes late". Watch Dia open the app, type, navigate, send — autonomously.>`

**[NARRATE]**

> Or, if you don't want to do it at all…
> Dia can do it for you.

`<Pilot animations playing. Show the action log — "Searching… Adding to cart… Confirming order…">`

> Pilot mode. Tell it what to do, in plain language.
> It drives the apps for you.

`<Subtitle on screen: "Switches to Gemma cloud automatically for complex tasks">`

> And when a task gets complex — ordering food, booking something —
> it seamlessly switches to a bigger Gemma model in the cloud.
> Local for speed and privacy. Cloud only when it's needed.

---

## SCENE 8 — SLATE
### (3:20–3:45) · light, playful

`<Cut to: a child's hand or just a stylus drawing on the Slate notebook screen. A messy "2x + 4 = 10" appears.>`

**[NARRATE]**

> *(brighter tone)*
> And it's not just for adults.

`<Tap "Read with Gemma 4" button. Dia narrates the equation back.>`

> Slate mode.
> Write on the whiteboard, and Dia writes back.

`<Cut to: solving a longer math problem — Dia explains the steps.>`

> Solve equations. Get explanations.

`<Cut to: Quiz mode — Dia asks a question, user scribbles an answer, Dia evaluates the handwriting.>`

> There's even a quiz mode that grades your handwritten answers.
> *(small pause)*
> A patient tutor that fits in your pocket.

---

## SCENE 9 — HOME
### (3:45–4:00) · calm, capable

`<Home Mode screen. Entity tiles for lights, thermostat, locks. User speaks: "Dia, turn off the bedroom light".>`

**[NARRATE]**

> Dia even runs your home.

`<The tile updates. The light icon dims. Confirmation TTS.>`

> Connect to your local Home Assistant, and Dia controls everything —
> lights, thermostats, locks — with your voice.
> No Alexa. No Google Home. No data leaving your house.

---

## SCENE 10 — THE CLOSE
### (4:00–4:20) · slow, sincere

`<Slow zoom out on the phone. Then logo. Then text fades.>`

**[NARRATE]**

> *(slow, quieter again)*
> Dia isn't built for power users.
> It's built for the people technology forgot.

`<Text card: "1.7 billion people have never used a smartphone.">`

> The grandmother who just wants to see her grandchildren.

`<Text card: "Built for offline. Built for everyone.">`

> The student who has no WiFi at home.
> The traveller, the farmer, the first-timer.
> *(pause)*
> And honestly, all of us — when the internet goes down.

`<Final logo card with tagline.>`

> **Dia.**
> *Offline AI for everyone.*
> *Built with Gemma 4 + LiteRT-LM.*

`<Music swells, then fades to silence.>`

---

## TIMING SUMMARY

| Section | Time | Cumulative |
|---|---|---|
| Hook | 0:35 | 0:35 |
| Introducing Dia | 0:20 | 0:55 |
| Chat | 0:25 | 1:20 |
| Lens Live (4 modes) | 0:40 | 2:00 |
| Bubble | 0:25 | 2:25 |
| Guide | 0:30 | 2:55 |
| Pilot | 0:25 | 3:20 |
| Slate | 0:25 | 3:45 |
| Home | 0:15 | 4:00 |
| Close | 0:20 | **4:20** |

> Tighten the Hook to 25s and Lens to 35s if you want to land closer to **3:45**.

---

## VOICEOVER TIPS

- **Pace:** Aim for ~140 words per minute. Natural conversation speed. Don't rush the hook or the close — those are the emotional anchors.
- **Mic:** Even a phone mic in a quiet, carpeted room beats a fancy mic in a tiled bathroom. Cover your phone with a sock if you have nothing else.
- **Breath:** Take a real breath between sections. Cut the pauses out in editing. It sounds way more confident than reading non-stop.
- **Two-pass record:** Record the whole script once cold, then again after watching it back. Your second take is always better.
- **Where to whisper-soft:** "So I tried to fix all of that." · "But what if you don't even know which button to tap?" · "Dia isn't built for power users."
- **Where to lift:** "This is Dia." · "Eight ways to use it. One offline brain." · "Dia. Offline AI for everyone."

---

## STOCK FOOTAGE TO GRAB (free sources)

- Pexels.com / Pixabay.com — search:
  - *"elderly woman phone confused"*
  - *"rural village no internet"*
  - *"no signal bars"*
  - *"video call frustrated grandparent"*
  - *"hand holding phone closeup"*

Avoid anything that feels staged or overly polished — judges can spot a stock video instantly. Subtle, real-feeling clips win.
