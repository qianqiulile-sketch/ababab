# REFERENCES.md

Every project we studied while building Dia. What they are, what they got right, what their limits are, and what we actually took.

---

## PokeClaw
**Repo:** https://github.com/agents-io/PokeClaw  
**Site:** https://agents-io.github.io/PokeClaw/  
**What it is:** The first open-source Android app that runs Gemma 4 entirely on-device via LiteRT-LM and controls the phone through Android Accessibility. Built solo in two all-nighters right after Gemma 4 dropped.

### What it is in one line
Give a local LLM a set of tools (tap, swipe, type, open app, send message, auto-reply) and let it decide what to do. The model sees a text representation of the current screen, picks an action, sees the result, picks the next action, until done.

### What they nailed
- First working proof that a local LLM can autonomously control an Android phone with no cloud
- Clean tool system: `tap`, `swipe`, `input_text`, `open_app`, `send_message`, `auto_reply`, `get_screen_info`, `take_screenshot`, `finish`
- Auto-reply is genuinely impressive — monitors a contact, reads conversation context, generates a reply, sends it
- 3-tier pipeline: simple commands hit zero LLM, known skills run deterministic sequences, only complex tasks hit the full agent loop. This is how you get reliable automation from a small model.
- Skills system: reusable workflows built from generic tools. Skills are the recipes. Tools are the building blocks. Exactly the model Dia follows.
- Honest about hardware: CPU-only warmup is ~45s. GPU/NPU drops it to seconds. Same model, better hardware.
- Optional cloud fallback (OpenAI-compatible) for tasks the local model can't handle
- 411 GitHub stars and 55 forks in the first 4 days

### Limitations
- Standalone app — no voice, no vision, no guide overlay, no canvas
- No persistent memory — each session starts cold
- Single active mode — no feature ecosystem
- No cross-device story

### What Dia takes from PokeClaw
- The entire tools + skills architecture (the conceptual model, not the code)
- The 3-tier pipeline idea: trivial → skill → full agent loop
- The accessibility-tree-based automation approach (not pixel-based)
- The honest cold-start handling
- The optional cloud fallback pattern

---

## Parlor
**Repo:** https://github.com/fikrikarim/parlor  
**What it is:** On-device, real-time multimodal AI. Voice + vision conversation that runs entirely locally. Python FastAPI server, built for Apple Silicon and Linux.

### What it is in one line
Talk to your laptop, show it your camera, it talks back. All local. Gemma 4 E2B for understanding, Kokoro for voice.

### Architecture
```
Browser (mic + camera)
  ↓ WebSocket (audio PCM + JPEG frames)
FastAPI server
  ├── Gemma 4 E2B via LiteRT-LM (GPU) → understands speech + vision
  └── Kokoro TTS (MLX on Mac, ONNX on Linux) → speaks back
  ↓ WebSocket (streamed audio chunks)
Browser (playback + transcript)
```

### What they nailed
- End-to-end proof: Silero VAD → Gemma 4 audio → Kokoro TTS, all offline
- Barge-in — you can interrupt the AI mid-sentence, no push-to-talk needed
- Sentence-level TTS streaming — audio starts before full response is generated. Critical for perceived latency.
- The whole thing is a FastAPI server + browser client — dead simple architecture
- Author built it to keep his English teaching server free after running up big API bills

### Limitations
- Mac/Linux only. No Android.
- Server-side Python — not a mobile app
- No tools, no actions — pure conversation
- No persistent memory
- No ambient mode — active sessions only
- 30s audio clip limit (Gemma model constraint)

### What Dia takes from Parlor
- The full voice pipeline: Silero VAD → Gemma 4 audio encoder → Kokoro TTS
- Sentence-level TTS streaming (start speaking before full response is done)
- Barge-in interaction model
- The proof that Kokoro ONNX works for offline TTS

### The Android adaptation
Parlor runs Python server-side. Dia runs this natively in Kotlin:
- Silero VAD → ONNX on-device (WebRTC VAD as fallback)
- Gemma 4 E2B audio → LiteRT inference
- Kokoro TTS → ONNX on Android (thewh1teagle/kokoro-onnx as reference)
- No server. No HTTP. In-process pipeline.

---

## Kokoro TTS
**Repo:** https://github.com/hexgrad/kokoro  
**HuggingFace:** https://huggingface.co/hexgrad/Kokoro-82M  
**ONNX export (for Android):** https://github.com/thewh1teagle/kokoro-onnx  
**Android TTS reference:** https://github.com/siva-sub/NekoSpeak  
**What it is:** Open-weight TTS model, 82M parameters. Apache licensed. Comparable quality to much larger models.

### Why Dia uses it
- 82M params — fits on any Android device
- Apache 2.0 — no restrictions
- ONNX export available — runs on Android via ONNX Runtime
- Sentence-level streaming possible — critical for voice latency
- ~$0.80 per million characters if served via API. For Dia: $0 because it's on-device.

### Android path
`kokoro-onnx` (thewh1teagle) exports `kokoro-v1.0.onnx` + `voices-v1.0.bin`. These run via ONNX Runtime on Android. NekoSpeak (siva-sub) is a working Android TTS app using Kokoro — good architecture reference for the Android integration.

---

## Clicky
**Repo (macOS original):** https://github.com/farzaa/clicky  
**Repo (Windows port):** https://github.com/tekram/clicky-windows  
**Repo (clicky-sdk, Android concept):** https://github.com/Rishabjs03/clicky-sdk  
**What it is:** An AI teacher that lives as a buddy next to your cursor on macOS. Sees your screen, hears your voice, talks back, and points at exact UI elements.

### What it is in one line
Push a hotkey, ask a question, AI sees your screen and responds while animating a blue cursor to the exact button you need to press.

### Architecture
```
Menu bar app (macOS, Swift)
Push-to-talk (ctrl+option) → AssemblyAI streaming STT
Screenshot of all monitors → Claude (via Cloudflare Worker proxy)
Claude response with [POINT:x,y:label:screenN] tags → ElevenLabs TTS + cursor animation
Transparent NSPanel overlay → cursor flies to target via bezier arc
```

### What they nailed
- The cursor animation flying to a UI element is genuinely magical UX. The best idea in this category.
- Screen-aware AI — sees what you're looking at, not just what you typed
- Non-activating overlay (`FLAG_NOT_FOCUSABLE` equivalent) — doesn't steal focus, feels like a companion not a popup
- `[POINT:x,y:label:screenN]` token format in model response triggers cursor movement — elegant design
- Multi-monitor coordinate mapping
- The metaphor: "AI teacher that lives next to your cursor" — perfect

### Limitations (why Dia's Guide is different)
- Cloud-dependent: AssemblyAI + Claude API + ElevenLabs. All paid. All external.
- macOS/Windows only
- Cursor points at coordinates — not actual UI nodes. Fragile if UI shifts.
- No persistent memory, no tool use

### CursorBuddy Android
`jasonkneen/cursorbuddy-android` — Android concept port showing `TYPE_APPLICATION_OVERLAY` floating cursor. Proof the overlay mechanism works on Android. No AI integration — just the cursor layer.

### What Dia Guide takes from Clicky
- The overlay cursor UX concept
- The "cursor flies to answer" interaction pattern
- The non-activating overlay (touches pass through)

**Key difference in Dia Guide:** instead of pixel coordinates, Dia uses `AccessibilityNodeInfo`. Dia finds the actual view node, then animates the cursor to `node.getBoundsInScreen()`. No coordinates in model output. More reliable — doesn't break when screen layout shifts.

**Second key difference:** fully offline. No AssemblyAI. No ElevenLabs. No Claude API. Gemma 4 E2B locally.

---

## GemmaForge (Previous Project — Reference Only)

Your own previous build. Listed here for context on what not to repeat.

### What was actually working
- LiteRT-LM integration on Android
- Tool system concept (18+ tools)
- Room DB for memory
- Ink Notes canvas concept
- Basic floating overlay

### What was broken or fake
- Most "AI features" were just Android API wrappers with no Gemma involvement
- No coherent feature isolation — features conflicted
- No voice pipeline
- No proper skills system
- No design language
- Accessibility tree was reading GemmaForge's own UI instead of the foreground app (the big bug)
- Tool count too high — model got confused

### What Dia does differently
- Every feature is audited: "is Gemma doing real work here?"
- Strict feature isolation (one active at a time)
- Tools + Skills architecture borrowed from PokeClaw
- Voice pipeline borrowed from Parlor
- Guide cursor borrowed from Clicky
- Smaller tool count per active skill

---

## OpenClaw / openclaw-community
**Hub:** https://github.com/openclaw-community/openclaw-hub  
**What it is:** The broader community ecosystem around AI phone/desktop agents. PokeClaw was directly inspired by OpenClaw. Good place to track what the community is building on the same stack.

Relevant discussion: PokeClaw's author posted there explaining the Android-native approach vs PC/ADB/cloud alternatives — the philosophical argument for why on-device + accessibility tree beats screenshot-based + Python + ADB.

---

## LiteRT-LM
**Docs:** https://ai.google.dev/edge/litert/llm/overview  
**Model:** https://huggingface.co/litert-community/gemma-4-E2B-it-litert-lm  
**What it is:** Google's on-device LLM inference SDK for Android (formerly TensorFlow Lite). Dia's entire inference stack runs on this.

Key things worth knowing:
- Native tool calling support — models output structured JSON, SDK handles parsing
- GPU delegate available on Snapdragon 8 Gen 2+, Tensor G3/G4, Dimensity 9200+
- CPU fallback works everywhere — just slower
- `.litertlm` format — quantized model file (INT4, ~2.6GB for E2B)
- Session stays warm between requests — don't recreate per inference call
