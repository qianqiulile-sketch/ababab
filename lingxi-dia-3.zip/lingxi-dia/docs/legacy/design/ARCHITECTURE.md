# ARCHITECTURE.md

How Dia works under the hood.

---

## The Stack

```
User
 │
 ▼
Feature (one active at a time)
 │  loads
 ▼
Skills (relevant .md files injected into context)
 │  describes how to use
 ▼
Tools (function calls Gemma can invoke)
 │  executes via
 ▼
Android APIs / LiteRT-LM / Hardware
```

---

## Inference Engine

LiteRT-LM handles all on-device inference.

**Model:** `litert-community/gemma-4-E2B-it-litert-lm`  
**Format:** `.litertlm`  
**Quantization:** INT4  
**RAM:** ~2GB active  
**Backend:** GPU delegate (falls back to CPU automatically)

Session init:
```kotlin
val options = LlmInference.LlmInferenceOptions.builder()
    .setModelPath(modelPath)
    .setMaxTokens(2048)
    .setPreferredBackend(Backend.GPU)
    .build()

val llm = LlmInference.createFromOptions(context, options)
```

One session stays warm at all times. Cold start: ~5-10s GPU, ~45s CPU.

---

## Feature Isolation

One feature active at any time. Switching = full teardown then fresh load.

```kotlin
object FeatureManager {
    var active: Feature = Feature.NONE

    fun switchTo(next: Feature) {
        active.teardown()   // release mic, camera, overlay, accessibility
        next.load()         // load skills, acquire resources
        active = next
    }
}

enum class Feature { NONE, CHAT, VOICE, LENS, GUIDE, PILOT, SLATE, DRIVE }
```

No shared resources between features. No exceptions right now.

---

## Tools → Skills → Features mapping

### Tools (primitives)

These are the raw function calls available to Gemma via native tool calling.

**Action tools**
```
tap(x, y)
swipe(x1, y1, x2, y2)
long_press(x, y)
input_text(text)
open_app(name)
send_message(contact, message)
make_call(contact)
scroll(direction)
go_back()
go_home()
finish()
```

**Perception tools**
```
get_screen_info()         → returns UI tree as text
take_screenshot()         → captures current screen
ask_camera(question)      → frame + question → Gemma vision → answer
read_document(image)      → OCR + understanding on captured image
transcribe_audio(clip)    → Gemma audio encoder on voice clip
describe_scene()          → Gemma narrates what camera sees
```

**System tools**
```
set_alarm(time, label)
create_reminder(text, time)
get_battery_status()
get_notifications()
save_memory(key, value)
recall_memory(key)
move_guide_cursor(nodeId)
speak(text)
```

---

### Skills (md files loaded per feature)

Skills are plain text `.md` files injected into the system prompt. They tell Gemma how to behave and which tools to use for a specific context.

**Format:**
```
# skill-name.md

## Goal
What this skill is for.

## Available Tools
List of tools this skill uses.

## Behavior
Step by step instructions for the model.

## Constraints
What not to do.
```

**Example — `automation-loop.md` (used by Pilot):**
```markdown
# automation-loop.md

## Goal
Complete a multi-step phone task given by the user.

## Available Tools
get_screen_info, tap, swipe, input_text, open_app,
send_message, scroll, go_back, go_home, take_screenshot, finish

## Behavior
1. Call get_screen_info to understand the current screen
2. Decide the next single action toward the goal
3. Execute it
4. Call get_screen_info again to see the result
5. Repeat until task is complete
6. Call finish when done

## Constraints
- Max 15 steps before calling finish with a failure summary
- Never tap on payment or banking UI
- If stuck on the same screen twice, try go_back and rethink
- Never guess a contact number — use search
```

---

### Feature → Skills loaded

| Feature | Skills loaded |
|---|---|
| Chat | `memory.md`, `tool-use.md` |
| Voice | `voice-conversation.md`, `memory.md` |
| Lens | `vision-query.md`, `ocr.md` |
| Guide | `read-ui-tree.md`, `cursor-guidance.md` |
| Pilot | `automation-loop.md`, `messaging-flow.md`, `app-navigation.md` |
| Slate | `ink-understanding.md`, `math-solver.md` |
| Drive | `dashcam-monitor.md` |

No cross-loading. Pilot never loads `ocr.md`. Lens never loads `automation-loop.md`.

---

## Voice Pipeline (Voice feature)

```
Mic
 ↓
Silero VAD (ONNX, CPU, ~1MB)
 ↓ speech detected
Audio buffer (30s max)
 ↓
Gemma 4 E2B audio encoder (USM conformer via LiteRT)
 ↓
Text → Gemma generates response
 ↓
Kokoro TTS (82M, ONNX, offline)
 ↓ sentence-level streaming
Speaker
```

Barge-in: VAD runs continuously even during playback. New speech → stop TTS → process.

---

## Vision Pipeline (Lens feature)

```
Camera frame (CameraX)
 ↓
Token budget selection:
  70   → quick classify
  280  → general describe
  560  → detailed analysis
  1120 → OCR / fine text
 ↓
frame + question → Gemma 4 vision (LiteRT)
 ↓
Response (text + optional speak)
```

Not real-time. Capture → process → respond. One frame per query.

---

## Automation Pipeline (Pilot feature)

```
User goal (text or voice)
 ↓
Planner: Gemma 4 with thinking mode
 ↓
Tool call → AccessibilityService executes
 ↓
get_screen_info → new UI state
 ↓
loop (max 15 steps)
 ↓
finish()
```

**Thinking mode gotcha:** in multi-turn Pilot sessions, thinking tokens from previous turns must NOT be included in conversation history. Only the final answer goes back. Including thinking in history breaks the loop.

```kotlin
// correct
history.add(Message(role = "assistant", content = response.finalAnswer))

// wrong — breaks multi-turn
history.add(Message(role = "assistant", content = response.fullOutputWithThinking))
```

---

## Guide Overlay

```
FloatingService
 ↓
WindowManager.addView(cursorView, TYPE_APPLICATION_OVERLAY)
  flags: FLAG_NOT_FOCUSABLE | FLAG_NOT_TOUCH_MODAL | FLAG_LAYOUT_IN_SCREEN
 ↓
User asks question
 ↓
Gemma reads get_screen_info() → identifies target node description
 ↓
AccessibilityService.findNode(description) → returns bounds
 ↓
Cursor animates to node.getBoundsInScreen()
 ↓
Dia speaks the instruction
```

Cursor is a `Canvas`-drawn view. Transparent to touch — all taps pass through.

---

## Memory System

Structured key-value store in Room DB. No vector search. No embedding model.

```kotlin
@Entity
data class Memory(
    @PrimaryKey val key: String,
    val value: String,
    val category: String,
    val updatedAt: Long
)
```

At session start, top memories are compiled into a short profile block (~200 tokens) and injected into the system prompt. Gemma calls `save_memory` and `recall_memory` as needed.

---

## Cloud Inference (optional)

When cloud mode is on, Dia replaces the LiteRT call with an HTTP request to the configured provider.

All providers use OpenAI-compatible format:
```kotlin
data class CloudConfig(
    val provider: String,       // "openai", "gemini", "groq", "ollama", "custom"
    val baseUrl: String,
    val apiKey: String?,        // null for local Ollama
    val modelId: String
)
```

Stored in Android `EncryptedSharedPreferences`. Never in plaintext.

**Ollama LAN:** baseUrl = `http://192.168.x.x:11434/v1` — lets the phone offload to a bigger model (26B MoE) running on your laptop over local network. Zero cloud, zero cost.

**Ollama Cloud:** baseUrl = `https://ollama.com/v1` — needs an ollama.com API key. Tool calling reliability may vary — warn user.

---

## Smart Routing (E2B ↔ E4B)

Only relevant once E4B is installed as optional download.

```kotlin
fun route(feature: Feature, battery: Int, thermal: ThermalState): ModelSize {
    if (battery < 20 || thermal == CRITICAL) return E2B
    return when (feature) {
        VOICE, GUIDE, CHAT -> E2B
        LENS, PILOT, SLATE -> E4B
        else -> E2B
    }
}
```

---

## Known Hard Problems

| Problem | Notes |
|---|---|
| OEM service killing | Samsung/Xiaomi kill background services. Need foreground service + notification. |
| Accessibility on secure screens | Banking apps block overlay + tree reading. Detect and inform user gracefully. |
| Thinking mode in multi-turn | Thinking tokens must not re-enter history. Silent failure if you get this wrong. |
| Kokoro on names/technical terms | 82M TTS stumbles on proper nouns sometimes. Acceptable tradeoff. |
| Pilot hallucinating tool params | Validator layer needed — check tool output before execution, fail safe. |
| Cold start UX | 45s on CPU feels broken. Need a loading state that feels intentional, not stuck. |
