# HACKATHON.md

Everything about the Gemma 4 Good Hackathon. The context, the prizes, the strategy.

---

## The Hackathon

**Gemma 4 Good** — hosted by Kaggle × Google DeepMind  
**Prize pool:** $200,000  
**Deadline:** May 18, 2026  
**Link:** kaggle.com/competitions/gemma-4-good

---

## Scoring Breakdown

| Criteria | Weight |
|---|---|
| Impact + Vision | 40% |
| Video Pitch | 30% |
| Technical Depth | 30% |

Impact outweighs code. The video is not a demo — it's the product. Previous winners made short films with emotional narratives. Judges evaluate whether the video makes them feel something. The writeup just verifies the code is real.

---

## Prizes

### Main Track — $100,000
| Place | Prize |
|---|---|
| 1st | $50,000 |
| 2nd | $25,000 |
| 3rd | $15,000 |
| 4th | $10,000 |

Best overall projects. Judged on all three criteria. Emphasis on real-world demo and wow factor. A project can win Main Track AND a special prize simultaneously.

---

### Impact Track — $50,000 ($10k each)

| Category | Focus |
|---|---|
| Health & Sciences | Bridge humans and data, accelerate discovery |
| Global Resilience | Offline edge, disaster response, climate |
| Future of Education | Multi-tool agents, adaptive learning |
| Digital Equity & Inclusivity | Linguistic diversity, AI skills gap |
| Safety & Trust | Transparency, reliability, explainability |

**Dia's strongest angle:** Digital Equity + Future of Education. Offline-first, 140+ languages, Guide for elderly/accessibility, Slate for classrooms with no internet.

---

### Special Tech Track — $50,000 ($10k each)

| Prize | What it rewards |
|---|---|
| **Cactus** | Best local-first mobile/wearable that intelligently routes tasks between model sizes (E2B ↔ E4B) |
| **LiteRT** | Most compelling use case built on Google AI Edge's LiteRT-LM |
| **llama.cpp** | Best on resource-constrained hardware |
| **Ollama** | Best project using Gemma 4 locally via Ollama |
| **Unsloth** | Best fine-tuned Gemma 4 using Unsloth for a specific impactful task |

---

## Dia's Prize Targets

| Prize | Why Dia qualifies | What to show |
|---|---|---|
| Main Track | Full ecosystem, real utility, strong story | Guide + Slate + Voice in one coherent demo |
| Cactus | Explicit E2B↔E4B routing per task/battery/thermal | Live routing decision shown in settings debug overlay |
| LiteRT | Entire inference stack on LiteRT-LM, no fallback for core | Show LiteRT session init code + inference stats |
| Digital Equity | Offline, 140+ langs, Guide for elderly, Slate for no-wifi classrooms | Pick one story (elderly / village teacher) and commit |

---

## Gemma 4 — Model Reference

Four sizes:

| Model | Effective Params | Context | Audio | RAM |
|---|---|---|---|---|
| E2B | 2.3B | 128K | ✅ | ~2GB |
| E4B | 4.5B | 128K | ✅ | ~4GB |
| 26B A4B MoE | 3.8B active / 26B total | 256K | ❌ | ~18GB |
| 31B Dense | 31B | 256K | ❌ | ~20GB |

Dia uses E2B (primary) and optionally E4B. 26B MoE is for laptop/desktop mode.

**Key capabilities Dia actually uses:**
- Native function calling (JSON tool use, no prompt hacking)
- Audio encoder — USM-style conformer, max 30s clips, built into E2B/E4B
- Vision — variable token budget (70/140/280/560/1120 tokens)
- Thinking mode — `<|think|>` in system prompt, visible chain-of-thought
- 140+ languages pretrained, 35+ out-of-box
- Native system prompt support (new in Gemma 4)

**Benchmark highlights (31B):**
- AIME 2026: 89.2% (was 20.8% in Gemma 3 — +330%)
- LiveCodeBench: 80.0%
- τ2-bench agentic tool use: 86.4% (was 6.6% — +1200%)
- GPQA Diamond: 84.3%
- Codeforces ELO: 2150

The agentic tool use jump (+1200%) is what makes Pilot and Guide actually viable on a 2B model.

---

## What Won Before (Previous Hackathons)

### Gemma 3n Impact Challenge (Dec 2025, $150k, 600+ submissions)

| Place | Project | What it did |
|---|---|---|
| 1st + AI Edge prize | Gemma Vision | AI for blind users, brother was the user, phone on chest, 8BitDo controller, MediaPipe + LiteRT |
| 2nd | Vite Vere Offline | Cognitive disability companion, image → spoken instructions, offline-first |
| 3rd + Unsloth | 3VA | Fine-tuned for Eva (cerebral palsy), pictograms → rich expressions, Apple MLX |
| Unsloth prize | Dream Assistant | Fine-tuned on user's own audio for speech impairment |
| Ollama prize | LENTERA | Pi broadcasting offline WiFi educational hub |

**Pattern:** real user, specific need, emotional narrative, offline-first. The winner had his blind brother as the actual user. That's why it won.

### Gemma 2 Global Communication (2024)
Winners: Swahili model, Arabic bridge (classical↔modern), Italian anti-hallucination fine-tune, ancient Chinese expert. Pattern: language and cultural adaptation.

---

## The Video Rule

This is the most important thing in the doc.

Previous winners' videos were essentially short films. The judges are not evaluating the code — they're evaluating whether the video makes them feel something. The technical writeup is just proof the code is real.

**Three story options for Dia's video:**

**Option A — The Elder**
Dadi ji got a new phone. Can't find anything. Dia Guide is on. She says "where do I send a photo to my son?" and a cursor appears, pointing at the share button. Dia explains in Hindi. She smiles.

**Option B — The Village Teacher**
Classroom with no internet. Teacher writes equations on Dia Slate. Students ask questions. Dia answers in the margin, in their language. No wifi required. The textbook is alive.

**Option C — The Student**
Competitive exam in 3 hours. No data. Dia Voice quizzes them by voice. Dia Slate lets them write problems and see solutions. Fully offline.

**Recommended: Option A or B.** Option A is more emotionally immediate. Everyone in India has someone like this. Option B is the stronger Digital Equity + Education pitch.

**Whichever you pick: find a real person. Make it real. Don't stage a demo.**

---

## Key Technical Gotchas for the Submission

1. **Thinking mode multi-turn:** Thinking tokens from previous turns must NOT re-enter conversation history. Only the final answer goes back. Silent failure mode in Pilot — will break your demo.

2. **Cactus prize specifically:** Judges want to see the routing decision be explicit and intelligent — battery-aware, complexity-aware, latency-aware. Not just "we use E2B sometimes." Show the decision happening.

3. **LiteRT vs AI Edge Gallery:** Using LiteRT-LM directly in a custom app is more impressive to judges than wrapping AI Edge Gallery. They know the difference.

4. **26B MoE hidden edge:** For the laptop mode, 26B MoE hits 88.3% AIME with only 3.8B active params — nearly same as 31B dense at a fraction of inference cost.

5. **Unsloth fine-tuning:** If pursuing the Unsloth prize — Unsloth is currently the only reliably working Gemma 4 fine-tuning path. They identified and fixed training bugs that affected all frameworks. Most people don't know this.
