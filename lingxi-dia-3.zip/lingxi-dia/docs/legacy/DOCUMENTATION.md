# Dia — Architecture & Feature Deep Dive

This document is the engineering reference for Dia. It covers the architecture, every feature, the on-device LLM engine, and the tradeoffs/OEM quirks we hit along the way.

## Table of Contents

1. [System overview](#system-overview)
2. [The LLM engine — `DiaEngine`](#the-llm-engine--diaengine)
3. [Accessibility service — `DiaAccessibilityService`](#accessibility-service--diaaccessibilityservice)
4. [Navigation & app shell](#navigation--app-shell)
5. [Feature: Chat](#feature-chat)
6. [Feature: Lens](#feature-lens)
7. [Feature: Lens Live (Think / Translate / Guide)](#feature-lens-live)
8. [Feature: Pilot — the autonomous agent](#feature-pilot)
9. [Feature: Guide — interactive on-screen tutor](#feature-guide)
10. [Feature: Slate — infinite handwriting canvas](#feature-slate)
11. [Onboarding, Model Setup, Settings](#onboarding-model-setup-settings)
12. [Cross-cutting concerns](#cross-cutting-concerns)

---

## System overview

Dia is a single Android app, single process, single Activity. Everything is built on Jetpack Compose and Kotlin coroutines.

```
                 ┌────────────────────────────────────────┐
                 │            MainActivity                │
                 │     (single-Activity Compose host)     │
                 └────────────────┬───────────────────────┘
                                  │
                       ┌──────────▼────────────┐
                       │      DiaApp           │
                       │   Navigation3 router  │
                       └──────────┬────────────┘
                                  │
       ┌───────────┬──────────────┼──────────────┬───────────┬──────────┐
       │           │              │              │           │          │
   ┌───▼───┐  ┌────▼────┐    ┌────▼────┐   ┌─────▼────┐ ┌────▼────┐  ...
   │ Chat  │  │  Lens   │    │ Lens    │   │  Pilot   │ │ Guide   │
   │       │  │         │    │ Live    │   │          │ │         │
   └───┬───┘  └────┬────┘    └────┬────┘   └─────┬────┘ └────┬────┘
       │           │              │              │           │
       └───────────┴──────────────┼──────────────┴───────────┘
                                  ▼
                       ┌──────────────────┐
                       │    DiaEngine     │
                       │  (LiteRT-LM)     │
                       └─────────┬────────┘
                                 │
                                 ▼
                          Gemma .task file
```

Cross-cutting services:

```
   DiaAccessibilityService    ←  Pilot taps + types, Guide reads UI tree
   PilotForegroundService     ←  keeps Dia alive while Pilot drives other apps
   GuideOverlayService        ←  draws pointer/highlight/caption over any app
   DiaNotificationListener    ←  reserved for future use
```

The whole app is offline by default. Network permission exists only because some Compose / CameraX / Compose-Material-Icons internals reference it; Dia itself never makes a network call.

### Module layout

```
app/src/main/java/com/dia/app/
  DiaApp.kt               Compose router, single backstack
  MainActivity.kt         enableEdgeToEdge, attach PilotAgent context
  DiaAccessibilityService.kt
  DiaNotificationListenerService.kt
  llm/
    DiaEngine.kt          singleton, all model calls go through here
    ModelState.kt         sealed UI state
  pilot/
    PilotAgent.kt         agent loop
    PilotForegroundService.kt
    PilotEvent.kt
    PilotState.kt
    tool/                 14 tools that act on the screen
  guide/
    GuideEngine.kt        single-step iterative planner
    GuideOverlayService.kt foreground service hosting overlays
    GuideModels.kt
    ui/                   PointerOverlayView, TargetHighlightView, CaptionOverlayView
  slate/
    SlateState.kt         observable state + viewport + tools
    SlateAi.kt            renders bitmap, calls model, animates reply
    HandwritingFont.kt    hand-drawn glyph library
    HandwritingSynth.kt   text → animated cursive strokes
    InkRenderer.kt        smooth quadratic-Bezier path builder
    InkModels.kt          Stroke, InkPoint, PenMode, etc.
  ui/
    home/                 HomeScreen, FeatureTile, DiaMascot, StatusBar
    chat/                 ChatScreen + ChatViewModel
    lens/                 single-shot Lens
    lenslive/             selector + 3 mode screens + shared components
    pilot/                PilotScreen
    guide/                GuideScreen (entry / permissions)
    slate/                SlateScreen (canvas + toolbar)
    onboarding/, setup/, settings/
    components/           GlassCard, GlowEffect
    theme/                Color, Theme, Type
  navigation/
    DiaNavigation.kt      route data objects
```

---

## The LLM engine — `DiaEngine`

File: `app/src/main/java/com/dia/app/llm/DiaEngine.kt`

`DiaEngine` is a Kotlin `object` (singleton). Owns a single `com.google.ai.edge.litertlm.Engine` and zero or more `Conversation`s. Initialised once at Model Setup and kept alive for the whole process.

### Engine lifecycle

```kotlin
suspend fun initialize(context, modelPath, preferredBackend = null) {
  // Tries GPU first, falls back to CPU on failure.
  // EngineConfig:
  //   backend = GPU() | CPU()
  //   visionBackend = matches main backend
  //   audioBackend = CPU
  //   maxNumTokens = 4096
}
```

State is exposed via a `StateFlow<ModelState>`:

```
NotLoaded → Loading("…") → Ready("Gemma E2B (GPU)") | InsufficientMemory | Error
```

### Conversations

LiteRT-LM has a hard rule: **only one `Conversation` exists at a time per `Engine`**. Creating a second one before the first is closed throws `FAILED_PRECONDITION: A session already exists`. Closing is asynchronous at the native layer — `close()` returns immediately but the slot may not free for ~80 ms.

`DiaEngine` works around this with three patterns:

1. **Per-feature conversation slot.** Each feature reuses one slot:
   - `conversation` → Chat (long-lived)
   - `pilotConversation` → Pilot (one per turn)
   - `lensConversation` → Lens / Lens Live / Slate (one per turn)

2. **Close-and-quench-and-retry.** Before a new Conversation is created, all known slots are closed, then `Thread.sleep(80)` lets the native side settle, then up to 7 creation attempts with 120ms→1.2s exponential backoff handle session-conflict errors.

3. **Synchronous wait for Pilot.** Pilot's `sendPilotTurn` collects tokens via `sendMessageAsync` but waits for `onDone` with a `CountDownLatch`. By the time the function returns, the session has fully released. This is the difference that fixed the back-to-back "session already exists" crash on step 2.

### Public API

| Method | Used by | System prompt | Stateful |
|---|---|---|---|
| `sendMessage(text, images, audio, …)` | Chat | "You are Dia, a helpful…" | yes (multi-turn) |
| `sendSingleTurn(text, images, …, systemInstruction?)` | Slate | caller-provided | no |
| `sendLensQuery(text, image, …)` | Lens, Lens Live Think | realtime vision prompt | no |
| `sendLensTranslate(image, …)` | Lens Live Translate | translation-only prompt | no |
| `sendLensConversation(text, image, isFirstTurn, …)` | Lens Live Guide | bbox-aware vision prompt | yes |
| `sendPilotTurn(systemInstruction, text, …)` | Pilot | caller-provided (full agent prompt) | no |
| `cancelLensQuery()`, `cancelPilotSession()`, `cancelGeneration()` | shutdown / cancel | — | — |
| `resetConversation()` | Chat "new chat" | — | — |

### Vision input

`Bitmap` → PNG bytes → `Content.ImageBytes`. Slate downscales to 720px max side and renders strokes black-on-white for maximum contrast (see `SlateAi.renderForModel`). Pilot does not currently send images; it relies on the accessibility tree.

---

## Accessibility service — `DiaAccessibilityService`

File: `app/src/main/java/com/dia/app/DiaAccessibilityService.kt`

Single instance, exposed as a `@Volatile` static. Used by:

- **Pilot** — `performTap`, `performSwipe`, `performLongPress`, `performImeEnter`, `getNodeById`, `getNodeCoordinates`, `findNodesByText`, `getScreenTree`.
- **Guide** — `getScreenTree`, `getNodeById`, `findNodesByText`, plus event callbacks `onScreenChanged` / `onUserClicked`.
- **UI permission checks** — `isRunning()` for the warning cards.

### Screen tree

`getScreenTree()` walks `rootInActiveWindow` and emits a compact, model-friendly serialization:

```
APP: com.android.settings
[n1] "Wi-Fi" TAP @540,650
[n2] "Bluetooth" TAP @540,720
[n3] hint="Search settings" EDIT TAP @540,180
…
```

Decisions:

- Cap at 250 visible interactive nodes (was 120 — bumped because deep apps like YouTube push the search field past 120).
- Include `hintText` (API 26+) so empty input fields aren't invisible.
- Emit `EDIT` marker for any node whose `isEditable` OR class name contains EditText / SearchView / AutoComplete / TextField / TextInput. YouTube's search field reports `isEditable=false` until tapped — we still mark it.
- Coordinate format is `@cx,cy` (single point) instead of bounds rect — saves tokens, tap_node and tap both work with center.
- The PilotAgent's prompt trimmer **always keeps `EDIT` lines**, then fills with other interactive nodes, so input fields are never truncated away.

### Gestures

`performTap`, `performLongPress`, `performSwipe` all dispatch a single-stroke `GestureDescription` and wait synchronously on a `CountDownLatch` (2 second timeout). Synchronous waits keep Pilot's loop deterministic.

### IME Enter

`performImeEnter()` is the most fragile API in the file. Strategy:

1. Find the focused input via `findFocus(FOCUS_INPUT)`.
2. On Android R+, try `AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id`. This invokes the keyboard's done/search action and works in nearly every real app.
3. As a no-op fallback, attempt `Runtime.getRuntime().exec("input keyevent 66")`. Doesn't work outside ADB shell on production devices, but it's harmless to attempt.

### Event routing

`onAccessibilityEvent` routes to:

- `TYPE_WINDOW_STATE_CHANGED` → `GuideEngine.onScreenChanged()` (currently a no-op)
- `TYPE_VIEW_CLICKED` → `GuideEngine.onUserClicked()` — this is the real "user followed the instruction" signal that drives Guide forward.

We deliberately do NOT route `TYPE_WINDOW_CONTENT_CHANGED` to Guide. That event fires hundreds of times per second on apps like Blinkit and was causing premature "done" signals.

---

## Navigation & app shell

`DiaApp.kt` uses `androidx.navigation3` with a single `mutableStateListOf` backstack. Routes are `data object`s in `navigation/DiaNavigation.kt`:

```
OnboardingRoute → HomeRoute
HomeRoute → ChatRoute, LensRoute, LensLiveRoute, PilotRoute, GuideRoute,
            SlateRoute, SettingsRoute, ModelSetupRoute
LensLiveRoute → LensThinkRoute, LensTranslateRoute, LensGuideRoute
```

Two safety details:

- The backstack is reseeded if it ever empties (`if (backStack.isEmpty()) backStack.add(startRoute)`), preventing the rare `NavDisplay backstack cannot be empty` crash on process restart.
- `MainActivity` declares `android:configChanges="orientation|screenSize|screenLayout|smallestScreenSize"` so when Slate locks to landscape the Activity isn't recreated (which would wipe the in-memory backstack).

`HomeScreen` is a 2×4 grid of `FeatureTile`s with a glowing icon, ambient gradient orbs, the `DiaMascot`, a greeting, and a `StatusBar` showing model + backend.

---

## Feature: Chat

Files: `ui/chat/ChatScreen.kt`, `ui/chat/ChatViewModel.kt`, `ui/chat/ChatMessage.kt`

Standard streaming chat. Scrollable bubble list, mic button (placeholder), image attachment, markdown rendering via `richtext-commonmark`.

### Lifecycle

```
sendMessage(text)
    → if (conversation == null) lazily recreate it
       (closes any lingering Pilot/Lens session, retry up to 7×)
    → DiaEngine.sendMessage(text, images, audio, onToken, onError)
    → tokens stream into _messages StateFlow
    → done sets isStreaming = false
```

The lazy-recreate fix is critical: Slate, Pilot, Lens Live all close the chat conversation when they run, because LiteRT-LM only allows one session. Before this fix, returning to Chat after using any other feature gave "Engine not initialized."

The Chat conversation is the only stateful one. `resetConversation()` closes and reopens it, giving you a fresh thread.

---

## Feature: Lens

File: `ui/lens/LensScreen.kt`

Single-shot vision: pick or capture an image, type a question, get an answer.

Uses `DiaEngine.sendLensQuery` which has a static prompt aimed at "describe what you see". Simple — most Lens use is curiosity-driven, not task-driven.

---

## Feature: Lens Live

The Lens Live entry point is a mode selector (`ui/lenslive/LensLiveScreen.kt`) showing three glass cards. Each navigates to a dedicated screen with its own camera lifecycle, TTS, and engine call pattern.

Shared components live in `ui/lenslive/LensLiveComponents.kt`:

- `AuroraBorder` — flowing gradient edge animation, tint-aware (purple for Think, amber for Translate, blue for Guide).
- `CaptionBubble` — chat-bubble style overlay with streaming cursor.
- `ThinkingIndicator` — animated dots while inference runs.
- `InitializingOverlay` — full-screen loader while CameraX warms up.
- `captureFrameScaled` — CameraX `ImageCapture.takePicture` → JPEG bytes → `Bitmap` → scaled to 512px max side, optionally mirrored for front camera. Synchronous via `suspendCancellableCoroutine`.

### Think mode

File: `ui/lenslive/LensThinkScreen.kt`

What it does:

1. CameraX preview, back camera.
2. Continuous **quick scan** every 3.5 s — short prompt, ~10 word reply, no TTS.
3. **Stillness detection** — listens to the accelerometer, computes magnitude deviation from gravity; if `|mag − 9.81| < 0.4 m/s²` for 2.5 s, auto-triggers **deep think** (long prompt, full description, TTS).
4. Manual **Deep Think button** — purple circular button with a stillness ring that fills as the phone holds still.

Why an auto-trigger on stillness? It mirrors how people use a magnifier — you point, hold, and want a careful look. Saves the user from tapping.

### Translate mode

File: `ui/lenslive/LensTranslateScreen.kt`

Auto-captures every 4 s and calls `DiaEngine.sendLensTranslate`. The translate prompt is brutal:

> "Your ONLY job is to find any visible text in the image and translate it to English. Format it exactly as: '[Original text] → [English translation]'. If there is no text visible, output exactly: 'No text detected'."

TTS speaks the translation. Amber aurora border. Uses back camera only (no flip).

### Guide mode

File: `ui/lenslive/LensGuideScreen.kt`

The Gemini Live-style mode. Tap the mic, ask a question, the model answers about whatever is in frame and **draws a green bounding box on the object it's talking about**.

The system prompt instructs the model to begin its reply with a `[BOX:x1,y1,x2,y2]` tag in normalized 0-1 coordinates. We parse it with:

```kotlin
val boxRegex = Regex(
  "\\[BOX\\s*:\\s*([0-9.]+)\\s*,\\s*([0-9.]+)\\s*,\\s*([0-9.]+)\\s*,\\s*([0-9.]+)\\s*\\]"
)
```

`sanitizeBounds` accepts both 0-1 normalized and 0-100 percent coordinates (the model sometimes drifts), validates min size, and discards inverted boxes.

A `Canvas` overlay on top of the camera preview maps the normalized coords to screen pixels — accounting for FILL_CENTER cropping (image aspect vs screen aspect) — and draws:

- A black 45%-alpha dim layer
- A radial cut-out around the box center (blendMode = Clear)
- A green `Color(0xFF4ADE80)` rounded-rect stroke
- A pulsing inner dot

`sendLensConversation` is multi-turn. After the first call, `isFirstTurn = false` keeps the same conversation alive so follow-up questions ("what about the one next to it?") have context. Each turn captures a fresh frame.

Voice input via Android `SpeechRecognizer` with `RecognizerIntent.LANGUAGE_MODEL_FREE_FORM`. Camera flip button exists. Aurora border tinted blue.

---

## Feature: Pilot

The autonomous on-device agent. You give it a goal, it controls the phone.

Files:

- `pilot/PilotAgent.kt` — the loop
- `pilot/PilotForegroundService.kt` — keeps the process alive
- `pilot/tool/` — tool registry + 14 tool implementations
- `ui/pilot/PilotScreen.kt` — task input, log, controls

### Agent loop

```
start(task)
  └─ launch foreground service
     ├─ initial screen read
     └─ for step in 1..40:
          ├─ build prompt (task + screen tree + recent history + recovery hint)
          ├─ DiaEngine.sendPilotTurn(systemInstruction, prompt)
          ├─ extract JSON from response (brace-balanced, handles truncation)
          ├─ stuck detection
          │    ├─ same fingerprint × 3 → force a different tool
          │    ├─ screen unchanged × 3 → if last was input_text, force enter
          │    └─ 3+ consecutive errors → finish with summary
          ├─ execute tool via ToolRegistry.executeTool
          │    └─ fuzzy name match (find-and-tap → find_and_tap, etc.)
          ├─ if action tool: settle delay → re-read screen
          └─ update notification (live progress)
```

### System prompt

Hard rules — **DO NOT FINISH EARLY** is the most important:

> Opening an app is NEVER the final goal. If the task says "search for X in Y" and you just opened Y, you are NOT done. Find the search bar, type X, and submit.
>
> Only call finish when the user can SEE the final result on screen.

Without this section the model would `finish` after every `open_app` because it interpreted "in app launched" as "task done."

Other rules: prefer `open_url` for web tasks, `get_device_info` for battery/wifi/storage queries, `tap_node` over `tap`, `input_text(submit=true)` for in-app search.

### Tool registry

`ToolRegistry.executeTool(name, params)` does fuzzy matching:

1. Exact match
2. Hyphens → underscores
3. Strip underscores
4. Substring match against registered names
5. Else "Unknown tool: <name>. Available: …"

The 14 tools:

| Tool | Purpose |
|---|---|
| `get_screen_info` | fresh screen tree |
| `tap_node(node_id)` | tap by node id from the tree |
| `tap(x, y)` | tap at coords |
| `long_press(node_id\|x,y)` | long-press |
| `swipe(start_x, start_y, end_x, end_y, duration_ms?)` | swipe gesture |
| `input_text(text, node_id?, clear_first?, submit?)` | type, with auto-Enter (default `submit=true`) |
| `system_key(key)` | back / home / recents / enter |
| `open_app(package_name\|app_name)` | launch via PackageManager |
| `open_url(url\|query)` | `Intent.ACTION_VIEW` — also accepts a `query` and runs Google search |
| `find_and_tap(text)` | text search, parent-clickable fallback |
| `scroll_to_find(text)` | scroll until text appears, then tap |
| `get_device_info(category)` | battery / wifi / storage / device / time, no Settings detour |
| `wait(duration_ms)` | sleep |
| `finish(summary)` | end the task |

### `InputTextTool` resilience

This was the most-iterated tool. Order of operations:

1. If `node_id` given, tap its coordinates and wait 450 ms for IME to open.
2. **Strategy A** — try the cached node directly. Many fields (YouTube search) only become editable after focus, so checking `isEditable` first throws away the working node.
3. **Strategy B** — `findFocus(FOCUS_INPUT)`, `findFocus(FOCUS_ACCESSIBILITY)`.
4. **Strategy C** — find the closest editable / EditText-class node to the tap point.
5. **Strategy D** — collect every editable / EditText / SearchView / AutoComplete / TextField / TextInput / MultiAutoCompleteTextView / SearchBar / SearchField on screen.
6. **Last resort** — any focusable node whose class name contains "Text", "Input", "Search", or "Field".

For each candidate: `ACTION_FOCUS` → `ACTION_CLICK` → `ACTION_SET_TEXT` (3 retries) → if all fail, **clipboard paste** via `ACTION_PASTE`. Web views and custom IMEs that reject SET_TEXT often accept paste.

If `submit=true` (default), `service.performImeEnter()` runs after typing.

### Stuck detection

Three escalation levels:

1. **Hint level** — inject a contextual recovery sentence into the next prompt. Example: tool=`tap_node` failed with "node not found" → hint = "That node id is stale. Call get_screen_info to get fresh ids."
2. **Strategy switch** — if same fingerprint repeats `STUCK_WINDOW=3` times, force a different tool:
   - `find_and_tap` stuck → `scroll_to_find`
   - `input_text` stuck → `system_key(enter)`
   - `tap_node` stuck → `get_screen_info`
   - `open_app` failed → `open_url(query=task)`
3. **Forced submit** — if the screen hash hasn't changed for 3 steps and the last tool was `input_text`, auto-fire `system_key(enter)` regardless of what the model wants. Recovers cases where the IME swallowed the submit.

### Token budget

- `SCREEN_TREE_CHAR_BUDGET = 1800` — was 2800, but with system prompt + tool spec + history + recovery hint, the input was pushing past 4096 tokens and the response got truncated mid-JSON. Reducing the screen budget to 1800 reliably fits.
- `HISTORY_LINES = 4`
- Tool spec is shown only on step 1 and every 5th step. The model has seen it recently — no need to repeat every turn.

### Screen-tree trimming

The trimmer in `PilotAgent.trimScreenTree` is "EDIT-aware": it keeps every line containing ` EDIT ` first, then fills the remaining budget with other lines. So input fields are never lost to truncation, regardless of how deep they sit in the tree.

### JSON extraction

`extractJson` walks the response character by character, tracking string boundaries (with backslash escape) and brace depth, returning the first balanced `{…}`. If truncated, falls back to `lastIndexOf('}')`. Worst case the parser sees a partial object and we plan a `get_screen_info` instead of crashing.

### Foreground service

`PilotForegroundService` runs while a task is active. Three jobs:

1. Raise process priority so Android doesn't kill Dia when it's backgrounded controlling another app (this was the original bug that triggered all the `NavDisplay backstack cannot be empty` reports — Dia was being killed mid-task with the LiteRT-LM engine still in 2 GB of RAM).
2. Hold a partial wake lock (10-minute ceiling) so the CPU doesn't doze during inference.
3. Show an ongoing notification with live step progress: "Pilot · Step 3 · ✓ open_app".

`startForeground` uses `FOREGROUND_SERVICE_TYPE_SPECIAL_USE` on Android 14+, with the required `<property android:name="android.app.PROPERTY_SPECIAL_USE_FGS_SUBTYPE" …>` declaration in the manifest.

### Logs

`PilotAgent` exposes `state: StateFlow<PilotState>` and `log: StateFlow<List<PilotLogEntry>>`. The UI scrolls through every step, every tool call, every result — what color-coded lines look like:

```
Started: search for dairy milk in blinkit
Step 0: Reading screen…
Step 1: Thinking…
▶ open_app  {"app_name":"blinkit"}
  ← Opened com.grofers.customerapp
Step 2: Thinking…
▶ find_and_tap  {"text":"Search"}
  ← Tapped: Search
Step 3: Thinking…
▶ input_text  {"text":"dairy milk","submit":true}
  ← Typed: dairy milk
…
✓ Done: Added Dairy Milk Silk to cart
```

---

## Feature: Guide

Interactive on-screen tutor. The user asks "how do I X?" and a glass cursor flies to the next thing they should tap, captioned and spoken aloud, step by step. The user taps; Guide reacts and points to the next step.

Files:

- `guide/GuideEngine.kt` — the planner
- `guide/GuideOverlayService.kt` — overlay host
- `guide/GuideModels.kt` — `Guide`, `GuideStep`, `GuideAction`, `GuideState`
- `guide/ui/PointerOverlayView.kt`, `TargetHighlightView.kt`, `CaptionOverlayView.kt`
- `ui/guide/GuideScreen.kt` — Compose entry point

### Iterative single-step planning

Originally Guide planned the whole tutorial up front from one screenshot, then walked through it. That broke as soon as the user navigated, because all the node IDs went stale.

Now: **plan one step against the current screen, then wait, then re-plan against the next screen.**

```
start(question)
  ├─ tryAutoOpenApp(question)        ← match "blinkit", "youtube" etc., launch via PM
  └─ runLoop:
       └─ for stepIdx in 1..25:
            ├─ readScreenTree (8 retries × 500 ms — slow apps need it)
            ├─ planNextStep (single-step prompt to Gemma)
            ├─ parse {action, node_id, label, caption, text?}
            ├─ render: pointer animates to target, highlight glows, caption + TTS
            ├─ auto-hide pointer + highlight after 1.5 s (so user can tap)
            └─ waitForScreenChange — actually waits for TYPE_VIEW_CLICKED via pendingReplan
```

### Auto-launch

If the user mentions a known app ("open whatsapp", "search youtube for…"), `tryAutoOpenApp` skips home-screen / drawer guidance entirely:

1. Match against a built-in map of 40+ common apps (Samsung packages prioritised).
2. Fall back to scanning all installed apps by display label.
3. `pm.getLaunchIntentForPackage(matched)` + `FLAG_ACTIVITY_NEW_TASK` + `startActivity`.
4. Wait 1.4 s for the new app to be in the foreground.
5. Then the loop runs against the live app.

### Why generic screen-changes are ignored

`onScreenChanged()` is intentionally a no-op. It used to call `pendingReplan.set(true)`, which fired the loop on every `TYPE_WINDOW_CONTENT_CHANGED` event. On Blinkit / Instagram / YouTube that's hundreds per second — the model kept replanning, kept seeing slightly different screens, kept saying "done" because it couldn't find the exact node. Result: Guide closed itself a second after opening the app.

Only `TYPE_VIEW_CLICKED` triggers `onUserClicked() → pendingReplan = true`. That's the real signal that the user followed the instruction.

### Auto-hide overlays — Samsung touch fix

Samsung One UI 6+ blocks touches through any overlay with `FLAG_NOT_TOUCHABLE` and shows a "Dia is not optimized" toast. Switching to `FLAG_NOT_FOCUSABLE | FLAG_NOT_TOUCH_MODAL | FLAG_WATCH_OUTSIDE_TOUCH` (no `FLAG_NOT_TOUCHABLE`) plus overriding `dispatchTouchEvent → false` in the views helped, but on some devices it still intermittently blocked.

The simple, reliable fix: **the pointer + highlight overlays auto-hide 1.5 s after they appear**. The user sees where to tap, then the overlay disappears, then they tap a clean screen. The caption stays (positioned away from the target) so they know what they're doing.

### Caption positioning

The caption window uses `FLAG_NOT_TOUCH_MODAL | FLAG_WATCH_OUTSIDE_TOUCH` so touches outside its actual view bounds pass through. Its only touchable elements are Prev / Replay / Next / Close buttons.

It also **repositions dynamically** — if the target's vertical center is in the bottom half of the screen, caption goes to the top; otherwise bottom. Never on top of what you need to tap.

### Glass pointer

`PointerOverlayView` is hand-drawn in `Canvas` using:

- 7-stop radial body gradient (warm core → faint cool tint → darker rim)
- a "saturation" radial pass for the lens "warp" feel
- a thick semi-transparent inner-shadow ring that fakes the refracted edge
- a sweep-gradient chrome rim (white → light blue → mid blue → white)
- specular highlight (top-left)
- soft drop shadow

It pulses with `ValueAnimator` (1.0 → 1.12 → 1.0 every 700 ms). Animates to the target via per-frame `WindowManager.updateViewLayout` using a 300-ms ease-out interpolation scaled by distance.

### Error UX

`fail(msg)` used to set state `IDLE` immediately. The overlay observer saw IDLE and called `stopSelf()`, killing the caption before the user could read why. Fixed: `fail` now emits the error, waits 3.5 s on the caption, then transitions to IDLE.

### System prompt highlights

> ANALYSIS ORDER — DO THIS EVERY TURN:
> 1. Look at the SCREEN tree first. Is there a visible node whose label matches the target the user wants? If yes — use it directly with action=tap.
> 2. Only if NO matching node exists in the visible tree, decide whether you need to navigate (back / open app drawer / scroll).
> 3. Never default to "swipe up to open app drawer" before checking the visible tree.

> APP DRAWER: a grid of app icons sorted alphabetically. If the target app is NOT visible in the current page, the user needs to SCROLL DOWN to find it.

> CRITICAL — DO NOT FINISH EARLY:
> Opening an app is NEVER the final goal.

---

## Feature: Slate

A landscape infinite-canvas notebook with AI handwriting playback.

Files:

- `slate/SlateState.kt` — observable state
- `slate/SlateAi.kt` — render canvas → bitmap, model call, animate reply
- `slate/HandwritingFont.kt` — hand-drawn glyph library
- `slate/HandwritingSynth.kt` — text → animated cursive strokes
- `slate/InkRenderer.kt` — smooth Compose Path builder
- `slate/InkModels.kt` — `Stroke`, `InkPoint`, `PenMode`, `CanvasRect`
- `ui/slate/SlateScreen.kt` — Compose UI

### Canvas

- World coordinates. Strokes never store screen pixels.
- Pan + zoom: two-finger gesture. Pinch zoom anchors on the focal point so it stays under the user's fingers.
- Drawing: single finger / stylus. `Stroke.add(p)` appends; if a second finger comes down mid-stroke, the active stroke is dropped and we switch to pan/zoom.
- Stylus pressure: `change.pressure` is read directly. On non-stylus touches it's a constant 1.0. Pressure modulates stroke alpha and width subtly.
- Backgrounds: dots / grid / plain. Scale-aware — grid spacing on screen always renders correctly when zoomed.
- Pen modes: pen, highlighter (low-alpha wide stroke), eraser (sweep over strokes; bounding-box pre-rejection then point-distance hit-test).
- Undo: bounded to add-stroke and remove-strokes ops. Redo is intentionally not implemented yet — single-direction undo is sufficient for a v1 notebook.
- Stroke virtualization: in `Canvas.onDraw`, every stroke whose bounding box doesn't intersect the viewport is skipped. With thousands of strokes you only pay for what's visible.

### Smooth ink

`InkRenderer.buildSmoothPath` uses **midpoint quadratic interpolation** — the same trick used by GoodNotes and Notability. Each curve segment ends at the midpoint between two raw samples with the previous sample as the control point. Removes per-sample jitter without hiding actual handwriting motion.

### Live stroke performance

The **biggest perf bug** during development: `state.currentStroke = s` reassignment on every pointer sample. Compose snapshotted the entire stroke each time. Adding a 100-point stroke = 100 full-list copies.

Fix: a separate `liveStrokeTick: Int` state that the Canvas observes. `extendStroke(p)` does `s.add(p)` then `liveStrokeTick++`. Compose recomposes (because it reads the tick), but adding a point is now a list-append + Int-increment instead of a snapshot copy.

### Locking landscape

Slate requests `SCREEN_ORIENTATION_SENSOR_LANDSCAPE` in a `DisposableEffect` and restores `UNSPECIFIED` on dispose. To survive the orientation change without the Activity being recreated (which would wipe the navigation backstack), `MainActivity` declares the relevant config changes in the manifest.

### Asking the AI

`SlateAi.ask`:

1. Compute bounding box of all user strokes (`SlateState.userContentBounds`).
2. Render that region to a 720-px white-background, **black-ink** bitmap. The black-on-white render maximises contrast for the vision model regardless of the user's pen color.
3. Call `DiaEngine.sendSingleTurn` with a custom system prompt and the bitmap.

### System prompt — answer, don't echo

The pain point on the model's side: vision models love to begin with "The image shows handwritten text reading…" The fix is a relentless prompt with negative examples:

> ABSOLUTE RULES:
> - DO NOT describe the image.
> - DO NOT say "the image shows", "the handwriting reads", "I see", "the user wrote", or anything similar.
> - DO NOT quote the question back. Just answer.
> - Read the handwriting silently, then respond AS IF the person spoke those words to you.
>
> Examples:
> Input: "Who is Elon Musk?"
> GOOD: CEO of Tesla and SpaceX, founded PayPal and now owns X.
> BAD: The image shows handwritten text reading 'Who is Elon Musk?'

Plus a **client-side narration filter** in `cleanModelText` that strips leading "The image shows…", "I can see…", "The user wrote…", surrounding quotes, code fences, smart quotes. Belt and suspenders.

### Custom system instruction in `sendSingleTurn`

`DiaEngine.sendSingleTurn` previously had a hardcoded system prompt. The Slate prompt was being passed as the user message, where the model treated it as a request to describe rather than a directive. Adding `systemInstruction: String?` parameter (with the old "vision assistant" prompt as the default) was the fix.

### Adaptive scaling

`SlateState.estimatedTextHeight()` takes the median height of recent user strokes (filtered to the 6-200 px range). That value becomes the AI's text size, so big handwriting gets big AI ink, small notes get small AI ink.

`SlateState.aiAnchor()` returns the position just below the lowest user stroke at the same left margin, so the AI's reply visually continues the user's notes.

### Synthesised handwriting

`HandwritingFont.kt` is a hand-built glyph library. Each character is a list of "letter strokes" where each stroke is a sequence of unit-coordinate points the pen passes through (`(0,0)` is the top-left of the letter box, `(1,1)` is the bottom-right, `y > 1` is descender). Built using:

- `line(p1, p2, …)` — straight-line segments
- `quad(p0, p1, p2, steps=12)` — quadratic Bézier sampling
- `cubic(p0, p1, p2, p3, steps=16)` — cubic Bézier sampling
- `arc(cx, cy, rx, ry, startDeg, endDeg, steps=28)` — for bowls (a, b, c, d, e, g, o, p, q)

Coverage: a-z, A-Z, 0-9, plus `. , ? ! : ; - + = / \ ( ) * " '`. Anything outside that gets a fallback dash so we don't lose characters.

`HandwritingFont.jitterGlyph` applies per-character variation:

- Forward base slant of 0.12 (cursive lean) ± 0.03
- Y shift ± 0.04
- X scale ± 0.06, Y scale ± 0.05
- Per-point jitter ± 0.012

So two `a`'s in the same word never look identical.

`HandwritingSynth.synthesize` ties it all together:

- Word-wraps to `maxWidth` using glyph advance widths.
- Densifies straight segments to ~1.8 px spacing so the animation has plenty of intermediate points.
- After each glyph (unless the next char is a space), draws a thin **cursive connector** stroke from the end of the last letter to the start of the next. This is the one feature that flips the visual from "italic font" to "actually handwritten".

### Animation

`SlateAi.animateStrokes` runs on `Dispatchers.Main` (Compose state must be written from the main thread). For each synthesized stroke:

```
state.currentStroke = empty live copy
for each point in the stroke:
    live.add(point)
    state.bumpLiveTick()         // triggers Canvas redraw
    delay(4 ms × speed factor)   // 1.4× start, 1.0× middle, 1.2× near-end
state.currentStroke = null
state.addAiStroke(live)          // commit to persistent layer
delay(28 ms)                     // pen-lift between glyphs
```

The result: the slate appears to write its answer at human-feeling speed.

---

## Onboarding, Model Setup, Settings

- **Onboarding** — single-screen welcome, written-once flag in SharedPreferences (`onboarding_complete`).
- **Model Setup** — pick a `.task` file from device storage, choose preferred backend (auto / GPU / CPU), watch progress as the engine initialises. Backend auto-falls-back to CPU if GPU init fails.
- **Settings** — currently shows engine status (active model, backend, file path basename) and a "Clear Chat History" action that calls `DiaEngine.resetConversation()`.

---

## Cross-cutting concerns

### Threading

- Compose state writes on `Dispatchers.Main`.
- LLM inference on `Dispatchers.IO` (LiteRT-LM also offloads internally).
- Coroutine scopes:
  - `DiaEngine` — none, runs on caller's scope
  - `PilotAgent` — `CoroutineScope(Dispatchers.IO + SupervisorJob())`, app-scoped
  - `GuideEngine` — same, app-scoped
  - `GuideOverlayService` — `CoroutineScope(Dispatchers.Main + SupervisorJob())`, service-scoped
  - `SlateState` — none, scope provided by caller (the screen's `rememberCoroutineScope`)

### Error handling philosophy

- Every model call either streams tokens or fires `onError`. UI state machines have an `Error` state with a friendly message and auto-recover after a short delay.
- Tool failures in Pilot don't crash the loop — they get formatted into history and the next prompt sees them, so the model can self-correct.
- Native session conflicts in LiteRT-LM are caught and retried up to 7 times.
- No Toast spam. State changes drive UI; UI shows a pill or caption with the message.

### OEM quirks we account for

- **Samsung One UI 6+** — overlay touch blocking. Mitigated with `FLAG_NOT_TOUCH_MODAL` + view-level `dispatchTouchEvent → false`, and ultimately by auto-hiding overlays after 1.5 s in Guide.
- **Samsung accessibility tree** — slow to populate on heavy apps. Guide retries the read 8 times × 500 ms.
- **Samsung battery optimisation** — likely to kill backgrounded apps with 2 GB of native memory loaded. PilotForegroundService takes care of this.
- **One UI orientation locks** — handled by adding `configChanges` in the manifest so MainActivity doesn't recreate.

### What's currently disabled / placeholder

- The mascot has a placeholder logo image.
- "Voice" and "Drive" tiles on the home screen are present but route to nothing.
- Settings has no theme picker or model swap UI yet.
- No telemetry, no analytics. Network permission exists but is unused by Dia code.

### What's been deliberately deferred

- Cloud fallback model providers (OpenAI / Gemini / Groq). Architecture supports it; no UI.
- Embedding-based memory / vector DB. Current memory is the conversation context window.
- True diffusion-based handwriting synthesis. Current path-from-glyph approach looks great and runs fast on-device.
- Full handwriting OCR with a bundled ONNX model. Slate currently relies on the vision model.
- ML Kit Digital Ink Recognition. Not used; the Gemma vision model handles it acceptably.

---

## Engineering principles

- **One model, one process.** Don't multiply native sessions.
- **Compose state on the main thread, always.** Background work suspends.
- **Stateful conversations cost RAM and risk session conflicts.** Use single-turn for transient features.
- **Fuzzy matching beats brittle exact match.** Tool names, screen tree node lookups, model output parsing all assume the model will be slightly wrong sometimes.
- **Auto-hide before block.** When in doubt, remove the overlay rather than fight the OS to keep it interactive.
- **Recover, don't error out.** Stuck detection forces strategy switches before giving up.
- **Don't make the user retry.** Lazy-recreate sessions, retry on transient failures, settle on slow devices.

---

This is a living document. As features ship and bugs reveal new constraints, update the relevant section.
