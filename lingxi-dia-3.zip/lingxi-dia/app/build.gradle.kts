plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.compose.compiler)
    alias(libs.plugins.kotlin.serialization)
}

android {
    namespace = "com.dia.app"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.dia.app"
        minSdk = 26
        targetSdk = 36
        versionCode = 2
        versionName = "2.0.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildFeatures {
        compose = true
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
            excludes += "/META-INF/DEPENDENCIES"
            excludes += "/META-INF/INDEX.LIST"
            pickFirsts += "/META-INF/*.kotlin_module"
        }
        jniLibs {
            // MediaPipe 与 LiteRT 可能都带同名 .so，取第一个即可
            pickFirsts += "**/libc++_shared.so"
        }
    }
}

kotlin {
    jvmToolchain(17)
}

dependencies {
    val composeBom = platform(libs.androidx.compose.bom)
    implementation(composeBom)
    androidTestImplementation(composeBom)

    // Core
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.lifecycle.runtime.compose)
    implementation(libs.androidx.lifecycle.viewmodel.compose)

    // Compose UI
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.graphics)
    implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.compose.material.icons.extended)
    implementation(libs.androidx.compose.animation)
    implementation(libs.androidx.compose.foundation)

    // Navigation 3
    implementation(libs.androidx.navigation3.runtime)
    implementation(libs.androidx.navigation3.ui)
    implementation(libs.androidx.lifecycle.viewmodel.navigation3)
    implementation(libs.kotlinx.serialization.json)

    // LiteRT-LM (on-device LLM inference)
    implementation(libs.litertlm)
    implementation(libs.tflite.gpu)

    // Markdown rendering for chat
    implementation(libs.richtext.commonmark)
    implementation(libs.richtext.ui.material3)

    // PDF 文字提取（读取本地 PDF）
    implementation("com.tom-roush:pdfbox-android:2.0.27.0")

    // 本机生图（MediaPipe Image Generator，代码里通过反射调用）。
    // 构建时可用 -Pdia.localImageGen=false 去掉（例如遇到依赖冲突时）。
    if ((project.findProperty("dia.localImageGen") ?: "true").toString().toBoolean()) {
        implementation("com.google.mediapipe:tasks-vision-image-generator:latest.release")
    }

    // EXIF rotation for Lens image loading (Gallery pattern)
    implementation("androidx.exifinterface:exifinterface:1.3.7")

    // CameraX for Lens Live realtime camera
    implementation(libs.androidx.camera.camera2)
    implementation(libs.androidx.camera.lifecycle)
    implementation(libs.androidx.camera.view)

    // Debug
    debugImplementation(libs.androidx.compose.ui.tooling)
    debugImplementation(libs.androidx.compose.ui.test.manifest)

    // Test
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.test.core)
    androidTestImplementation(libs.androidx.test.ext.junit)
    androidTestImplementation(libs.androidx.test.runner)
    androidTestImplementation(libs.androidx.test.espresso.core)
    androidTestImplementation(libs.androidx.compose.ui.test.junit4)
}
