package com.dia.app.slate

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path as AndroidPath
import android.util.Log
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import com.dia.app.llm.BackendRouter
import com.dia.app.llm.DiaEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.max

private const val TAG = "SlateAi"

/** Color of AI-rendered handwriting on paper. Slightly cooler than user ink. */
internal val AiInk = Color(0xFF2B5BC9)

/* ────────────────────────────────────────────────────────────────────── */
/*  Prompts                                                                */
/* ────────────────────────────────────────────────────────────────────── */

private const val NOTES_PROMPT = """You are reading a handwritten note on a digital slate. You answer the person who wrote it directly.

ABSOLUTE RULES:
- DO NOT describe the image or say what you see.
- DO NOT say "the image shows", "the handwriting reads", "I see", "the user wrote".
- DO NOT quote the question back. Just answer.
- DO NOT say "please provide me with" or "I need you to" or "could you provide" or "please share" or "I don't see any" or "there is no text".
- The image ALWAYS contains handwriting. Read it and respond to what it says.
- If you truly cannot read the handwriting, say "I can't read this clearly — try writing larger."

How to respond:
- Question -> answer directly.
- Math problem -> solve it briefly.
- Topic name -> 1-2 sentence summary.
- Half-finished sentence -> finish it helpfully.
- Single word or name -> give a brief fact about it.

Style:
- 1-2 short lines. Plain text only. No markdown.
- Plain math: x^2, sqrt(2), pi.
- Direct. Friendly. SHORT — your reply will be hand-written into a finite space."""

private const val QUIZ_GEN_PROMPT = """You generate exactly 10 quiz questions on the given topic.

Output format: 10 numbered lines, one question per line, NOTHING else.
1. <question>
2. <question>
...
10. <question>

Rules:
- Each question must be answerable in <= 8 words.
- Mix difficulties.
- For math/science topics, prefer numeric answers.
- No multi-part questions. No "explain why".
- No preamble, no closing, no markdown."""

/**
 * Grading prompt: vision call. Model receives the question (text) and
 * the student's hand-drawn answer as an image, then judges whether the
 * drawing is a valid answer.
 *
 * Designed to be GENEROUS: the model judges the spirit of the answer,
 * not exact text match. A smiley face for "what makes you happy" is
 * correct. A drawn triangle for "name a 3-sided shape" is correct.
 * Tally marks for a count question are correct.
 */
private const val QUIZ_GRADE_PROMPT = """You are grading a hand-drawn quiz answer.

You will see:
1. A question (text).
2. An IMAGE of the student's hand-drawn answer on paper.

Look carefully at the drawing. The student may have:
- Written a number (digit, word, tally, or Roman numeral): "4", "four", "IIII", "IV".
- Written a word, phrase, or sentence answer.
- Sketched a shape, object, person, face, or scene that depicts the answer.
- Written an equation or solution path.
- Used arrows, diagrams, symbols, emoji-like marks.

JUDGE THE SPIRIT OF THE ANSWER, not exact text match. Be GENEROUS.

ACCEPT all of these as CORRECT:
- Equivalent numerical forms ("3" = "three" = "III" = "IIII" = "1+2=3").
- Different cases / spelling / spacing / punctuation / articles.
- Synonyms and near-synonyms.
- A drawing that depicts the right concept (a smiley face for "what's the best feeling", a heart for "what makes life worthwhile", a triangle for "a 3-sided shape", a sun for "what gives us light").
- A short rationale prefix (e.g. "the answer is 4", "the sum is 3").
- Mathematically equivalent forms ("1/2" = "0.5" = "50%").

ONLY mark INCORRECT if:
- The drawing is empty / completely blank.
- The drawing is unintelligible scribble that conveys nothing.
- The answer truly contradicts what the question asks (e.g. drew a square when asked for a triangle, wrote "5" when asked for "1+2").

OUTPUT FORMAT — exactly two lines, no preamble, no explanation, no extra prose:
Line 1: CORRECT or INCORRECT
Line 2: <one canonical correct answer in 1-3 WORDS, plain text — no full sentences>

EXAMPLES:

Question: What is 1 + 2?
Image shows: a hand-written "3"
Output:
CORRECT
3

Question: What is 1 + 2?
Image shows: a hand-written "three"
Output:
CORRECT
3

Question: What is 1 + 2?
Image shows: three tally marks "III"
Output:
CORRECT
3

Question: What is 1 + 2?
Image shows: a hand-written "the sum is 3"
Output:
CORRECT
3

Question: What is 1 + 2?
Image shows: a hand-written "5"
Output:
INCORRECT
3

Question: Draw a 3-sided shape.
Image shows: a hand-drawn triangle
Output:
CORRECT
triangle

Question: Draw a 3-sided shape.
Image shows: a hand-drawn square
Output:
INCORRECT
triangle

Question: Capital of France?
Image shows: a hand-written "paris"
Output:
CORRECT
Paris

Question: What's the most precious thing on earth?
Image shows: a smiley face / a heart / "love" / "family"
Output:
CORRECT
love

Do not include reasoning, explanations, or anything before/after the two lines."""

/* ────────────────────────────────────────────────────────────────────── */
/*  Public API                                                             */
/* ────────────────────────────────────────────────────────────────────── */

object SlateAi {

    /**
     * Render the user's strokes on this page into a high-contrast bitmap
     * the vision model can read. Black ink on white paper regardless of
     * the on-screen pen colour.
     */
    fun renderPageForModel(page: NotebookPage, maxDim: Int = 1024): Bitmap {
        // Find the bounding box of user strokes only — sending the empty
        // page just confuses the model.
        val userStrokes = page.strokes.filter { it.origin == StrokeOrigin.USER }
        if (userStrokes.isEmpty()) {
            // Return a blank canvas so the caller can detect "no input".
            return Bitmap.createBitmap(64, 64, Bitmap.Config.ARGB_8888).apply {
                eraseColor(android.graphics.Color.WHITE)
            }
        }
        var l = Float.POSITIVE_INFINITY; var t = Float.POSITIVE_INFINITY
        var r = Float.NEGATIVE_INFINITY; var b = Float.NEGATIVE_INFINITY
        for (s in userStrokes) {
            if (s.minX < l) l = s.minX
            if (s.minY < t) t = s.minY
            if (s.maxX > r) r = s.maxX
            if (s.maxY > b) b = s.maxY
        }
        val pad = 32f
        l -= pad; t -= pad; r += pad; b += pad

        val w = (r - l).coerceAtLeast(64f)
        val h = (b - t).coerceAtLeast(64f)
        val scale = (maxDim.toFloat() / max(w, h)).coerceAtMost(2f)
        val pxW = (w * scale).toInt().coerceAtLeast(64)
        val pxH = (h * scale).toInt().coerceAtLeast(64)
        val bmp = Bitmap.createBitmap(pxW, pxH, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        canvas.drawColor(android.graphics.Color.WHITE)

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = android.graphics.Color.BLACK
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }

        for (s in userStrokes) {
            paint.strokeWidth = max(3f, s.width * scale * 1.4f)
            val path = AndroidPath()
            for ((i, p) in s.points.withIndex()) {
                val x = (p.x - l) * scale
                val y = (p.y - t) * scale
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            canvas.drawPath(path, paint)
        }
        return bmp
    }

    /**
     * Notes mode: read the page, write a short reply. Calls back with the
     * trimmed reply text (or null on error).
     */
    fun askNotes(
        page: NotebookPage,
        scope: CoroutineScope,
        onResult: (String?) -> Unit,
    ) {
        val bitmap = renderPageForModel(page)
        // Check if the bitmap is essentially blank (no user strokes).
        val userStrokes = page.strokes.filter { it.origin == StrokeOrigin.USER }
        if (userStrokes.isEmpty()) {
            scope.launch(Dispatchers.Main) { onResult(null) }
            return
        }

        val sb = StringBuilder()
        // Give the model a stronger nudge: tell it there IS handwriting and
        // to read it carefully. The previous generic "Read the handwriting"
        // prompt let the model hallucinate when it couldn't parse the ink.
        val textPrompt = "The image contains handwritten text on a white background. " +
            "Read the handwriting carefully — it may be a question, a word, a math problem, or a topic. " +
            "Answer what the handwriting asks. If it's a single word or phrase, give a brief fact about it. " +
            "DO NOT say you cannot read it. DO NOT ask for more input. Just answer."

        BackendRouter.sendSingleTurn(
            text = textPrompt,
            images = listOf(bitmap),
            onToken = { partial, done ->
                if (partial.isNotEmpty()) sb.append(partial)
                if (done) {
                    val cleaned = cleanModelText(sb.toString())
                    scope.launch(Dispatchers.Main) { onResult(cleaned) }
                }
            },
            onError = { msg ->
                Log.e(TAG, "askNotes error: $msg")
                scope.launch(Dispatchers.Main) { onResult(null) }
            },
            systemInstruction = NOTES_PROMPT,
        )
    }

    /**
     * Quiz mode: generate 10 questions for [topic]. Calls back with a
     * list of trimmed question strings (size may be < 10 if the model
     * shorted us; never more than 10).
     */
    fun generateQuiz(
        topic: String,
        scope: CoroutineScope,
        onResult: (List<String>?) -> Unit,
    ) {
        val sb = StringBuilder()
        BackendRouter.sendSingleTurn(
            text = "Topic: $topic\n\nGenerate 10 quiz questions. Output 10 numbered lines, nothing else.",
            images = emptyList(),
            onToken = { partial, done ->
                if (partial.isNotEmpty()) sb.append(partial)
                if (done) {
                    val parsed = parseQuizQuestions(sb.toString())
                    scope.launch(Dispatchers.Main) {
                        onResult(if (parsed.isEmpty()) null else parsed)
                    }
                }
            },
            onError = { msg ->
                Log.e(TAG, "quiz gen error: $msg")
                scope.launch(Dispatchers.Main) { onResult(null) }
            },
            systemInstruction = QUIZ_GEN_PROMPT,
        )
    }

    /** Result of grading one quiz answer. */
    data class GradeResult(val correct: Boolean, val canonical: String)

    /**
     * Grade a single quiz answer with one vision call. The model sees
     * the question (text) plus the rasterised page (image) and judges
     * whether the drawing is a valid answer — accepting written
     * answers, sketches, symbols, tally marks, equivalent forms, etc.
     *
     * One call, not two: a vision model handles the whole pipeline
     * holistically. A drawn smiley for "what makes you happy" gets
     * judged on its meaning, which OCR-then-judge would have lost.
     */
    fun gradeAnswer(
        question: String,
        page: NotebookPage,
        scope: CoroutineScope,
        onResult: (GradeResult?) -> Unit,
    ) {
        if (page.strokes.none { it.origin == StrokeOrigin.USER }) {
            // Empty page — short-circuit without a model call.
            scope.launch(Dispatchers.Main) {
                onResult(GradeResult(false, "(no answer drawn)"))
            }
            return
        }

        val bitmap = renderPageForModel(page)
        val sb = StringBuilder()
        val payload = "Question: $question\n\nThe image shows the student's hand-drawn answer. Judge it. Output the two lines."
        BackendRouter.sendSingleTurn(
            text = payload,
            images = listOf(bitmap),
            onToken = { partial, done ->
                if (partial.isNotEmpty()) sb.append(partial)
                if (done) {
                    val parsed = parseGrade(sb.toString())
                    Log.d(TAG, "Grade raw='${sb.toString().take(120)}' parsed=$parsed")
                    scope.launch(Dispatchers.Main) { onResult(parsed) }
                }
            },
            onError = { msg ->
                Log.e(TAG, "grade error: $msg")
                scope.launch(Dispatchers.Main) { onResult(null) }
            },
            systemInstruction = QUIZ_GRADE_PROMPT,
            temperature = 0.05,
        )
    }

    /* ─── Stroke animation ─── */

    /**
     * Animate the synthesized strokes onto the page, one point at a time.
     * MUST run on Dispatchers.Main because it mutates Compose state.
     *
     * @param baseDelayMs delay between samples; 3-5ms feels natural.
     */
    suspend fun animateStrokes(
        strokes: List<Stroke>,
        state: SlateState,
        page: NotebookPage,
        baseDelayMs: Long = 3L,
    ) {
        for (synthesized in strokes) {
            // Build the stroke incrementally on the live overlay.
            val live = Stroke(
                id = state.newStrokeId(),
                color = synthesized.color,
                width = synthesized.width,
                origin = StrokeOrigin.AI,
                mode = synthesized.mode,
            )
            state.currentAiStroke = live
            for ((i, p) in synthesized.points.withIndex()) {
                live.add(p)
                state.bumpLiveTick()
                val portion = i.toFloat() / max(1, synthesized.points.size)
                val pause = when {
                    portion < 0.08f -> baseDelayMs * 2  // start: a little slower (pen press)
                    portion > 0.92f -> baseDelayMs      // tail: normal
                    else -> baseDelayMs                 // body
                }
                if (pause > 0) delay(pause)
            }
            state.currentAiStroke = null
            page.addAiStroke(live)
            // Tiny gap between strokes, like lifting the pen.
            delay(28)
        }
    }

    /* ─── Internals ─── */

    private fun parseQuizQuestions(raw: String): List<String> {
        val out = ArrayList<String>(10)
        // Match "1. question", "2) question", "1: question" etc.
        val rx = Regex("^\\s*(\\d{1,2})[.)\\:\\-]\\s*(.+?)\\s*$")
        for (line in raw.lines()) {
            val m = rx.matchEntire(line) ?: continue
            val q = m.groupValues[2].trim().trim('"')
            if (q.isNotEmpty() && q.length >= 4) out.add(q)
            if (out.size == 10) break
        }
        return out
    }

    private fun parseGrade(raw: String): GradeResult? {
        // Pull the first non-empty line; if the model added narration ("Sure!"
        // etc.) skip ahead to the first line that contains CORRECT/INCORRECT.
        val lines = raw.lines().map { it.trim() }.filter { it.isNotEmpty() }
        if (lines.isEmpty()) return null

        val verdictIdx = lines.indexOfFirst { line ->
            val u = line.uppercase()
            u.startsWith("CORRECT") || u.startsWith("INCORRECT") ||
                u.contains("\u2705") /* ✅ */ || u.contains("\u274C") /* ❌ */
        }
        val (verdictLine, canonicalLine) = if (verdictIdx >= 0) {
            lines[verdictIdx] to lines.getOrNull(verdictIdx + 1)
        } else {
            // Fallback: just inspect the very first line.
            lines[0] to lines.getOrNull(1)
        }

        val u = verdictLine.uppercase()
        val correct = when {
            u.startsWith("INCORRECT") -> false
            u.contains("INCORRECT") -> false
            u.contains("\u274C") -> false
            u.startsWith("CORRECT") -> true
            u.contains("CORRECT") && !u.contains("INCORRECT") -> true
            u.contains("\u2705") -> true
            else -> false
        }
        val canonicalRaw = canonicalLine
            ?.removePrefix("Answer:")
            ?.trim()
            ?.trimStart('-', ':', '*', '`')
            ?.trim()
            ?.trim('"', '\'', '*', '`')
            ?: ""
        // Strip verbose prefixes Gemma sometimes adds despite the prompt
        // ("the sum is 3", "the answer is 3", "the answer to 1+2 is 3").
        val canonical = stripVerbosePrefix(canonicalRaw).take(40)
        return GradeResult(correct, canonical.ifBlank { "(answer not provided)" })
    }

    private fun stripVerbosePrefix(s: String): String {
        if (s.isEmpty()) return s
        // Common phrasing patterns the model emits even when told not to.
        val patterns = listOf(
            Regex("^(?:[Tt]he )?(?:answer|sum|result|product|difference|quotient|value)(?: of [^=]*?)?(?:\\s+(?:is|=|:))\\s+", RegexOption.IGNORE_CASE),
            Regex("^[Ii]t (?:is|=|:)\\s+"),
            Regex("^=\\s*"),
        )
        var cur = s
        var changed = true
        while (changed) {
            changed = false
            for (re in patterns) {
                val replaced = cur.replace(re, "")
                if (replaced != cur) {
                    cur = replaced.trim()
                    changed = true
                    break
                }
            }
        }
        return cur.trim().trim('.', ',').trim()
    }

    private fun cleanModelText(raw: String): String {
        var s = raw
            .replace(Regex("```[a-z]*\\n?"), "")
            .replace("```", "")
            .replace(Regex("[\\u2018\\u2019]"), "'")
            .replace(Regex("[\\u201C\\u201D]"), "\"")
            .trim()

        val narration = listOf(
            Regex("^[Tt]he (image|handwriting|note|user('s)? writing|text)[^.]*?(reads?|shows?|says?|contains?|is|displays?)[^.]*?[.\\n]"),
            Regex("^[Ii] (can )?see[^.]*?[.\\n]"),
            Regex("^[Ii]t (looks like|appears|seems)[^.]*?[.\\n]"),
            Regex("^[Tt]he user (has )?(wrote|written|asked)[^.]*?[.\\n]"),
            Regex("^[Tt]his (is|appears to be|looks like)[^.]*?[.\\n]"),
            Regex("^[Tt]he handwritten[^.]*?[.\\n]"),
            Regex("^[Tt]he (image|handwriting|note|text)[^:]*?:\\s*"),
            Regex("^[Pp]lease (provide|share|give|send|write)[^.]*?[.\\n]"),
            Regex("^[Ii] (don't|do not|cannot|can't) (see|read|find)[^.]*?[.\\n]"),
            Regex("^[Tt]here (is no|are no|isn't any)[^.]*?[.\\n]"),
            Regex("^[Cc]ould you (please )?(provide|share|give)[^.]*?[.\\n]"),
            Regex("^[Ii] need[^.]*?[.\\n]"),
        )
        var changed = true
        while (changed) {
            changed = false
            for (re in narration) {
                val match = re.find(s)
                if (match != null && match.range.first == 0) {
                    s = s.substring(match.range.last + 1).trimStart()
                    changed = true
                    break
                }
            }
        }
        if (s.length > 2 && s.startsWith('"') && s.endsWith('"')) s = s.substring(1, s.length - 1)
        if (s.length > 2 && s.startsWith('\'') && s.endsWith('\'')) s = s.substring(1, s.length - 1)

        return s
            .lines()
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .joinToString("\n")
            .take(180) // a bit shorter — replies need to fit handwritten on a page
            .ifBlank { raw.trim().take(180) }
    }
}

/** Color hint exported for any UI using AI ink colour. */
internal val AiInkColor: Color get() = AiInk

/** Anchor offset used by the screen to start writing the AI reply. */
fun pickAiAnchor(page: NotebookPage): Offset {
    val userStrokes = page.strokes.filter { it.origin == StrokeOrigin.USER }
    if (userStrokes.isEmpty()) {
        // Top-left margin if nothing's there yet.
        return Offset(80f, 100f)
    }
    val maxY = userStrokes.maxOf { it.maxY }
    val minX = userStrokes.minOf { it.minX }
    val left = minX.coerceAtLeast(80f)
    val below = maxY + 64f
    // If we're near the bottom of the page, fall back to the page-bottom margin.
    val safeY = below.coerceAtMost(SlateState.PAGE_HEIGHT - 200f)
    return Offset(left, safeY)
}

/** Estimate user's writing height for matching AI font size. */
fun estimateLineHeight(page: NotebookPage): Float {
    val userPenStrokes = page.strokes
        .filter { it.origin == StrokeOrigin.USER && it.mode == PenMode.PEN }
        .takeLast(40)
    if (userPenStrokes.isEmpty()) return 44f
    val heights = userPenStrokes
        .map { (it.maxY - it.minY).coerceAtLeast(0f) }
        .filter { it in 8f..220f }
    if (heights.isEmpty()) return 44f
    val sorted = heights.sorted()
    return sorted[sorted.size / 2].coerceIn(28f, 80f)
}
