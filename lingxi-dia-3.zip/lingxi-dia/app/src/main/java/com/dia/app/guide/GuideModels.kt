package com.dia.app.guide

import android.graphics.RectF

/** One instruction the user should perform. */
data class GuideStep(
    val stepNumber: Int,
    val totalSteps: Int,
    val action: GuideAction,
    /** Screen bounds of the target, if resolvable. */
    val targetBounds: RectF?,
    /** Short label of the target (text / content-desc / hint). */
    val targetLabel: String,
    /** Friendly caption shown to the user and spoken via TTS. */
    val caption: String,
    /** Optional short text the user should type, when action=TYPE. */
    val textToType: String? = null,
)

enum class GuideAction {
    TAP, LONG_PRESS, TYPE, SCROLL, SWIPE, WAIT, DONE
}

/** Running state of the guide. */
enum class GuideState {
    IDLE,       // No active tutorial
    ANALYZING,  // Planning steps
    GUIDING,    // Showing pointer / caption
    PAUSED,     // User paused
    COMPLETE,   // Tutorial finished
}

/** A planned tutorial — a sequence of steps for a user question. */
data class Guide(
    val id: String,
    val question: String,
    val appPackage: String?,
    val steps: List<GuideStep>,
)
