package com.dia.app.pilot.tool.impl

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Rect
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.accessibility.AccessibilityNodeInfo
import com.dia.app.DiaAccessibilityService
import com.dia.app.pilot.tool.BaseTool
import com.dia.app.pilot.tool.ToolParameter
import com.dia.app.pilot.tool.ToolResult
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Resilient text input.
 *
 * Resolution order for the target field (first non-null wins):
 *   1. If `node_id` is given, tap its coords to focus, then use the live
 *      cached node directly. Many apps (YouTube, Reddit) expose their search
 *      field via a node that is not yet marked editable until it's tapped.
 *   2. The live `findFocus(FOCUS_INPUT)` result — trusted unconditionally,
 *      matching the old working behaviour.
 *   3. The closest editable/EditText-class node to the tap point.
 *   4. The first editable / EditText-class / SearchView / TextField node
 *      found anywhere in the tree.
 *
 * Once we have a candidate we try ACTION_SET_TEXT (with retries). If that
 * still fails we fall back to clipboard + ACTION_PASTE.
 */
class InputTextTool : BaseTool() {
    companion object { private const val TAG = "InputTextTool" }

    override fun getName(): String = "input_text"

    override fun getDescription(): String =
        "Type text into a field. Auto-presses Enter after typing by default. " +
            "Set submit=false to type without submitting."

    override fun getParameters(): List<ToolParameter> = listOf(
        ToolParameter("text", "string", "Text to input", true),
        ToolParameter("node_id", "string", "Optional node ID to focus first", false),
        ToolParameter("clear_first", "boolean", "Clear existing text (default true)", false),
        ToolParameter("submit", "boolean", "Press Enter after typing (default TRUE — submit by default)", false),
    )

    override fun execute(params: Map<String, Any>): ToolResult {
        val service = requireAccessibilityService()
            ?: return ToolResult.error("Accessibility service is not running")

        val text = requireString(params, "text")
        val nodeId = extractNodeId(optionalString(params, "node_id", ""))
        val clearFirst = optionalBoolean(params, "clear_first", true)
        // Default submit=true — most type actions in tasks are searches that
        // need to be submitted. The model often forgets to pass it.
        val submit = optionalBoolean(params, "submit", true)

        var targetCoords: IntArray? = null
        var cachedNode: AccessibilityNodeInfo? = null

        if (nodeId.isNotBlank()) {
            cachedNode = service.getNodeById(nodeId)
            targetCoords = service.getNodeCoordinates(nodeId)
            if (targetCoords != null) {
                service.performTap(targetCoords[0], targetCoords[1])
                sleep(450) // let focus + IME settle
            }
        }

        // Strategy A: try the cached node we tapped. Many fields only expose
        // themselves as editable AFTER they're focused.
        if (cachedNode != null) {
            try { cachedNode.performAction(AccessibilityNodeInfo.ACTION_FOCUS) } catch (_: Exception) {}
            try { cachedNode.performAction(AccessibilityNodeInfo.ACTION_CLICK) } catch (_: Exception) {}
            if (clearFirst) clearNodeText(cachedNode)
            if (trySetText(cachedNode, text, clearFirst)) {
                if (submit) { sleep(180); service.performImeEnter() }
                return ToolResult.success("Typed: ${text.take(80)}")
            }
        }

        // Strategy B / C / D: resolve a live candidate from the current tree.
        val candidates = resolveCandidates(service, targetCoords)
        if (candidates.isEmpty()) {
            return ToolResult.error("No editable field found. Tap the search bar first, then retry input_text.")
        }

        Log.d(TAG, "Candidates: ${candidates.size} (first class=${candidates.first().className})")

        for (node in candidates) {
            try { node.performAction(AccessibilityNodeInfo.ACTION_FOCUS) } catch (_: Exception) {}
            try { node.performAction(AccessibilityNodeInfo.ACTION_CLICK) } catch (_: Exception) {}
            if (clearFirst) clearNodeText(node)
            if (trySetText(node, text, clearFirst)) {
                if (submit) { sleep(180); service.performImeEnter() }
                return ToolResult.success("Typed: ${text.take(80)}")
            }
            // Clipboard paste for this candidate.
            if (pasteIntoNode(service, node, text, clearFirst)) {
                if (submit) { sleep(180); service.performImeEnter() }
                return ToolResult.success("Typed (paste): ${text.take(80)}")
            }
        }

        return ToolResult.error("Failed to input text — tried ${candidates.size} candidate field(s)")
    }

    // ─── Candidate resolution ──────────────────────────────────────────────

    private fun resolveCandidates(
        service: DiaAccessibilityService,
        targetCoords: IntArray?,
    ): List<AccessibilityNodeInfo> {
        val result = LinkedHashMap<String, AccessibilityNodeInfo>() // de-dup by identity key

        fun add(node: AccessibilityNodeInfo?) {
            if (node == null) return
            val key = System.identityHashCode(node).toString()
            if (!result.containsKey(key)) result[key] = node
        }

        // Poll up to ~1.2 s — tapping the search bar in big apps like YouTube
        // sometimes takes two frames to produce a focused input.
        repeat(6) { iter ->
            val root = service.rootInActiveWindow ?: run { sleep(200); return@repeat }

            // (B) findFocus — trusted, like the old behaviour.
            try {
                val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
                if (focused != null) add(focused)
            } catch (_: Exception) {}

            // (B2) accessibility-focused node (screen readers sometimes use this).
            try {
                val a11y = root.findFocus(AccessibilityNodeInfo.FOCUS_ACCESSIBILITY)
                if (a11y != null && (a11y.isEditable || isInputClass(a11y))) add(a11y)
            } catch (_: Exception) {}

            // (C) editable / EditText near the tap point.
            if (targetCoords != null) {
                val near = findEditableNearPoint(root, targetCoords[0], targetCoords[1])
                if (near != null) add(near)
            }

            // (D) all editables / EditText / SearchView / TextField nodes on screen.
            collectInputs(root, result)

            if (result.isNotEmpty()) return@repeat
            sleep(200)
        }

        // Final pass: if somehow still empty, tolerate *anything* focusable with
        // text capability — last-resort, better than "no editable field found".
        if (result.isEmpty()) {
            val root = service.rootInActiveWindow
            if (root != null) {
                collectFocusableText(root, result)
            }
        }

        // Order: focused first, then near-tap, then the rest.
        return result.values.toList()
    }

    private fun collectInputs(node: AccessibilityNodeInfo, out: MutableMap<String, AccessibilityNodeInfo>) {
        try {
            if (node.isEditable || isInputClass(node)) {
                val key = System.identityHashCode(node).toString()
                out.putIfAbsent(key, node)
            }
            for (i in 0 until node.childCount) {
                val child = node.getChild(i) ?: continue
                collectInputs(child, out)
            }
        } catch (_: Exception) {}
    }

    private fun collectFocusableText(node: AccessibilityNodeInfo, out: MutableMap<String, AccessibilityNodeInfo>) {
        try {
            val cls = node.className?.toString().orEmpty()
            val looksLikeField = cls.contains("Text", true) || cls.contains("Input", true) ||
                cls.contains("Search", true) || cls.contains("Field", true)
            if (node.isFocusable && looksLikeField) {
                val key = System.identityHashCode(node).toString()
                out.putIfAbsent(key, node)
            }
            for (i in 0 until node.childCount) {
                val child = node.getChild(i) ?: continue
                collectFocusableText(child, out)
            }
        } catch (_: Exception) {}
    }

    private fun isInputClass(node: AccessibilityNodeInfo): Boolean {
        val cls = node.className?.toString().orEmpty()
        return cls.contains("EditText", ignoreCase = true) ||
            cls.contains("AutoComplete", ignoreCase = true) ||
            cls.contains("SearchView", ignoreCase = true) ||
            cls.contains("SearchBar", ignoreCase = true) ||
            cls.contains("SearchField", ignoreCase = true) ||
            cls.contains("TextField", ignoreCase = true) ||
            cls.contains("TextInput", ignoreCase = true) ||
            cls.contains("MultiAutoCompleteTextView", ignoreCase = true)
    }

    private fun findEditableNearPoint(node: AccessibilityNodeInfo, x: Int, y: Int): AccessibilityNodeInfo? {
        val bounds = Rect().apply { node.getBoundsInScreen(this) }
        val isLikely = node.isEditable || isInputClass(node)
        if (isLikely && bounds.contains(x, y)) return node

        var best: AccessibilityNodeInfo? = null
        var bestDist = Int.MAX_VALUE
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val candidate = findEditableNearPoint(child, x, y) ?: continue
            val cb = Rect().apply { candidate.getBoundsInScreen(this) }
            val dx = cb.centerX() - x
            val dy = cb.centerY() - y
            val d = dx * dx + dy * dy
            if (d < bestDist) { bestDist = d; best = candidate }
        }
        return best
    }

    // ─── Text-entry strategies ─────────────────────────────────────────────

    private fun clearNodeText(node: AccessibilityNodeInfo) {
        try {
            val selArgs = Bundle().apply {
                putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, 0)
                putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, Int.MAX_VALUE)
            }
            node.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, selArgs)
            val clearArgs = Bundle().apply {
                putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, "")
            }
            node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, clearArgs)
        } catch (_: Exception) {}
    }

    private fun moveCursorToEnd(node: AccessibilityNodeInfo) {
        try {
            val end = node.text?.length ?: 0
            val args = Bundle().apply {
                putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, end)
                putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, end)
            }
            node.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, args)
        } catch (_: Exception) {}
    }

    private fun trySetText(node: AccessibilityNodeInfo, text: String, clearFirst: Boolean): Boolean {
        for (attempt in 0 until 3) {
            try {
                val existing = node.text
                val candidate = if (clearFirst) text else ((existing?.toString() ?: "") + text)
                val args = Bundle().apply {
                    putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, candidate)
                }
                if (node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) return true
            } catch (_: Exception) {}
            sleep(180)
            try { node.performAction(AccessibilityNodeInfo.ACTION_FOCUS) } catch (_: Exception) {}
            try { node.performAction(AccessibilityNodeInfo.ACTION_CLICK) } catch (_: Exception) {}
        }
        return false
    }

    private fun pasteIntoNode(
        service: DiaAccessibilityService,
        node: AccessibilityNodeInfo,
        text: String,
        clearFirst: Boolean,
    ): Boolean {
        if (!setClipboardText(service.applicationContext, text)) return false
        if (clearFirst) clearNodeText(node) else moveCursorToEnd(node)
        return try {
            node.performAction(AccessibilityNodeInfo.ACTION_PASTE)
        } catch (_: Exception) { false }
    }

    private fun setClipboardText(context: Context, text: String): Boolean {
        val latch = CountDownLatch(1)
        val ok = booleanArrayOf(false)
        Handler(Looper.getMainLooper()).post {
            try {
                val cb = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cb.setPrimaryClip(ClipData.newPlainText("pilot_input", text))
                ok[0] = true
            } catch (_: Exception) {}
            latch.countDown()
        }
        return try {
            latch.await(2, TimeUnit.SECONDS)
            ok[0]
        } catch (_: Exception) { false }
    }

    private fun sleep(ms: Long) {
        try { Thread.sleep(ms) } catch (_: InterruptedException) { Thread.currentThread().interrupt() }
    }
}
