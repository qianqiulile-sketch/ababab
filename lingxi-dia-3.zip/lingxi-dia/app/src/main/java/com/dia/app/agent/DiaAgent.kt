package com.dia.app.agent

import android.graphics.Bitmap
import com.dia.app.files.FileRef
import com.dia.app.llm.AudioClip
import com.dia.app.llm.LlmGateway
import com.dia.app.memory.MemoryStore
import com.dia.app.prefs.DiaSettings
import com.dia.app.ui.chat.ChatMessage
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** 自循环里的角色设定。 */
data class Persona(val name: String, val other: String, val topic: String, val round: Int, val total: Int)

/** 一次回复的输入。 */
data class AgentRequest(
    /** 之前的对话（不含本次用户消息） */
    val history: List<ChatMessage>,
    /** 本次用户消息（自循环时为空） */
    val userText: String,
    val hiddenContext: String? = null,
    val images: List<Bitmap> = emptyList(),
    val audio: List<AudioClip> = emptyList(),
    /** 本次消息附带的文件 */
    val files: List<FileRef> = emptyList(),
    val thinking: Boolean = false,
    val persona: Persona? = null,
    /** 强制先执行的工具（斜杠命令） */
    val forcedTool: Pair<String, JSONObject>? = null,
)

/** Agent 运行中向界面汇报的事件。 */
interface AgentListener : ToolHost {
    /** 当前回复的可见文本（整段替换） */
    fun onText(text: String)
    fun onThought(delta: String)
    /** 开始一个工具调用：返回卡片 id */
    fun onToolStart(name: String, title: String): String
    fun onToolEnd(cardId: String, outcome: ToolOutcome)
}

/**
 * 灵犀 Agent：让本地 / 云端模型以「提示词 + 工具调用」的方式工作。
 *
 * 每一步：拼提示词 → 模型输出 → 如果是 `<tool>{…}</tool>` 就执行工具，把结果写回
 * 「本轮工具记录」再问一次；否则就是最终回答。所有功能（搜索、翻译、文件、生图、
 * 操控手机、记忆…）都通过这一个对话入口互相组合，由 AI 自行决定调用。
 */
object DiaAgent {

    private const val NAME = "灵犀"

    fun systemPrompt(req: AgentRequest, tools: List<ToolSpec>, memories: List<String>): String {
        val now = SimpleDateFormat("yyyy年M月d日 EEEE HH:mm", Locale.CHINA).format(Date())
        val lang = DiaSettings.replyLanguage.value
        val sb = StringBuilder()
        val p = req.persona
        if (p != null) {
            sb.append("你正在参与一场「自我对话」。你扮演「${p.name}」，对方是「${p.other}」（也是 AI）。\n")
            sb.append("讨论主题：${p.topic}\n")
            sb.append("要求：针对对方上一段发言回应并推进讨论，可以追问、补充、反驳或总结；每次 80～200 字；不要重复已说过的内容；不要自称 AI 助手。\n")
            sb.append("如果对话记录里出现【用户插话】，必须优先回应用户的新信息或新要求。\n")
            sb.append("现在是第 ${p.round}/${p.total} 轮。")
            if (p.round >= p.total) sb.append("这是最后一轮，请做个收尾总结。")
            sb.append("\n当前时间：$now。使用$lang。\n")
        } else {
            sb.append("你是「$NAME」（Dia），运行在用户手机上的中文 AI 助手，亲切、可靠、简洁。\n")
            sb.append("当前时间：$now。默认使用$lang 回答，除非用户要求其他语言。善用 Markdown（列表、加粗、代码块）。\n")
        }
        if (memories.isNotEmpty()) {
            sb.append("\n【关于用户的记忆】（自然地利用，不要生硬复述）\n")
            for (m in memories) sb.append("- ").append(m).append('\n')
        }
        if (tools.isNotEmpty()) {
            sb.append("\n【工具】需要时调用。调用方法：只输出一行\n<tool>{\"name\":\"工具名\",\"args\":{参数}}</tool>\n")
            sb.append("不要输出其它文字，系统会执行并把【工具结果】告诉你，然后你再回答。不需要工具就直接回答。\n")
            for (t in tools) {
                sb.append("- ").append(t.name).append(' ').append(t.args).append("：").append(t.desc)
                if (t.needsConfirm) sb.append("（会请用户确认）")
                sb.append('\n')
            }
            sb.append("规则：\n")
            sb.append("1. 涉及最新信息（新闻、天气、价格、版本、比赛、汇率等）或你不确定的事实，先 web_search。\n")
            sb.append("2. 用户要求修改/新建/下载文件或操作手机时，必须调用对应工具，不要假装已经完成。\n")
            sb.append("3. 文件用 id（如 f1）指代。改文件前如不清楚原文，先 read_file。\n")
            sb.append("4. 一次只调用一个工具；拿到结果后根据结果回答，引用搜索结果时标注 [序号]。\n")
            sb.append("5. 用户说「画/生成一张图」用 generate_image；说「记住…」用 remember。\n")
        }
        return sb.toString()
    }

    private fun roleName(m: ChatMessage, persona: Persona?): String = when {
        m.isUser -> if (persona != null) "【用户插话】" else "用户"
        m.persona != null -> m.persona
        else -> NAME
    }

    /** 把历史压缩成文本，从最新往前取，直到用完预算。 */
    fun historyText(history: List<ChatMessage>, budget: Int, persona: Persona?): String {
        val lines = ArrayList<String>()
        var used = 0
        for (m in history.asReversed()) {
            val line = when (m.kind) {
                ChatMessage.KIND_NOTE -> null
                ChatMessage.KIND_TOOL -> "（$NAME 调用了 ${m.title ?: m.toolName}${if (m.status == "error") "，失败" else ""}）"
                ChatMessage.KIND_CONFIRM -> "（请求用户确认：${m.title}，结果：${if (m.status == "approved") "同意" else "拒绝"}）"
                ChatMessage.KIND_IMAGE -> "（$NAME 生成了一张图片${m.detail?.let { "，$it" }.orEmpty()}）"
                else -> {
                    if (m.isError || (m.text.isBlank() && m.imagePaths.isEmpty() && m.fileNames.isEmpty())) null
                    else {
                        val extra = buildString {
                            if (m.imagePaths.isNotEmpty() && m.isUser) append("［发送了${m.imagePaths.size}张图片］")
                            if (m.fileNames.isNotEmpty()) append("［附件：${m.fileIds.zip(m.fileNames).joinToString("、") { "${it.first}《${it.second}》" }}］")
                        }
                        val body = m.text.let { if (it.length > 800) it.take(800) + "…" else it }
                        "${roleName(m, persona)}：$extra$body"
                    }
                }
            } ?: continue
            if (used + line.length > budget) {
                if (lines.isEmpty() && budget > 200) lines.add(line.take(budget - 20) + "…")
                break
            }
            lines.add(line)
            used += line.length + 1
        }
        return lines.asReversed().joinToString("\n")
    }

    /**
     * 运行一次回复。返回最终可见文本（已展示的工具卡片不在其中）。
     */
    suspend fun run(req: AgentRequest, listener: AgentListener): String {
        val toolNames = if (DiaSettings.agentTools.value || req.forcedTool != null) AgentTools.enabledNames(req.persona != null) else emptySet()
        val tools = AgentTools.ALL.filter { it.name in toolNames }
        val maxSteps = if (tools.isEmpty()) 0 else DiaSettings.maxToolSteps.value.coerceIn(1, 8)

        val memItems = if (DiaSettings.memoryEnabled.value && req.persona == null) {
            MemoryStore.relevant(req.userText + " " + req.history.takeLast(2).joinToString(" ") { it.text.take(100) })
        } else emptyList()
        if (memItems.isNotEmpty()) MemoryStore.markUsed(memItems.map { it.id })
        val system = systemPrompt(req, tools, memItems.map { it.content })

        val budget = (LlmGateway.promptCharBudget() - system.length).coerceAtLeast(800)
        val scratch = StringBuilder()
        var images = req.images

        // 本次附带的文件：直接把开头内容放进提示词，小模型不必再调用 read_file
        val filesBlock = StringBuilder()
        if (req.files.isNotEmpty()) {
            val perFile = (budget * 0.4 / req.files.size).toInt().coerceIn(400, 6000)
            for (f in req.files) {
                filesBlock.append("文件 ${f.id}《${f.name}》（${f.kind}）")
                try {
                    val r = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                        com.dia.app.files.FileManager.read(f, 0, perFile)
                    }
                    if (r.text.isNotBlank()) {
                        filesBlock.append("内容").append(if (r.totalChars > r.text.length) "（前 ${r.text.length}/${r.totalChars} 字，可用 read_file 继续读）" else "").append("：\n")
                        filesBlock.append(r.text).append("\n\n")
                    } else {
                        filesBlock.append("：").append(r.note.ifBlank { "无法直接提取文字，可调用 read_file 读取。" }).append("\n\n")
                    }
                } catch (e: Exception) {
                    filesBlock.append("：读取失败（${e.message}）\n\n")
                }
            }
        }

        var forced = req.forcedTool
        var step = 0
        var lastShownToUser = false
        while (true) {
            // 强制工具（斜杠命令）先执行
            if (forced != null) {
                val (fname, fargs) = forced
                forced = null
                val outcome = runTool(fname, fargs, listener)
                appendScratch(scratch, fname, fargs, outcome)
                lastShownToUser = outcome.shownToUser
                if (outcome.images.isNotEmpty()) images = images + outcome.images
                step++
                continue
            }

            val canUseTools = tools.isNotEmpty() && step < maxSteps
            val prompt = buildPrompt(req, budget, filesBlock.toString(), scratch.toString(), canUseTools, lastShownToUser)

            var full = ""
            listener.onText("")
            val output = LlmGateway.complete(
                system = system,
                prompt = prompt,
                images = images,
                audio = if (step == 0) req.audio else emptyList(),
                temperature = if (req.persona != null) 0.8 else 0.6,
                thinking = req.thinking,
            ) { delta, thought ->
                if (thought != null) listener.onThought(thought)
                if (delta.isNotEmpty()) {
                    full += delta
                    val visible = ToolCallParser.visibleText(full)
                    if (!(tools.isNotEmpty() && ToolCallParser.mightBeCall(full))) listener.onText(stripInlineThink(visible))
                }
            }
            full = output.ifEmpty { full }

            val raw = if (canUseTools) ToolCallParser.findRaw(full) else null
            val call = raw?.let { parseCall(it.json) }
            if (call == null || call.first !in toolNames) {
                val finalText = stripInlineThink(ToolCallParser.visibleText(full)).trim()
                    .ifBlank { if (raw != null) "（模型想调用一个不可用的工具，已忽略）" else "" }
                listener.onText(finalText)
                return finalText
            }
            // 是工具调用：清空流式文本，执行工具
            listener.onText("")
            val (name, args) = call
            val outcome = runTool(name, args, listener)
            appendScratch(scratch, name, args, outcome)
            lastShownToUser = outcome.shownToUser
            if (outcome.images.isNotEmpty()) images = images + outcome.images
            step++
        }
    }

    private suspend fun runTool(name: String, args: JSONObject, listener: AgentListener): ToolOutcome {
        val card = listener.onToolStart(name, AgentTools.cardTitle(name, args))
        val outcome = AgentTools.execute(name, args, listener)
        listener.onToolEnd(card, outcome)
        return outcome
    }

    private fun appendScratch(sb: StringBuilder, name: String, args: JSONObject, outcome: ToolOutcome) {
        val limit = 3500
        val res = outcome.forModel.let { if (it.length > limit) it.take(limit) + "…（已截断）" else it }
        sb.append("<tool>{\"name\":\"").append(name).append("\",\"args\":").append(args.toString()).append("}</tool>\n")
        sb.append("【工具结果 ").append(name).append(if (outcome.ok) "" else "（失败）").append("】\n").append(res).append("\n\n")
    }

    private fun buildPrompt(
        req: AgentRequest,
        budget: Int,
        filesBlock: String,
        scratch: String,
        canUseTools: Boolean,
        shownToUser: Boolean,
    ): String {
        val current = if (req.persona == null) {
            buildString {
                append("用户：")
                if (req.images.isNotEmpty()) append("［发送了${req.images.size}张图片，见上方］")
                if (req.audio.isNotEmpty()) append("［发送了一段语音，请先听懂再回答］")
                append(req.userText)
                if (!req.hiddenContext.isNullOrBlank()) append("\n\n【附带上下文】\n").append(req.hiddenContext.take(budget / 3))
            }
        } else ""
        // 预算分配：当前消息 > 工具记录 > 文件 > 历史
        val scratchPart = if (scratch.length > budget / 2) scratch.takeLast(budget / 2) else scratch
        val filesPart = if (filesBlock.length > budget * 2 / 5) filesBlock.take(budget * 2 / 5) else filesBlock
        val remain = (budget - current.length - scratchPart.length - filesPart.length - 200).coerceAtLeast(300)
        val history = historyText(req.history, remain, req.persona)

        return buildString {
            if (history.isNotBlank()) append("【对话记录】\n").append(history).append("\n\n")
            if (filesPart.isNotBlank()) append("【本次附带的文件】\n").append(filesPart).append("\n")
            if (req.persona == null) {
                append("【当前消息】\n").append(current).append("\n\n")
            } else {
                val p: Persona = req.persona
                append("请以「${p.name}」的身份发言")
                if (history.isBlank()) append("，先提出你对主题「${p.topic}」的第一个观点或问题")
                append("。\n\n")
            }
            if (scratchPart.isNotBlank()) {
                append("【本轮工具记录】\n").append(scratchPart)
                when {
                    shownToUser -> append("工具结果已经展示给用户了，请用一两句话简短收尾，不要重复内容。\n")
                    canUseTools -> append("请根据工具结果回答用户；确实还需要信息才再调用一个工具。\n")
                    else -> append("不要再调用工具，请直接根据以上结果给出最终回答。\n")
                }
            } else if (!canUseTools && req.persona == null) {
                // 无工具时无需额外提示
            }
            val speaker = req.persona?.name ?: NAME
            append("$speaker：")
        }
    }

    private fun parseCall(json: String): Pair<String, JSONObject>? = try {
        val o = JSONObject(json)
        val name = o.optString("name").ifBlank { o.optString("tool") }.ifBlank { o.optString("function") }.trim()
        if (name.isBlank()) null else {
            val args = o.optJSONObject("args") ?: o.optJSONObject("arguments") ?: o.optJSONObject("params")
                ?: o.optJSONObject("parameters") ?: o.optString("arguments").takeIf { it.startsWith("{") }?.let { JSONObject(it) }
                ?: JSONObject().also { a ->
                    // 参数直接平铺在顶层的情况
                    val keys = o.keys()
                    while (keys.hasNext()) {
                        val k = keys.next()
                        if (k != "name" && k != "tool" && k != "function") a.put(k, o.get(k))
                    }
                }
            name to args
        }
    } catch (_: Exception) {
        null
    }

    /** 去掉部分量化模型会漏出的 `<think>…</think>`。 */
    private fun stripInlineThink(s: String): String {
        var t = s.replace(Regex("<think>[\\s\\S]*?</think>"), "")
        val open = t.indexOf("<think>")
        if (open >= 0) t = t.substring(0, open)
        return t.trimStart()
    }
}
