package com.dia.app.agent

import android.content.Context
import android.graphics.Bitmap
import android.util.Log
import com.dia.app.DiaAccessibilityService
import com.dia.app.files.FileManager
import com.dia.app.imagegen.ImageGen
import com.dia.app.llm.LlmGateway
import com.dia.app.memory.MemoryStore
import com.dia.app.pilot.PilotAgent
import com.dia.app.pilot.PilotEvent
import com.dia.app.prefs.DiaSettings
import com.dia.app.web.WebDownloader
import com.dia.app.web.WebReader
import com.dia.app.web.WebSearch
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject

/** 一个工具的说明（会写进系统提示词）。 */
data class ToolSpec(
    val name: String,
    val title: String,
    val args: String,
    val desc: String,
    val needsConfirm: Boolean = false,
)

/** 工具执行结果。 */
data class ToolOutcome(
    /** 给模型看的结果 */
    val forModel: String,
    /** 卡片上显示的结果（可展开） */
    val display: String = forModel,
    val ok: Boolean = true,
    /** 结果已直接展示给用户（例如长篇译文），模型只需简单收尾 */
    val shownToUser: Boolean = false,
    /** 生成的图片路径 */
    val imagePath: String? = null,
    /** 需要模型进一步“看”的图片（如扫描版 PDF 页面） */
    val images: List<Bitmap> = emptyList(),
)

/** 工具执行时与界面交互的接口（由 ChatController 实现）。 */
interface ToolHost {
    val context: Context
    /** 弹出确认卡片，等待用户点「同意 / 拒绝」。 */
    suspend fun confirm(title: String, detail: String): Boolean
    /** 更新当前工具卡片的进度文字。 */
    fun progress(text: String)
    /** 需要把灵犀退到后台（例如框选屏幕翻译）。 */
    fun moveAppToBack()
}

object AgentTools {

    private const val TAG = "AgentTools"

    val ALL: List<ToolSpec> = listOf(
        ToolSpec("web_search", "联网搜索", "{\"query\":\"搜索词\"}", "搜索互联网获取最新信息（新闻、价格、天气、百科、教程等）"),
        ToolSpec("read_webpage", "读取网页", "{\"url\":\"网址\"}", "打开网页并读取正文"),
        ToolSpec("download", "下载文件", "{\"url\":\"文件网址\",\"filename\":\"可选文件名\"}", "把网上的文件下载到手机「下载/Dia」目录", needsConfirm = true),
        ToolSpec("read_file", "读取文件", "{\"file\":\"文件id或路径\",\"offset\":0}", "读取已附加的本地文件（Word/PPT/Excel/PDF/文本），offset 用于继续往后读"),
        ToolSpec("list_files", "浏览目录", "{\"dir\":\"Download\"}", "列出手机某个目录里的文件"),
        ToolSpec("edit_file", "修改文件", "{\"file\":\"f1\",\"action\":\"replace|append|rewrite\",\"find\":\"原文\",\"text\":\"新内容\"}", "修改本地文件：replace 替换文字、append 末尾追加、rewrite 全文重写。修改前自动备份", needsConfirm = true),
        ToolSpec("create_file", "新建文件", "{\"name\":\"文件名\",\"content\":\"内容\",\"format\":\"docx|txt|md\"}", "在「下载/Dia」新建文档", needsConfirm = true),
        ToolSpec("restore_file", "还原文件", "{\"file\":\"f1\"}", "把文件还原到最近一次修改前的备份", needsConfirm = true),
        ToolSpec("translate", "翻译", "{\"text\":\"要翻译的内容\",\"to\":\"目标语言\"}", "翻译文字；也可用 {\"file\":\"f1\",\"to\":\"英文\"} 翻译整个文件"),
        ToolSpec("translate_screen", "翻译屏幕", "{}", "让用户在屏幕上框选区域进行翻译（会切到后台）"),
        ToolSpec("generate_image", "生成图片", "{\"prompt\":\"画面描述\",\"size\":\"1024x1024\"}", "用生图 AI 画图"),
        ToolSpec("open_app", "打开应用", "{\"name\":\"应用名\"}", "打开手机上的某个应用"),
        ToolSpec("phone_task", "操控手机", "{\"task\":\"任务描述\"}", "自动在手机上点击 / 输入完成任务，例如“打开微信给张三发消息说晚点到”", needsConfirm = true),
        ToolSpec("guide", "屏幕引导", "{\"question\":\"想做什么\"}", "在屏幕上一步步指引用户操作某个应用"),
        ToolSpec("remember", "写入记忆", "{\"content\":\"要记住的事\",\"category\":\"偏好\"}", "把关于用户的重要信息记到长期记忆"),
        ToolSpec("forget", "删除记忆", "{\"keyword\":\"关键词\"}", "删除包含关键词的记忆"),
    )

    fun spec(name: String): ToolSpec? = ALL.firstOrNull { it.name == name }

    /** 根据设置决定本轮开放哪些工具。 */
    fun enabledNames(selfLoop: Boolean): Set<String> {
        if (selfLoop) {
            return if (DiaSettings.webEnabled.value) setOf("web_search", "read_webpage") else emptySet()
        }
        val out = LinkedHashSet<String>()
        for (t in ALL) out.add(t.name)
        if (!DiaSettings.webEnabled.value) out.removeAll(setOf("web_search", "read_webpage", "download"))
        if (!DiaSettings.memoryEnabled.value) out.removeAll(setOf("remember", "forget"))
        if (!FileManager.hasAllFilesAccess()) out.remove("list_files")
        return out
    }

    /** 卡片标题，例如「联网搜索：今天北京天气」。 */
    fun cardTitle(name: String, args: JSONObject): String {
        val t = spec(name)?.title ?: name
        val key = when (name) {
            "web_search" -> args.optString("query")
            "read_webpage", "download" -> args.optString("url")
            "read_file", "edit_file", "restore_file" -> FileManager.find(args.optString("file"))?.name ?: args.optString("file")
            "create_file" -> args.optString("name")
            "translate" -> args.optString("text").ifBlank { FileManager.find(args.optString("file"))?.name.orEmpty() }
            "generate_image" -> args.optString("prompt")
            "open_app" -> args.optString("name")
            "phone_task" -> args.optString("task")
            "guide" -> args.optString("question")
            "remember" -> args.optString("content")
            "forget" -> args.optString("keyword")
            "list_files" -> args.optString("dir")
            else -> ""
        }.take(40)
        return if (key.isBlank()) t else "$t：$key"
    }

    private fun str(a: JSONObject, vararg keys: String): String {
        for (k in keys) {
            val v = a.opt(k)
            if (v != null && v != JSONObject.NULL && v.toString().isNotBlank()) return v.toString().trim()
        }
        return ""
    }

    suspend fun execute(name: String, args: JSONObject, host: ToolHost): ToolOutcome = try {
        when (name) {
            "web_search" -> webSearch(str(args, "query", "q", "keyword", "text"), host)
            "read_webpage" -> readWeb(str(args, "url", "link"))
            "download" -> download(str(args, "url", "link"), str(args, "filename", "name"), host)
            "read_file" -> readFile(str(args, "file", "id", "path", "name"), args.optInt("offset", 0), host)
            "list_files" -> withContext(Dispatchers.IO) { ToolOutcome(FileManager.listDir(str(args, "dir", "path").ifBlank { null })) }
            "edit_file" -> editFile(args, host)
            "create_file" -> createFile(args, host)
            "restore_file" -> restoreFile(str(args, "file", "id", "name"), host)
            "translate" -> translate(args, host)
            "translate_screen" -> translateScreen(host)
            "generate_image" -> generateImage(str(args, "prompt", "description", "text"), str(args, "size"), host)
            "open_app" -> openApp(str(args, "name", "app", "app_name"), host)
            "phone_task" -> phoneTask(str(args, "task", "goal", "text"), host)
            "guide" -> guide(str(args, "question", "task", "goal"), host)
            "remember" -> remember(str(args, "content", "text", "memory"), str(args, "category").ifBlank { "其他" })
            "forget" -> forget(str(args, "keyword", "content", "text"))
            else -> ToolOutcome("没有名为 $name 的工具。可用工具：${ALL.joinToString(",") { it.name }}", ok = false)
        }
    } catch (e: kotlinx.coroutines.CancellationException) {
        throw e
    } catch (e: Exception) {
        Log.w(TAG, "$name failed", e)
        ToolOutcome("工具执行失败：${e.message ?: e.javaClass.simpleName}", ok = false)
    }

    // ───────── 联网 ─────────

    private suspend fun webSearch(query: String, host: ToolHost): ToolOutcome = withContext(Dispatchers.IO) {
        if (query.isBlank()) return@withContext ToolOutcome("缺少搜索词 query", ok = false)
        host.progress("正在搜索…")
        val r = WebSearch.search(query, 6)
        if (r.hits.isEmpty()) return@withContext ToolOutcome("搜索失败：${r.error}", ok = false)
        val sb = StringBuilder()
        for ((i, h) in r.hits.withIndex()) {
            sb.append("[${i + 1}] ${h.title}\n${h.url}\n${h.snippet}\n\n")
        }
        var forModel = sb.toString().trim()
        if (DiaSettings.deepSearch.value) {
            host.progress("正在阅读搜索结果网页…")
            val pages = StringBuilder()
            for (h in r.hits.take(2)) {
                try {
                    val p = WebReader.read(h.url, 1500)
                    if (p.text.isNotBlank()) pages.append("【${h.title}】\n${p.text}\n\n")
                } catch (_: Exception) { }
            }
            if (pages.isNotEmpty()) forModel += "\n\n=== 网页正文摘录 ===\n" + pages.toString().trim()
        }
        ToolOutcome(
            forModel = "（来自 ${r.engine} 的搜索结果，回答时可用 [序号] 标注来源）\n$forModel",
            display = sb.toString().trim(),
        )
    }

    private suspend fun readWeb(url: String): ToolOutcome = withContext(Dispatchers.IO) {
        if (url.isBlank()) return@withContext ToolOutcome("缺少网址 url", ok = false)
        val p = WebReader.read(url, 4000)
        val head = if (p.title.isNotBlank()) "标题：${p.title}\n" else ""
        ToolOutcome("${head}网址：${p.url}\n\n${p.text.ifBlank { "（网页没有可读的正文）" }}", display = "$head${p.text.take(1500)}")
    }

    private suspend fun download(url: String, filename: String, host: ToolHost): ToolOutcome {
        if (!url.startsWith("http")) return ToolOutcome("下载地址无效：$url", ok = false)
        val probe = withContext(Dispatchers.IO) { WebDownloader.probe(url, filename.ifBlank { null }) }
        val ok = host.confirm(
            "下载文件到手机？",
            "文件：${probe.fileName}\n大小：${WebDownloader.formatSize(probe.sizeBytes)}\n类型：${probe.mime ?: "未知"}\n来源：$url\n保存到：下载/Dia/",
        )
        if (!ok) return ToolOutcome("用户拒绝了下载。", ok = false)
        val id = WebDownloader.enqueue(host.context, probe)
        var status = "已开始下载"
        for (i in 0 until 10) {
            delay(1000)
            val (s, done) = WebDownloader.status(host.context, id)
            status = s
            host.progress(s)
            if (done) break
        }
        return ToolOutcome("已提交下载：${probe.fileName}，当前状态：$status。下载完成后在通知栏和「下载/Dia」里可以找到。")
    }

    // ───────── 文件 ─────────

    private suspend fun readFile(key: String, offset: Int, host: ToolHost): ToolOutcome {
        val ref = FileManager.find(key)
            ?: return ToolOutcome("找不到文件「$key」。请让用户点 ＋ →「文件」先选择文件。", ok = false)
        host.progress("正在读取 ${ref.name}…")
        val budget = (LlmGateway.promptCharBudget() / 2).coerceIn(1200, 12000)
        val r = withContext(Dispatchers.IO) { FileManager.read(ref, offset, budget) }
        if (r.text.isBlank() && r.images.isNotEmpty()) {
            host.progress("扫描版 PDF，正在识别文字…")
            val ocr = StringBuilder()
            for ((i, img) in r.images.withIndex()) {
                val t = LlmGateway.complete(
                    system = "你是 OCR 文字识别引擎。逐字输出图片中的全部文字，保持原有段落，不要解释。",
                    prompt = "识别这一页的文字：",
                    images = listOf(img),
                    temperature = 0.1,
                )
                ocr.append("【第${i + 1}页】\n").append(t.trim()).append("\n\n")
            }
            return ToolOutcome("${ref.name}（${r.note}）\n\n$ocr", display = ocr.toString().take(2000))
        }
        val end = offset + r.text.length
        val more = if (end < r.totalChars) "\n\n（全文共 ${r.totalChars} 字，当前显示 ${offset}–$end。需要继续请用 offset=$end）" else ""
        val note = if (r.note.isNotBlank()) "\n（${r.note}）" else ""
        val pages = if (r.pages > 0) "，共 ${r.pages} 页" else ""
        return ToolOutcome(
            "文件 ${ref.id}《${ref.name}》（${ref.kind}$pages）内容：\n${r.text}$more$note",
            display = r.text.take(1500) + if (r.text.length > 1500) "…" else "",
        )
    }

    private suspend fun editFile(args: JSONObject, host: ToolHost): ToolOutcome {
        val key = str(args, "file", "id", "path", "name")
        val ref = FileManager.find(key) ?: return ToolOutcome("找不到文件「$key」", ok = false)
        val action = str(args, "action", "mode").ifBlank { if (str(args, "find", "old").isNotBlank()) "replace" else "append" }.lowercase()
        val find = str(args, "find", "old", "from", "search")
        val text = args.optString("text", args.optString("new", args.optString("content", "")))
        val summary = withContext(Dispatchers.IO) { FileManager.previewEdit(ref, action, find, text) }
        val ok = host.confirm(
            "允许修改文件「${ref.name}」？",
            "$summary\n\n修改前会自动备份，随时可以在「备份还原」里恢复。",
        )
        if (!ok) return ToolOutcome("用户拒绝了这次修改，文件没有变化。", ok = false)
        val res = withContext(Dispatchers.IO) { FileManager.applyEdit(ref, action, find, text) }
        return ToolOutcome(res)
    }

    private suspend fun createFile(args: JSONObject, host: ToolHost): ToolOutcome {
        val name = str(args, "name", "filename", "title").ifBlank { "灵犀文档" }
        val content = args.optString("content", args.optString("text", ""))
        val format = str(args, "format", "type").ifBlank { if (name.endsWith(".docx")) "docx" else if (name.endsWith(".md")) "md" else "txt" }
        if (content.isBlank()) return ToolOutcome("缺少文件内容 content", ok = false)
        val ok = host.confirm(
            "新建文件「$name」？",
            "格式：$format\n长度：${content.length} 字\n保存到：下载/Dia/\n\n预览：${content.take(200)}${if (content.length > 200) "…" else ""}",
        )
        if (!ok) return ToolOutcome("用户取消了新建文件。", ok = false)
        val ref = withContext(Dispatchers.IO) { FileManager.createFile(name, content, format) }
        return ToolOutcome("已新建文件 ${ref.id}《${ref.name}》，保存在「下载/Dia」目录。")
    }

    private suspend fun restoreFile(key: String, host: ToolHost): ToolOutcome {
        val list = FileManager.backupsFor(key)
        val latest = list.firstOrNull() ?: return ToolOutcome("没有找到「$key」的备份。", ok = false)
        val ok = host.confirm(
            "还原文件「${latest.name}」？",
            "还原到：${FileManager.formatTime(latest.time)}（${latest.note}）\n当前版本会先自动备份。",
        )
        if (!ok) return ToolOutcome("用户取消了还原。", ok = false)
        val res = withContext(Dispatchers.IO) { FileManager.restore(latest.id) }
        return ToolOutcome(res)
    }

    // ───────── 翻译 ─────────

    private suspend fun translate(args: JSONObject, host: ToolHost): ToolOutcome {
        val to = str(args, "to", "target", "lang", "language").ifBlank { DiaSettings.translateTarget.value }
        var text = args.optString("text", "")
        val fileKey = str(args, "file")
        if (text.isBlank() && fileKey.isNotBlank()) {
            val ref = FileManager.find(fileKey) ?: return ToolOutcome("找不到文件「$fileKey」", ok = false)
            host.progress("正在读取 ${ref.name}…")
            text = withContext(Dispatchers.IO) { FileManager.read(ref, 0, 8000).text }
        }
        if (text.isBlank()) return ToolOutcome("缺少要翻译的内容", ok = false)
        val chunks = chunk(text, 1200)
        val out = StringBuilder()
        for ((i, c) in chunks.withIndex()) {
            if (chunks.size > 1) host.progress("翻译中 ${i + 1}/${chunks.size}…")
            val t = LlmGateway.complete(
                system = "你是专业翻译。把用户给出的内容翻译成$to。要求：准确、通顺、符合$to 的表达习惯；保留原有格式、换行和专有名词；只输出译文，不要解释，不要加引号。",
                prompt = c,
                temperature = 0.2,
            )
            out.append(t.trim()).append('\n')
        }
        val result = out.toString().trim()
        return if (result.length > 600) {
            ToolOutcome(
                forModel = "译文（共 ${result.length} 字）已完整展示给用户。开头：${result.take(300)}…\n请只用一两句话告诉用户翻译已完成，不要重复译文。",
                display = result,
                shownToUser = true,
            )
        } else {
            ToolOutcome("译文：\n$result", display = result)
        }
    }

    fun chunk(text: String, size: Int): List<String> {
        if (text.length <= size) return listOf(text)
        val out = ArrayList<String>()
        val sb = StringBuilder()
        for (line in text.split('\n')) {
            if (sb.length + line.length + 1 > size && sb.isNotEmpty()) {
                out.add(sb.toString()); sb.setLength(0)
            }
            if (line.length > size) {
                var i = 0
                while (i < line.length) { out.add(line.substring(i, minOf(line.length, i + size))); i += size }
            } else {
                sb.append(line).append('\n')
            }
        }
        if (sb.isNotEmpty()) out.add(sb.toString())
        return out
    }

    private fun translateScreen(host: ToolHost): ToolOutcome {
        if (!DiaAccessibilityService.isRunning()) {
            return ToolOutcome("需要先开启无障碍服务：设置 → 权限 → 无障碍，打开「灵犀 Dia」。", ok = false)
        }
        if (!com.dia.app.screen.QuickActionService.hasOverlayPermission(host.context)) {
            return ToolOutcome("需要“显示在其他应用上层”权限：设置 → 权限 → 悬浮窗。", ok = false)
        }
        host.moveAppToBack()
        com.dia.app.translate.ScreenTranslateService.start(
            host.context, com.dia.app.translate.ScreenTranslateService.Mode.TRANSLATE,
        )
        return ToolOutcome("已切到上一个应用，请在屏幕上框选要翻译的区域，结果会浮在屏幕上，也可以点「发到对话」带回来。", shownToUser = true)
    }

    // ───────── 生图 ─────────

    suspend fun generateImage(prompt: String, size: String, host: ToolHost): ToolOutcome {
        if (prompt.isBlank()) return ToolOutcome("缺少画面描述 prompt", ok = false)
        var finalPrompt = prompt
        val provider = DiaSettings.imageProvider.value
        if (DiaSettings.imagePromptTranslate.value && provider != "openai" && LlmGateway.isAvailable() &&
            prompt.any { it.code in 0x4E00..0x9FFF }
        ) {
            host.progress("正在润色提示词…")
            try {
                finalPrompt = LlmGateway.complete(
                    system = "把用户的中文画面描述改写成适合 Stable Diffusion / FLUX 的英文提示词：保留所有要素，补充画风、光线、构图等细节，用逗号分隔的短语，不超过 60 个词。只输出英文提示词。",
                    prompt = prompt,
                    temperature = 0.3,
                    timeoutMs = 60_000,
                ).trim().lines().firstOrNull { it.isNotBlank() }?.trim()?.trim('"')?.ifBlank { prompt } ?: prompt
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (_: Exception) {
                finalPrompt = prompt
            }
        }
        host.progress("${ImageGen.providerLabel(provider)} 正在作画…")
        val r = withContext(Dispatchers.IO) { ImageGen.generate(finalPrompt, size.ifBlank { null }) }
        return ToolOutcome(
            forModel = "图片已生成并展示给用户（提示词：$finalPrompt）。请用一句话简短说明画了什么。",
            display = "提示词：$finalPrompt",
            imagePath = r.path,
            shownToUser = true,
        )
    }

    // ───────── 手机操控 ─────────

    private val APP_ALIASES = mapOf(
        "微信" to "com.tencent.mm", "wechat" to "com.tencent.mm", "qq" to "com.tencent.mobileqq",
        "支付宝" to "com.eg.android.AlipayGphone", "淘宝" to "com.taobao.taobao", "抖音" to "com.ss.android.ugc.aweme",
        "京东" to "com.jingdong.app.mall", "美团" to "com.sankuai.meituan", "哔哩哔哩" to "tv.danmaku.bili",
        "b站" to "tv.danmaku.bili", "小红书" to "com.xingin.xhs", "高德地图" to "com.autonavi.minimap",
        "百度地图" to "com.baidu.BaiduMap", "微博" to "com.sina.weibo", "拼多多" to "com.xunmeng.pinduoduo",
        "网易云音乐" to "com.netease.cloudmusic", "钉钉" to "com.alibaba.android.rimet", "飞书" to "com.ss.android.lark",
    )

    private fun openApp(name: String, host: ToolHost): ToolOutcome {
        if (name.isBlank()) return ToolOutcome("缺少应用名", ok = false)
        val ctx = host.context
        val pm = ctx.packageManager
        val key = name.trim().lowercase()
        var pkg: String? = APP_ALIASES[key]?.takeIf { pm.getLaunchIntentForPackage(it) != null }
        if (pkg == null) {
            val main = android.content.Intent(android.content.Intent.ACTION_MAIN)
                .addCategory(android.content.Intent.CATEGORY_LAUNCHER)
            val apps = try { pm.queryIntentActivities(main, 0) } catch (_: Exception) { emptyList() }
            val labeled = apps.map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            pkg = labeled.firstOrNull { it.second.equals(name.trim(), true) }?.first
                ?: labeled.firstOrNull { it.second.contains(name.trim(), true) || name.contains(it.second, true) && it.second.length >= 2 }?.first
                ?: labeled.firstOrNull { it.first.contains(key) }?.first
        }
        val intent = pkg?.let { pm.getLaunchIntentForPackage(it) }
            ?: return ToolOutcome("没有找到名为「$name」的应用。", ok = false)
        intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(intent)
        return ToolOutcome("已打开「$name」。")
    }

    private suspend fun phoneTask(task: String, host: ToolHost): ToolOutcome {
        if (task.isBlank()) return ToolOutcome("缺少任务描述", ok = false)
        if (!DiaAccessibilityService.isRunning()) {
            return ToolOutcome("操控手机需要先开启无障碍服务：设置 → 权限 → 无障碍，打开「灵犀 Dia」。", ok = false)
        }
        if (PilotAgent.isRunning()) return ToolOutcome("已有一个手机任务正在执行，请稍后。", ok = false)
        val ok = host.confirm("允许灵犀操控手机？", "任务：$task\n\n灵犀会自动打开应用、点击和输入。执行中可在通知栏停止。")
        if (!ok) return ToolOutcome("用户拒绝了操控手机。", ok = false)
        PilotAgent.attach(host.context)
        return coroutineScope {
            val done = CompletableDeferred<String>()
            val steps = StringBuilder()
            val collector = launch(start = CoroutineStart.UNDISPATCHED) {
                PilotAgent.events.collect { e ->
                    when (e) {
                        is PilotEvent.Step -> { steps.append("· ").append(e.message).append('\n'); host.progress(e.message) }
                        is PilotEvent.ToolCall -> host.progress("执行：${e.name}")
                        is PilotEvent.Finished -> done.complete("完成：${e.summary}")
                        is PilotEvent.Failed -> done.complete("失败：${e.error}")
                        else -> Unit
                    }
                }
            }
            PilotAgent.start(task)
            val result = withTimeoutOrNull(5 * 60_000L) { done.await() } ?: run {
                PilotAgent.stop()
                "超时，已停止"
            }
            collector.cancel()
            ToolOutcome("手机任务「$task」$result", display = "$result\n\n过程：\n$steps".trim(), ok = !result.startsWith("失败"))
        }
    }

    private fun guide(question: String, host: ToolHost): ToolOutcome {
        if (question.isBlank()) return ToolOutcome("缺少引导问题", ok = false)
        if (!DiaAccessibilityService.isRunning()) return ToolOutcome("屏幕引导需要开启无障碍服务。", ok = false)
        if (!com.dia.app.guide.GuideOverlayService.hasOverlayPermission(host.context)) {
            return ToolOutcome("屏幕引导需要“显示在其他应用上层”权限。", ok = false)
        }
        com.dia.app.guide.GuideOverlayService.start(host.context, question)
        return ToolOutcome("已开始屏幕引导：$question。灵犀会在屏幕上一步步指示。", shownToUser = true)
    }

    // ───────── 记忆 ─────────

    private fun remember(content: String, category: String): ToolOutcome {
        if (content.isBlank()) return ToolOutcome("缺少要记住的内容", ok = false)
        val m = MemoryStore.add(content, category, source = "manual") ?: return ToolOutcome("内容太短，没有记录", ok = false)
        return ToolOutcome("已记住：${m.content}")
    }

    private fun forget(keyword: String): ToolOutcome {
        if (keyword.isBlank()) return ToolOutcome("缺少关键词", ok = false)
        val n = MemoryStore.forget(keyword)
        return ToolOutcome(if (n > 0) "已删除 $n 条包含「$keyword」的记忆" else "没有包含「$keyword」的记忆")
    }
}
