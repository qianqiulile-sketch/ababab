package com.dia.app.screen

import android.content.Context
import android.content.Intent
import com.dia.app.MainActivity
import com.dia.app.ui.chat.ChatController
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** 让其它页面 / 服务请求「回到对话页」。 */
object NavBus {
    private val _request = MutableStateFlow(0L)
    /** 每次请求都会变化的计数，DiaApp 观察它回到对话页。 */
    val toChat: StateFlow<Long> = _request.asStateFlow()
    fun requestChat() { _request.value = System.nanoTime() }
}

/** 悬浮气泡 / 屏幕识别结果 → 对话。 */
object ChatBridge {

    fun openChat(context: Context) {
        NavBus.requestChat()
        val intent = Intent(context, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
        }
        try { context.startActivity(intent) } catch (_: Exception) { }
    }

    /** 打开灵犀，并把 [text] 放进输入框，用户可以编辑后发送。 */
    fun openChatWithDraft(context: Context, text: String) {
        ChatController.setDraft(text)
        openChat(context)
    }
}
