package com.dia.app

import android.content.Context
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation3.runtime.NavEntry
import androidx.navigation3.ui.NavDisplay
import com.dia.app.llm.DiaEngine
import com.dia.app.navigation.BubbleRoute
import com.dia.app.navigation.ChatRoute
import com.dia.app.navigation.GuideRoute
import com.dia.app.navigation.HomeModeRoute
import com.dia.app.navigation.LensGuideRoute
import com.dia.app.navigation.LensLiveRoute
import com.dia.app.navigation.LensThinkRoute
import com.dia.app.navigation.LensTranslateRoute
import com.dia.app.navigation.ModelSetupRoute
import com.dia.app.navigation.OnboardingRoute
import com.dia.app.navigation.PilotRoute
import com.dia.app.navigation.SettingsRoute
import com.dia.app.navigation.SlateNotebookRoute
import com.dia.app.navigation.SlateQuizRoute
import com.dia.app.navigation.SlateRoute
import com.dia.app.prefs.AccessibilityPrefs
import com.dia.app.prefs.DiaPrefs
import com.dia.app.prefs.LocalAccessibility
import com.dia.app.screen.NavBus
import com.dia.app.ui.chat.BubbleEditorSheet
import com.dia.app.ui.chat.ChatScreen
import com.dia.app.ui.chat.ToolPage
import com.dia.app.ui.guide.GuideScreen
import com.dia.app.ui.home.HomeModeScreen
import com.dia.app.ui.lenslive.LensGuideScreen
import com.dia.app.ui.lenslive.LensLiveScreen
import com.dia.app.ui.lenslive.LensThinkScreen
import com.dia.app.ui.lenslive.LensTranslateScreen
import com.dia.app.ui.onboarding.OnboardingScreen
import com.dia.app.ui.pilot.PilotScreen
import com.dia.app.ui.settings.SettingsScreen
import com.dia.app.ui.setup.ModelSetupScreen
import com.dia.app.ui.slate.SlateHomeScreen
import com.dia.app.ui.slate.SlateNotebookScreen
import com.dia.app.ui.slate.SlateQuizScreen
import com.dia.app.ui.theme.DiaPal
import com.dia.app.ui.theme.DiaTheme
import com.dia.app.ui.theme.InkTheme
import com.dia.app.ui.theme.inkWashBackground

private const val PREFS_NAME = "dia_prefs"
private const val KEY_ONBOARDING_DONE = "onboarding_complete"

private fun MutableList<Any>.resetTo(route: Any) {
    if (isEmpty()) {
        add(route)
        return
    }
    this[0] = route
    while (size > 1) removeAt(size - 1)
}

/**
 * 灵犀的界面骨架：只有一个主界面——对话。
 * 其它功能（实时镜头、手写板、智能家居…）作为对话里的工具页打开，返回即回到对话。
 */
@Composable
fun DiaApp() {
    DiaTheme {
        val context = LocalContext.current
        val prefs = remember { context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE) }
        val isOnboardingDone = remember { prefs.getBoolean(KEY_ONBOARDING_DONE, false) }

        val bigText by DiaPrefs.bigText.collectAsState()
        val highContrast by DiaPrefs.highContrast.collectAsState()
        val a11y = AccessibilityPrefs(bigText = bigText, highContrast = highContrast)

        CompositionLocalProvider(LocalAccessibility provides a11y) {
            val startRoute: Any = if (isOnboardingDone) ChatRoute else OnboardingRoute
            val backStack = remember { mutableStateListOf(startRoute) }
            if (backStack.isEmpty()) backStack.add(startRoute)

            fun pop() { if (backStack.size > 1) backStack.removeAt(backStack.size - 1) }
            fun needsModel(route: Any) { backStack.add(if (DiaEngine.isReady) route else ModelSetupRoute) }

            // 快捷方式 / 通知按钮
            LaunchedEffect(Unit) {
                val action = MainActivity.pendingQuickAction
                MainActivity.pendingQuickAction = null
                when (action) {
                    DiaQuickLaunchService.ACTION_GUIDE -> backStack.add(GuideRoute)
                    DiaQuickLaunchService.ACTION_PILOT -> backStack.add(PilotRoute)
                }
            }
            // 悬浮气泡等请求回到对话
            val toChat by NavBus.toChat.collectAsState()
            LaunchedEffect(toChat) {
                if (toChat != 0L && backStack.firstOrNull() is ChatRoute) {
                    while (backStack.size > 1) backStack.removeAt(backStack.size - 1)
                }
            }

            NavDisplay(
                backStack = backStack,
                onBack = { pop() },
                entryProvider = { key ->
                    when (key) {
                        is OnboardingRoute -> NavEntry(key) {
                            OnboardingScreen(onComplete = {
                                prefs.edit().putBoolean(KEY_ONBOARDING_DONE, true).apply()
                                backStack.resetTo(ChatRoute)
                            })
                        }

                        is ChatRoute -> NavEntry(key) {
                            ChatScreen(onOpenPage = { page ->
                                when (page) {
                                    ToolPage.SETTINGS -> backStack.add(SettingsRoute)
                                    ToolPage.MODEL_SETUP -> backStack.add(ModelSetupRoute)
                                    ToolPage.LENS_LIVE -> needsModel(LensLiveRoute)
                                    ToolPage.SLATE -> needsModel(SlateRoute)
                                    ToolPage.HOME_MODE -> backStack.add(HomeModeRoute)
                                    ToolPage.PILOT -> needsModel(PilotRoute)
                                    ToolPage.GUIDE -> needsModel(GuideRoute)
                                }
                            })
                        }

                        is SettingsRoute -> NavEntry(key) {
                            SettingsScreen(
                                onBack = { pop() },
                                onOpenModelSetup = { backStack.add(ModelSetupRoute) },
                                onEditBubble = { backStack.add(BubbleRoute) },
                                onReplayOnboarding = { backStack.add(OnboardingRoute) },
                            )
                        }

                        is BubbleRoute -> NavEntry(key) { BubblePage(onBack = { pop() }) }

                        is ModelSetupRoute -> NavEntry(key) {
                            InkTheme {
                                ModelSetupScreen(
                                    onModelReady = { if (backStack.lastOrNull() is ModelSetupRoute) pop() },
                                    onBack = { pop() },
                                )
                            }
                        }

                        is LensLiveRoute -> NavEntry(key) {
                            InkTheme {
                                LensLiveScreen(
                                    onBack = { pop() },
                                    onThinkClick = { backStack.add(LensThinkRoute) },
                                    onTranslateClick = { backStack.add(LensTranslateRoute) },
                                    onGuideClick = { backStack.add(LensGuideRoute) },
                                )
                            }
                        }
                        is LensThinkRoute -> NavEntry(key) { InkTheme { LensThinkScreen(onBack = { pop() }) } }
                        is LensTranslateRoute -> NavEntry(key) { InkTheme { LensTranslateScreen(onBack = { pop() }) } }
                        is LensGuideRoute -> NavEntry(key) { InkTheme { LensGuideScreen(onBack = { pop() }) } }
                        is PilotRoute -> NavEntry(key) { InkTheme { PilotScreen(onBack = { pop() }) } }
                        is GuideRoute -> NavEntry(key) { InkTheme { GuideScreen(onBack = { pop() }) } }
                        is SlateRoute -> NavEntry(key) {
                            InkTheme {
                                SlateHomeScreen(
                                    onBack = { pop() },
                                    onOpenNotebook = { id -> backStack.add(SlateNotebookRoute(id)) },
                                    onOpenQuiz = { backStack.add(SlateQuizRoute) },
                                )
                            }
                        }
                        is SlateNotebookRoute -> NavEntry(key) {
                            InkTheme { SlateNotebookScreen(notebookId = key.notebookId, onBack = { pop() }) }
                        }
                        is SlateQuizRoute -> NavEntry(key) { InkTheme { SlateQuizScreen(onBack = { pop() }) } }
                        is HomeModeRoute -> NavEntry(key) { InkTheme { HomeModeScreen(onBack = { pop() }) } }

                        else -> NavEntry(key) { ChatScreen(onOpenPage = { backStack.add(SettingsRoute) }) }
                    }
                },
            )
        }
    }
}

@Composable
private fun BubblePage(onBack: () -> Unit) {
    val p = DiaPal.current
    Column(Modifier.fillMaxSize().inkWashBackground(p).windowInsetsPadding(WindowInsets.statusBars)) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "返回", tint = p.text) }
            Text("悬浮气泡", style = MaterialTheme.typography.headlineMedium, color = p.text)
        }
        Column(Modifier.verticalScroll(rememberScrollState())) { BubbleEditorSheet(p) }
    }
}
