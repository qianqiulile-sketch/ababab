package com.dia.app.ui.chat

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Per-chat metadata, surfaced in the history drawer.
 *
 * Storage model: one JSON file per chat under `filesDir/chats/<id>.json`.
 * The store is *read-only history* — when the user opens an old chat we
 * show its messages but the live engine starts a fresh conversation. This
 * is deliberate: replaying long histories into LiteRT-LM was the largest
 * source of session-conflict crashes in the previous build.
 */
data class ChatThread(
    val id: String,
    val title: String,
    val createdAt: Long,
    val updatedAt: Long,
    val messageCount: Int,
    val lastModel: String? = null,
)

object ChatHistoryStore {

    private const val TAG = "ChatHistoryStore"
    private const val DIR_NAME = "chats"

    private lateinit var dir: File

    private val _threads = MutableStateFlow<List<ChatThread>>(emptyList())
    val threads: StateFlow<List<ChatThread>> = _threads.asStateFlow()

    private val initialized: Boolean
        get() = ::dir.isInitialized

    suspend fun init(context: Context) = withContext(Dispatchers.IO) {
        if (initialized) return@withContext
        dir = File(context.applicationContext.filesDir, DIR_NAME).apply { mkdirs() }
        _threads.value = scanThreads()
    }

    private fun scanThreads(): List<ChatThread> {
        if (!::dir.isInitialized || !dir.exists()) return emptyList()
        return dir.listFiles { f -> f.isFile && f.name.endsWith(".json") }
            ?.mapNotNull { f ->
                try { readMeta(f) } catch (e: Exception) {
                    Log.w(TAG, "skip bad chat file ${f.name}: ${e.message}")
                    null
                }
            }
            ?.sortedByDescending { it.updatedAt }
            ?: emptyList()
    }

    private fun readMeta(file: File): ChatThread {
        val root = JSONObject(file.readText())
        val id = root.optString("id").ifEmpty { file.nameWithoutExtension }
        val title = root.optString("title").ifEmpty { "未命名" }
        val createdAt = root.optLong("createdAt", file.lastModified())
        val updatedAt = root.optLong("updatedAt", file.lastModified())
        val messageCount = root.optJSONArray("messages")?.length() ?: 0
        val lastModel = root.optString("lastModel").ifEmpty { null }
        return ChatThread(id, title, createdAt, updatedAt, messageCount, lastModel)
    }

    /**
     * Load the persisted messages for a thread for read-only display.
     * Returns an empty list if the thread doesn't exist.
     */
    suspend fun loadMessages(id: String): List<ChatMessage> = withContext(Dispatchers.IO) {
        if (!initialized) return@withContext emptyList()
        val file = File(dir, "$id.json")
        if (!file.exists()) return@withContext emptyList()
        try {
            val root = JSONObject(file.readText())
            val arr = root.optJSONArray("messages") ?: return@withContext emptyList()
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                ChatMessage(
                    id = o.optString("id").ifEmpty { java.util.UUID.randomUUID().toString() },
                    text = o.optString("text"),
                    isUser = o.optBoolean("isUser"),
                    timestamp = o.optLong("timestamp", System.currentTimeMillis()),
                    isStreaming = false,
                    isError = o.optBoolean("isError"),
                    thinking = o.optString("thinking").ifEmpty { null },
                    source = o.optString("source").ifEmpty { null },
                    kind = o.optString("kind").ifEmpty { ChatMessage.KIND_TEXT },
                    persona = o.optString("persona").ifEmpty { null },
                    toolName = o.optString("toolName").ifEmpty { null },
                    title = o.optString("title").ifEmpty { null },
                    detail = o.optString("detail").ifEmpty { null },
                    status = o.optString("status").ifEmpty { null }?.let { st ->
                        // 未完成的状态在重新打开时视为结束
                        when (st) { "running" -> "error"; "pending" -> "rejected"; else -> st }
                    },
                    imagePaths = strList(o.optJSONArray("imagePaths")),
                    fileIds = strList(o.optJSONArray("fileIds")),
                    fileNames = strList(o.optJSONArray("fileNames")),
                    hiddenContext = o.optString("hiddenContext").ifEmpty { null },
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "loadMessages failed for $id", e)
            emptyList()
        }
    }

    /**
     * Persist a chat thread. Drops empty drafts so the drawer stays clean
     * if the user opens a new chat and leaves without typing.
     */
    suspend fun save(
        id: String,
        title: String,
        messages: List<ChatMessage>,
        lastModel: String?,
    ) = withContext(Dispatchers.IO) {
        if (!initialized) return@withContext
        if (messages.none { it.isUser || (it.text.isNotBlank() && !it.isStreaming) }) {
            delete(id)
            return@withContext
        }
        val now = System.currentTimeMillis()
        val file = File(dir, "$id.json")
        val createdAt = if (file.exists()) {
            try { JSONObject(file.readText()).optLong("createdAt", now) } catch (_: Exception) { now }
        } else now

        val arr = JSONArray()
        for (m in messages) {
            if (m.isStreaming && m.text.isBlank()) continue
            val o = JSONObject()
                .put("id", m.id)
                .put("text", m.text)
                .put("isUser", m.isUser)
                .put("timestamp", m.timestamp)
                .put("isError", m.isError)
            if (!m.thinking.isNullOrBlank()) o.put("thinking", m.thinking)
            if (!m.source.isNullOrBlank()) o.put("source", m.source)
            if (m.kind != ChatMessage.KIND_TEXT) o.put("kind", m.kind)
            m.persona?.let { o.put("persona", it) }
            m.toolName?.let { o.put("toolName", it) }
            m.title?.let { o.put("title", it) }
            m.detail?.let { o.put("detail", it.take(20000)) }
            m.status?.let { o.put("status", it) }
            if (m.imagePaths.isNotEmpty()) o.put("imagePaths", JSONArray(m.imagePaths))
            if (m.fileIds.isNotEmpty()) o.put("fileIds", JSONArray(m.fileIds))
            if (m.fileNames.isNotEmpty()) o.put("fileNames", JSONArray(m.fileNames))
            m.hiddenContext?.let { o.put("hiddenContext", it.take(8000)) }
            arr.put(o)
        }

        val root = JSONObject()
            .put("id", id)
            .put("title", title.ifBlank { "新对话" })
            .put("createdAt", createdAt)
            .put("updatedAt", now)
            .put("messages", arr)
        if (!lastModel.isNullOrBlank()) root.put("lastModel", lastModel)

        try {
            file.writeText(root.toString())
        } catch (e: Exception) {
            Log.e(TAG, "save failed for $id", e)
            return@withContext
        }
        _threads.value = scanThreads()
    }

    suspend fun delete(id: String) = withContext(Dispatchers.IO) {
        if (!initialized) return@withContext
        val file = File(dir, "$id.json")
        if (file.exists()) file.delete()
        _threads.value = scanThreads()
    }

    suspend fun deleteAll() = withContext(Dispatchers.IO) {
        if (!initialized) return@withContext
        dir.listFiles()?.forEach { it.delete() }
        _threads.value = emptyList()
    }

    private fun strList(a: JSONArray?): List<String> {
        if (a == null) return emptyList()
        return (0 until a.length()).mapNotNull { a.optString(it).takeIf { s -> s.isNotEmpty() } }
    }

    /** Best-effort title from the first user message. */
    fun deriveTitle(messages: List<ChatMessage>): String {
        val first = messages.firstOrNull { it.isUser }?.text?.trim().orEmpty()
        if (first.isEmpty()) return "新对话"
        val truncated = first.take(48).replace('\n', ' ')
        return if (first.length > 48) "$truncated…" else truncated
    }
}
