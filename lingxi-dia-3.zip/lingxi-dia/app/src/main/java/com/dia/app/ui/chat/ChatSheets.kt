package com.dia.app.ui.chat

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dia.app.files.FileManager
import com.dia.app.files.FileRef
import com.dia.app.llm.ModelLoadState
import com.dia.app.llm.ModelRegistry
import com.dia.app.memory.MemoryItem
import com.dia.app.memory.MemoryStore
import com.dia.app.prefs.DiaPrefs
import com.dia.app.prefs.DiaSettings
import com.dia.app.screen.BubbleAction
import com.dia.app.screen.BubbleConfig
import com.dia.app.screen.QuickActionService
import com.dia.app.ui.theme.DiaPalette
import com.dia.app.ui.theme.DiaSerif
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SheetTitle(p: DiaPalette, title: String, subtitle: String? = null, trailing: @Composable () -> Unit = {}) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, style = MaterialTheme.typography.headlineMedium, color = p.text, fontFamily = DiaSerif, modifier = Modifier.weight(1f))
            trailing()
        }
        if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodySmall, color = p.textTertiary)
        Spacer(Modifier.height(10.dp))
    }
}

// ───────── 百宝箱 ─────────

private data class ToolItem(val key: String, val emoji: String, val label: String)

@Composable
fun ToolboxSheet(p: DiaPalette, onAction: (String) -> Unit) {
    val groups = listOf(
        "发送" to listOf(
            ToolItem("image", "🖼", "图片"), ToolItem("camera", "📷", "拍照"),
            ToolItem("file", "📎", "文件"), ToolItem("draw", "🎨", "画图"),
        ),
        "能力" to listOf(
            ToolItem("search", "🔍", "联网搜索"), ToolItem("translate", "🈯", "翻译"),
            ToolItem("screen_translate", "🪟", "翻译屏幕"), ToolItem("loop", "🔄", "AI自循环"),
            ToolItem("phone", "📱", "操控手机"), ToolItem("guide", "🧭", "屏幕引导"),
            ToolItem("memory", "📝", "记忆"), ToolItem("backup", "♻️", "备份还原"),
        ),
        "更多" to listOf(
            ToolItem("lens", "👁", "实时镜头"), ToolItem("slate", "✒️", "手写板"),
            ToolItem("home", "🏠", "智能家居"), ToolItem("bubble", "🫧", "悬浮气泡"),
            ToolItem("pilot", "🤖", "任务面板"), ToolItem("guide_page", "📖", "引导面板"),
            ToolItem("help", "❓", "命令帮助"), ToolItem("settings", "⚙️", "设置"),
        ),
    )
    Column(Modifier.fillMaxWidth().padding(bottom = 24.dp)) {
        SheetTitle(p, "百宝箱", "所有功能都在对话里，选一个开始")
        for ((name, items) in groups) {
            Text(name, style = MaterialTheme.typography.labelMedium, color = p.gold, modifier = Modifier.padding(start = 22.dp, top = 6.dp, bottom = 4.dp))
            for (row in items.chunked(4)) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
                    for (it in row) {
                        Column(
                            Modifier.weight(1f).padding(4.dp).clip(RoundedCornerShape(14.dp))
                                .clickable { onAction(it.key) }.padding(vertical = 10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            Box(
                                Modifier.size(46.dp).clip(RoundedCornerShape(13.dp)).background(p.surfaceAlt)
                                    .border(0.8.dp, p.border, RoundedCornerShape(13.dp)),
                                contentAlignment = Alignment.Center,
                            ) { Text(it.emoji, fontSize = 22.sp) }
                            Spacer(Modifier.height(4.dp))
                            Text(it.label, style = MaterialTheme.typography.labelMedium, color = p.textSecondary, maxLines = 1)
                        }
                    }
                    repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
                }
            }
        }
    }
}

// ───────── 历史 ─────────

@Composable
fun HistorySheet(
    p: DiaPalette,
    threads: List<ChatThread>,
    activeId: String,
    onPick: (String) -> Unit,
    onDelete: (String) -> Unit,
    onNew: () -> Unit,
    onClearAll: () -> Unit,
) {
    var confirmClear by remember { mutableStateOf(false) }
    val fmt = remember { SimpleDateFormat("M月d日 HH:mm", Locale.CHINA) }
    Column(Modifier.fillMaxWidth().padding(bottom = 20.dp)) {
        SheetTitle(p, "历史对话", "点开即可接着聊") {
            IconButton(onClick = onNew) { Icon(Icons.Rounded.Add, "新对话", tint = p.cinnabar) }
        }
        if (threads.isEmpty()) {
            Text("还没有对话记录", color = p.textTertiary, modifier = Modifier.padding(20.dp))
        } else {
            LazyColumn(Modifier.fillMaxWidth().heightIn(max = 480.dp), contentPadding = PaddingValues(horizontal = 16.dp)) {
                items(threads, key = { it.id }) { t ->
                    val active = t.id == activeId
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 3.dp).clip(RoundedCornerShape(12.dp))
                            .background(if (active) p.cinnabar.copy(alpha = 0.10f) else p.surfaceAlt.copy(alpha = 0.5f))
                            .clickable { onPick(t.id) }.padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(t.title, color = p.text, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("${fmt.format(Date(t.updatedAt))} · ${t.messageCount} 条", color = p.textTertiary, style = MaterialTheme.typography.labelSmall)
                        }
                        IconButton(onClick = { onDelete(t.id) }) { Icon(Icons.Rounded.Delete, "删除", tint = p.textTertiary, modifier = Modifier.size(18.dp)) }
                    }
                }
            }
            TextButton(onClick = { confirmClear = true }, modifier = Modifier.padding(start = 12.dp)) {
                Text("清空全部历史", color = p.error)
            }
        }
    }
    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("清空全部历史？") },
            text = { Text("所有对话记录都会被删除，无法恢复。记忆不受影响。") },
            confirmButton = { TextButton(onClick = { confirmClear = false; onClearAll() }) { Text("清空", color = p.error) } },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("取消") } },
        )
    }
}

// ───────── 模型 ─────────

@Composable
fun ModelSheet(
    p: DiaPalette,
    loadState: ModelLoadState,
    onPickLocal: (String) -> Unit,
    onPickCloud: () -> Unit,
    onImport: () -> Unit,
    onUnload: () -> Unit,
    onSwitchBackend: (String) -> Unit,
) {
    val context = LocalContext.current
    val locals = remember { ModelRegistry.discoverLocal(context) }
    val cloudOn by DiaPrefs.cloudEnabled.collectAsState()
    val cloudReady = DiaPrefs.cloudBaseUrl.collectAsState().value.isNotBlank() && DiaPrefs.cloudModel.collectAsState().value.isNotBlank()
    Column(Modifier.fillMaxWidth().padding(bottom = 24.dp)) {
        SheetTitle(p, "选择模型", "选中的模型供整个灵犀共用（对话、看图、操控手机…）")
        Column(Modifier.padding(horizontal = 16.dp)) {
            Text("本地 · 手机上离线运行", style = MaterialTheme.typography.labelMedium, color = p.gold)
            Spacer(Modifier.height(6.dp))
            if (locals.isEmpty()) {
                Text("没有找到 .litertlm 模型文件。点下方「导入模型」，或把模型放到 下载 / Models 目录。",
                    style = MaterialTheme.typography.bodySmall, color = p.textTertiary)
            }
            for (f in locals) {
                val activePath = (loadState as? ModelLoadState.Ready)?.modelPath ?: (loadState as? ModelLoadState.Loading)?.modelPath
                val active = activePath == f.absolutePath && !cloudOn
                val sizeMb = f.length() / 1024 / 1024
                OptionRow(
                    p, "🧠", ModelRegistry.friendlyName(f),
                    when {
                        active && loadState is ModelLoadState.Loading -> "加载中… ${loadState.progress}"
                        active && loadState is ModelLoadState.Ready -> "使用中 · ${loadState.backend} · $sizeMb MB"
                        else -> "${f.parentFile?.name.orEmpty()} · $sizeMb MB"
                    },
                    active,
                ) { onPickLocal(f.absolutePath) }
            }
            OptionRow(p, "📥", "导入模型", "从手机文件中选择 .litertlm", false, onImport)
            if (loadState is ModelLoadState.Ready) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = { onSwitchBackend("GPU") }, enabled = loadState.backend != "GPU") { Text("切到 GPU") }
                    TextButton(onClick = { onSwitchBackend("CPU") }, enabled = loadState.backend != "CPU") { Text("切到 CPU") }
                    TextButton(onClick = onUnload) { Text("卸载模型", color = p.error) }
                }
            }
            Spacer(Modifier.height(10.dp))
            Text("云端 · OpenAI 兼容接口", style = MaterialTheme.typography.labelMedium, color = p.gold)
            Spacer(Modifier.height(6.dp))
            OptionRow(
                p, "☁️",
                if (cloudReady) ModelRegistry.cloudLabel() else "云端模型（未配置）",
                if (cloudReady) "例如 DeepSeek、通义千问、Kimi、智谱、OpenAI…" else "请到 设置 → 云端模型 填写地址和密钥",
                cloudOn && cloudReady,
            ) { if (cloudReady) onPickCloud() }
        }
    }
}

@Composable
private fun OptionRow(p: DiaPalette, emoji: String, title: String, subtitle: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 3.dp).clip(RoundedCornerShape(12.dp))
            .background(if (selected) p.cinnabar.copy(alpha = 0.10f) else p.surfaceAlt.copy(alpha = 0.5f))
            .border(0.8.dp, if (selected) p.cinnabar.copy(alpha = 0.5f) else p.border, RoundedCornerShape(12.dp))
            .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(emoji, fontSize = 20.sp)
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = p.text, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(subtitle, color = p.textTertiary, style = MaterialTheme.typography.labelSmall, maxLines = 2)
        }
        if (selected) Box(Modifier.size(8.dp).clip(CircleShape).background(p.cinnabar))
    }
}

// ───────── 记忆 ─────────

@Composable
fun MemorySheet(p: DiaPalette) {
    val items by MemoryStore.items.collectAsState()
    val enabled by DiaSettings.memoryEnabled.flow.collectAsState()
    val auto by DiaSettings.autoMemory.flow.collectAsState()
    var editing by remember { mutableStateOf<MemoryItem?>(null) }
    var adding by remember { mutableStateOf(false) }
    var confirmClear by remember { mutableStateOf(false) }
    val fmt = remember { SimpleDateFormat("M月d日", Locale.CHINA) }
    Column(Modifier.fillMaxWidth().padding(bottom = 20.dp)) {
        SheetTitle(p, "记忆", "灵犀会记住关于你的关键信息，回答时自然地用上") {
            IconButton(onClick = { adding = true }) { Icon(Icons.Rounded.Add, "写一条记忆", tint = p.cinnabar) }
        }
        ToggleRow(p, "启用记忆", "关闭后不读取也不写入记忆", enabled) { DiaSettings.memoryEnabled.set(it) }
        ToggleRow(p, "自动记忆", "每聊两轮，自动提取对话中的关键信息", auto) { DiaSettings.autoMemory.set(it) }
        HorizontalDivider(color = p.border, modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp))
        if (items.isEmpty()) {
            Text("还没有记忆。可以在对话里说「记住…」，或点右上角 ＋ 手写一条。", color = p.textTertiary,
                style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(20.dp))
        }
        LazyColumn(Modifier.fillMaxWidth().heightIn(max = 420.dp), contentPadding = PaddingValues(horizontal = 16.dp)) {
            items(items, key = { it.id }) { m ->
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 3.dp).clip(RoundedCornerShape(12.dp))
                        .background(p.surfaceAlt.copy(alpha = 0.6f)).clickable { editing = m }
                        .padding(horizontal = 12.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text((if (m.pinned) "📌 " else "") + m.content, color = p.text, style = MaterialTheme.typography.bodyMedium)
                        Text("${m.category} · ${if (m.source == "auto") "自动" else "手写"} · ${fmt.format(Date(m.updatedAt))}",
                            color = p.textTertiary, style = MaterialTheme.typography.labelSmall)
                    }
                    IconButton(onClick = { MemoryStore.togglePin(m.id) }) {
                        Text(if (m.pinned) "取消置顶" else "置顶", color = p.gold, style = MaterialTheme.typography.labelSmall)
                    }
                    IconButton(onClick = { MemoryStore.delete(m.id) }) { Icon(Icons.Rounded.Delete, "删除", tint = p.textTertiary, modifier = Modifier.size(18.dp)) }
                }
            }
        }
        if (items.isNotEmpty()) {
            TextButton(onClick = { confirmClear = true }, modifier = Modifier.padding(start = 12.dp)) { Text("清空全部记忆", color = p.error) }
        }
    }
    if (adding || editing != null) {
        val cur = editing
        MemoryEditDialog(
            p, initial = cur?.content.orEmpty(), initialCat = cur?.category ?: "其他",
            onDismiss = { adding = false; editing = null },
        ) { text, cat ->
            if (cur != null) MemoryStore.edit(cur.id, text, cat) else MemoryStore.add(text, cat, "manual")
            adding = false; editing = null
        }
    }
    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("清空全部记忆？") },
            text = { Text("灵犀将忘记所有关于你的信息。") },
            confirmButton = { TextButton(onClick = { confirmClear = false; MemoryStore.clear() }) { Text("清空", color = p.error) } },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("取消") } },
        )
    }
}

@Composable
private fun MemoryEditDialog(p: DiaPalette, initial: String, initialCat: String, onDismiss: () -> Unit, onSave: (String, String) -> Unit) {
    var text by remember { mutableStateOf(initial) }
    var cat by remember { mutableStateOf(initialCat) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial.isEmpty()) "写一条记忆" else "编辑记忆") },
        text = {
            Column {
                OutlinedTextField(value = text, onValueChange = { text = it }, modifier = Modifier.fillMaxWidth(), minLines = 2,
                    placeholder = { Text("例如：用户对花生过敏") })
                Spacer(Modifier.height(8.dp))
                for (row in MemoryStore.CATEGORIES.chunked(3)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(vertical = 2.dp)) {
                        for (c in row) {
                            Text(
                                c, style = MaterialTheme.typography.labelMedium,
                                color = if (c == cat) p.onCinnabar else p.textSecondary,
                                modifier = Modifier.clip(RoundedCornerShape(10.dp))
                                    .background(if (c == cat) p.cinnabar else p.surfaceAlt)
                                    .clickable { cat = c }.padding(horizontal = 10.dp, vertical = 5.dp),
                            )
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { if (text.isNotBlank()) onSave(text, cat) }) { Text("保存", color = p.cinnabar) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("取消") } },
    )
}

@Composable
fun ToggleRow(p: DiaPalette, title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(horizontal = 20.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = p.text, style = MaterialTheme.typography.titleSmall)
            Text(subtitle, color = p.textTertiary, style = MaterialTheme.typography.labelSmall)
        }
        Switch(
            checked = checked, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedTrackColor = p.cinnabar, checkedThumbColor = p.onCinnabar),
        )
    }
}

// ───────── 文件与备份 ─────────

@Composable
fun BackupSheet(p: DiaPalette, onAttach: (FileRef) -> Unit) {
    val files by FileManager.files.collectAsState()
    val backups by FileManager.backups.collectAsState()
    var confirmRestore by remember { mutableStateOf<String?>(null) }
    var message by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxWidth().padding(bottom = 20.dp)) {
        SheetTitle(p, "文件与备份", "灵犀每次修改文件前都会自动备份，可随时还原")
        LazyColumn(Modifier.fillMaxWidth().heightIn(max = 520.dp), contentPadding = PaddingValues(horizontal = 16.dp)) {
            item { Text("已附加的文件（点击加入本条消息）", style = MaterialTheme.typography.labelMedium, color = p.gold, modifier = Modifier.padding(vertical = 4.dp)) }
            if (files.isEmpty()) item { Text("暂无。点 ＋ →「文件」选择。", color = p.textTertiary, style = MaterialTheme.typography.bodySmall) }
            items(files, key = { "f_" + it.id }) { f ->
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 2.dp).clip(RoundedCornerShape(10.dp))
                        .background(p.surfaceAlt.copy(alpha = 0.6f)).clickable { onAttach(f) }.padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("${f.id}", color = p.cinnabar, style = MaterialTheme.typography.labelMedium, modifier = Modifier.width(32.dp))
                    Column(Modifier.weight(1f)) {
                        Text(f.name, color = p.text, style = MaterialTheme.typography.bodyMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("${f.kind}${if (f.editable) " · 可修改" else ""}", color = p.textTertiary, style = MaterialTheme.typography.labelSmall)
                    }
                    IconButton(onClick = { FileManager.remove(f.id) }) { Icon(Icons.Rounded.Close, "移除", tint = p.textTertiary, modifier = Modifier.size(16.dp)) }
                }
            }
            item {
                Spacer(Modifier.height(10.dp))
                Text("备份记录", style = MaterialTheme.typography.labelMedium, color = p.gold, modifier = Modifier.padding(vertical = 4.dp))
            }
            if (backups.isEmpty()) item { Text("暂无备份。", color = p.textTertiary, style = MaterialTheme.typography.bodySmall) }
            items(backups, key = { "b_" + it.id }) { b ->
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 2.dp).clip(RoundedCornerShape(10.dp))
                        .background(p.surfaceAlt.copy(alpha = 0.6f)).padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(b.name, color = p.text, style = MaterialTheme.typography.bodyMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("${FileManager.formatTime(b.time)} · ${b.note} · ${com.dia.app.web.WebDownloader.formatSize(b.size)}",
                            color = p.textTertiary, style = MaterialTheme.typography.labelSmall)
                    }
                    TextButton(onClick = { confirmRestore = b.id }) { Text("还原", color = p.cinnabar) }
                    IconButton(onClick = { FileManager.deleteBackup(b.id) }) { Icon(Icons.Rounded.Delete, "删除备份", tint = p.textTertiary, modifier = Modifier.size(16.dp)) }
                }
            }
        }
        message?.let { Text(it, color = p.bamboo, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp)) }
    }
    confirmRestore?.let { id ->
        AlertDialog(
            onDismissRequest = { confirmRestore = null },
            title = { Text("还原这个备份？") },
            text = { Text("文件会被替换为备份时的内容；当前版本会先自动备份一份。") },
            confirmButton = {
                TextButton(onClick = {
                    confirmRestore = null
                    message = try { FileManager.restore(id) } catch (e: Exception) { "还原失败：${e.message}" }
                }) { Text("还原", color = p.cinnabar) }
            },
            dismissButton = { TextButton(onClick = { confirmRestore = null }) { Text("取消") } },
        )
    }
}

// ───────── 悬浮气泡编辑 ─────────

@Composable
fun BubbleEditorSheet(p: DiaPalette) {
    val context = LocalContext.current
    val actions by BubbleConfig.actions.collectAsState()
    val style by BubbleConfig.style.collectAsState()
    var running by remember { mutableStateOf(QuickActionService.isRunning()) }
    var editing by remember { mutableStateOf<BubbleAction?>(null) }
    var adding by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxWidth().padding(bottom = 20.dp)) {
        SheetTitle(p, "悬浮气泡", "在任何应用上方随时呼出灵犀。菜单可自由编辑") {
            IconButton(onClick = { BubbleConfig.reset() }) { Icon(Icons.Rounded.Refresh, "恢复默认", tint = p.textSecondary) }
        }
        ToggleRow(p, "显示悬浮气泡", if (QuickActionService.hasOverlayPermission(context)) "单击展开菜单，拖动移动，双击隐藏" else "需要先授予「显示在其他应用上层」权限", running) { on ->
            if (on) {
                if (!QuickActionService.hasOverlayPermission(context)) {
                    context.startActivity(
                        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}"))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                } else {
                    QuickActionService.start(context); running = true
                }
            } else {
                QuickActionService.stop(context); running = false
            }
        }
        Text("外观", style = MaterialTheme.typography.labelMedium, color = p.gold, modifier = Modifier.padding(start = 20.dp, top = 6.dp))
        Row(Modifier.padding(horizontal = 16.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            for ((id, label) in listOf("cinnabar" to "朱砂", "gold" to "古金", "indigo" to "黛青", "ink" to "墨")) {
                Chip(p, label, style.color == id) { BubbleConfig.setStyle(style.copy(color = id)) }
            }
        }
        Row(Modifier.padding(horizontal = 16.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            for ((sz, label) in listOf(44 to "小", 52 to "中", 62 to "大")) {
                Chip(p, label, style.sizeDp == sz) { BubbleConfig.setStyle(style.copy(sizeDp = sz)) }
            }
            for ((sec, label) in listOf(10 to "结果10秒", 30 to "30秒", 0 to "不自动关")) {
                Chip(p, label, style.resultSeconds == sec) { BubbleConfig.setStyle(style.copy(resultSeconds = sec)) }
            }
        }
        Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 12.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("菜单动作", style = MaterialTheme.typography.labelMedium, color = p.gold, modifier = Modifier.weight(1f))
            TextButton(onClick = { adding = true }) { Text("＋ 添加", color = p.cinnabar) }
        }
        LazyColumn(Modifier.fillMaxWidth().heightIn(max = 380.dp), contentPadding = PaddingValues(horizontal = 16.dp)) {
            items(actions, key = { it.id }) { a ->
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 2.dp).clip(RoundedCornerShape(10.dp))
                        .background(p.surfaceAlt.copy(alpha = if (a.enabled) 0.7f else 0.3f)).padding(start = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f).clickable { editing = a }.padding(vertical = 8.dp)) {
                        Text(a.label + if (a.isCustom) " ·自定义" else "", color = if (a.enabled) p.text else p.textTertiary, style = MaterialTheme.typography.bodyMedium)
                        if (a.subtitle.isNotBlank()) Text(a.subtitle, color = p.textTertiary, style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    IconButton(onClick = { BubbleConfig.move(a.id, -1) }, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Rounded.KeyboardArrowDown, "上移", tint = p.textSecondary, modifier = Modifier.size(18.dp).graphicsLayer { rotationZ = 180f })
                    }
                    IconButton(onClick = { BubbleConfig.move(a.id, 1) }, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Rounded.KeyboardArrowDown, "下移", tint = p.textSecondary, modifier = Modifier.size(18.dp))
                    }
                    IconButton(onClick = { editing = a }, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Rounded.Edit, "编辑", tint = p.textSecondary, modifier = Modifier.size(16.dp))
                    }
                    Switch(
                        checked = a.enabled, onCheckedChange = { BubbleConfig.toggle(a.id) },
                        colors = SwitchDefaults.colors(checkedTrackColor = p.cinnabar, checkedThumbColor = p.onCinnabar),
                        modifier = Modifier.padding(end = 4.dp),
                    )
                }
            }
        }
    }
    if (adding || editing != null) {
        BubbleActionDialog(p, editing, onDismiss = { adding = false; editing = null }, onDelete = { id ->
            BubbleConfig.delete(id); adding = false; editing = null
        }) { action ->
            BubbleConfig.upsert(action); adding = false; editing = null
        }
    }
}

@Composable
private fun Chip(p: DiaPalette, label: String, selected: Boolean, onClick: () -> Unit) {
    Text(
        label, style = MaterialTheme.typography.labelMedium,
        color = if (selected) p.onCinnabar else p.textSecondary,
        modifier = Modifier.clip(RoundedCornerShape(10.dp)).background(if (selected) p.cinnabar else p.surfaceAlt)
            .clickable(onClick = onClick).padding(horizontal = 10.dp, vertical = 6.dp),
    )
}

@Composable
private fun BubbleActionDialog(
    p: DiaPalette,
    existing: BubbleAction?,
    onDismiss: () -> Unit,
    onDelete: (String) -> Unit,
    onSave: (BubbleAction) -> Unit,
) {
    var type by remember { mutableStateOf(existing?.type ?: BubbleAction.TYPE_CUSTOM) }
    var label by remember { mutableStateOf(existing?.label ?: "") }
    var subtitle by remember { mutableStateOf(existing?.subtitle ?: "") }
    var prompt by remember { mutableStateOf(existing?.prompt ?: "") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "添加气泡动作" else "编辑气泡动作") },
        text = {
            Column {
                if (existing == null) {
                    Text("类型", style = MaterialTheme.typography.labelMedium, color = p.gold)
                    val all = listOf(BubbleAction.TYPE_CUSTOM to "自定义（框选 + 你的提示词）") + BubbleAction.BUILTIN_TYPES
                    Column(Modifier.heightIn(max = 180.dp)) {
                        LazyColumn {
                            items(all, key = { it.first }) { (t, l) ->
                                Text(
                                    l, color = if (t == type) p.cinnabar else p.textSecondary,
                                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = if (t == type) FontWeight.SemiBold else FontWeight.Normal),
                                    modifier = Modifier.fillMaxWidth().clickable {
                                        type = t
                                        if (label.isBlank()) label = l.substringBefore("（")
                                    }.padding(vertical = 5.dp),
                                )
                            }
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                }
                OutlinedTextField(value = label, onValueChange = { label = it }, label = { Text("名称") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = subtitle, onValueChange = { subtitle = it }, label = { Text("说明（可选）") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                if (type == BubbleAction.TYPE_CUSTOM || type == BubbleAction.TYPE_QUICK_ASK) {
                    OutlinedTextField(
                        value = prompt, onValueChange = { prompt = it },
                        label = { Text(if (type == BubbleAction.TYPE_CUSTOM) "提示词（框选区域后执行）" else "默认问题（可选）") },
                        minLines = 2, modifier = Modifier.fillMaxWidth(),
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (label.isNotBlank() && (type != BubbleAction.TYPE_CUSTOM || prompt.isNotBlank())) {
                    onSave(
                        (existing ?: BubbleAction(type = type, label = label)).copy(
                            type = type, label = label.trim(), subtitle = subtitle.trim(), prompt = prompt.trim(),
                        )
                    )
                }
            }) { Text("保存", color = p.cinnabar) }
        },
        dismissButton = {
            Row {
                if (existing != null) TextButton(onClick = { onDelete(existing.id) }) { Text("删除", color = p.error) }
                TextButton(onClick = onDismiss) { Text("取消") }
            }
        },
    )
}
