package com.dia.app.voice

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs

/**
 * PCM-16-bit mono recorder that feeds raw audio straight into the on-device
 * Gemma model via `Content.AudioBytes(...)`.
 *
 * This is the "audio scribe" pipeline LiteRT-LM exposes — Gemma 3n / 4 does
 * the speech recognition itself on device, instead of bouncing off platform
 * SpeechRecognizer (which requires Play Services and shifts user audio off
 * the device).
 *
 * Output: 16 kHz, 16-bit signed little-endian, mono PCM.
 */
class AudioScribeRecorder(
    private val sampleRateHz: Int = 16_000,
    private val maxDurationMs: Long = 30_000L,
) {

    /** Public accessor so callers can attach the rate when building the clip. */
    val sampleRate: Int get() = sampleRateHz

    companion object { private const val TAG = "AudioScribe" }

    enum class State { IDLE, RECORDING }

    private val _state = MutableStateFlow(State.IDLE)
    val state: StateFlow<State> = _state.asStateFlow()

    /** 0..32767 peak amplitude — used to drive a waveform indicator. */
    private val _amplitude = MutableStateFlow(0)
    val amplitude: StateFlow<Int> = _amplitude.asStateFlow()

    /** Elapsed milliseconds since the recording started (or 0 when idle). */
    private val _elapsedMs = MutableStateFlow(0L)
    val elapsedMs: StateFlow<Long> = _elapsedMs.asStateFlow()

    private var recorder: AudioRecord? = null
    private val stream = ByteArrayOutputStream()
    private var job: Job? = null
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    @SuppressLint("MissingPermission")
    fun start(): Boolean {
        if (_state.value != State.IDLE) return false
        val minBuf = AudioRecord.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
        )
        if (minBuf == AudioRecord.ERROR || minBuf == AudioRecord.ERROR_BAD_VALUE) {
            Log.e(TAG, "AudioRecord min buffer size unavailable")
            return false
        }
        val rec = try {
            AudioRecord(
                MediaRecorder.AudioSource.MIC,
                sampleRate,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                minBuf,
            )
        } catch (e: Exception) {
            Log.e(TAG, "Failed to create AudioRecord", e)
            return false
        }
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            Log.e(TAG, "AudioRecord state=${rec.state} after construction")
            try { rec.release() } catch (_: Exception) {}
            return false
        }
        stream.reset()
        recorder = rec
        _state.value = State.RECORDING
        _elapsedMs.value = 0L
        _amplitude.value = 0

        job = scope.launch {
            val buf = ByteArray(minBuf)
            try {
                rec.startRecording()
                val started = System.currentTimeMillis()
                while (_state.value == State.RECORDING && rec.recordingState == AudioRecord.RECORDSTATE_RECORDING) {
                    val read = rec.read(buf, 0, buf.size)
                    if (read > 0) {
                        stream.write(buf, 0, read)
                        _amplitude.value = peak(buf, read)
                    }
                    val elapsed = System.currentTimeMillis() - started
                    _elapsedMs.value = elapsed
                    if (elapsed >= maxDurationMs) break
                }
            } catch (e: Exception) {
                Log.e(TAG, "Recording loop crashed", e)
            }
        }
        return true
    }

    /** Stop recording and return the captured PCM bytes. */
    fun stop(): ByteArray {
        if (_state.value != State.RECORDING) return ByteArray(0)
        _state.value = State.IDLE
        try {
            recorder?.let {
                if (it.recordingState == AudioRecord.RECORDSTATE_RECORDING) it.stop()
                it.release()
            }
        } catch (e: Exception) {
            Log.w(TAG, "stop/release: ${e.message}")
        }
        recorder = null
        try { job?.cancel() } catch (_: Exception) {}
        job = null
        _amplitude.value = 0
        val bytes = stream.toByteArray()
        stream.reset()
        return bytes
    }

    fun cancel() {
        if (_state.value != State.RECORDING) return
        _state.value = State.IDLE
        try {
            recorder?.let {
                if (it.recordingState == AudioRecord.RECORDSTATE_RECORDING) it.stop()
                it.release()
            }
        } catch (_: Exception) {}
        recorder = null
        try { job?.cancel() } catch (_: Exception) {}
        job = null
        _amplitude.value = 0
        stream.reset()
    }

    fun release() {
        cancel()
        try { scope.cancel() } catch (_: Exception) {}
    }

    /**
     * Find the largest absolute sample (signed 16-bit LE) in the buffer.
     * Mirrors the Gallery helper.
     */
    private fun peak(buffer: ByteArray, bytesRead: Int): Int {
        if (bytesRead < 2) return 0
        val shorts = ByteBuffer.wrap(buffer, 0, bytesRead)
            .order(ByteOrder.LITTLE_ENDIAN)
            .asShortBuffer()
        var max = 0
        while (shorts.hasRemaining()) {
            val s = abs(shorts.get().toInt())
            if (s > max) max = s
        }
        return max
    }
}
