package com.dia.app.llm

import android.content.Context
import android.util.Log
import com.dia.app.prefs.DiaPrefs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Single owner of [DiaEngine] for the whole app.
 *
 * Why this exists: every feature (chat, lens, pilot, slate, setup) used to
 * call [DiaEngine.initialize] directly. Concurrent inits crashed JNI. This
 * class serializes every load/unload through one [Mutex], short-circuits
 * "same model already loaded", and exposes a single observable
 * [ModelLoadState] that every feature renders.
 *
 * Modeled after Gallery's `ModelManagerViewModel.modelInitializationStatus`
 * and PokeClaw's `EngineHolder` + `LocalModelRuntime`.
 */
object ModelManager {

    private const val TAG = "ModelManager"

    private val mutex = Mutex()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private val _state = MutableStateFlow<ModelLoadState>(ModelLoadState.Idle)
    val state: StateFlow<ModelLoadState> = _state.asStateFlow()

    /**
     * Background bridge that keeps [_state] in sync with [DiaEngine.state]
     * for paths that bypass [load]/[unload] (e.g. internal close-on-error
     * inside DiaEngine). Doesn't touch [_state] when we're already in a
     * Loading state owned by [load].
     */
    init {
        scope.launch {
            DiaEngine.state.collect { engineState ->
                val current = _state.value
                if (current is ModelLoadState.Loading) return@collect
                when (engineState) {
                    is ModelState.Ready -> {
                        val path = DiaEngine.currentModelPath ?: return@collect
                        _state.value = ModelLoadState.Ready(
                            modelPath = path,
                            modelName = java.io.File(path).nameWithoutExtension,
                            backend = DiaEngine.activeBackend,
                        )
                    }
                    is ModelState.NotLoaded -> {
                        if (current !is ModelLoadState.Idle) _state.value = ModelLoadState.Idle
                    }
                    is ModelState.Error -> {
                        if (current !is ModelLoadState.Error) {
                            _state.value = ModelLoadState.Error(engineState.message)
                        }
                    }
                    is ModelState.InsufficientMemory -> {
                        if (current !is ModelLoadState.Error) {
                            _state.value = ModelLoadState.Error(engineState.message, oom = true)
                        }
                    }
                    is ModelState.Loading -> Unit
                }
            }
        }
    }

    /** Convenience: true when an inference-ready engine is loaded. */
    val isReady: Boolean
        get() = _state.value is ModelLoadState.Ready

    /** Currently loaded path, if any. Mirror of DiaEngine.currentModelPath. */
    val currentPath: String?
        get() = (_state.value as? ModelLoadState.Ready)?.modelPath
            ?: DiaEngine.currentModelPath

    /** Backend the currently-loaded engine is running on, e.g. "GPU" / "CPU". */
    val currentBackend: String?
        get() = (_state.value as? ModelLoadState.Ready)?.backend

    /**
     * Initialize the engine with [modelPath]. Returns when the engine is
     * fully ready (or has errored).
     *
     * - If the same model on the same backend is already loaded, returns
     *   immediately. This is the spam-protection behavior — tapping a model
     *   in the picker repeatedly is a no-op once loaded.
     * - If a *different* model is loaded, it is closed first.
     * - All concurrent callers serialize on a single [Mutex], so racing
     *   `initialize` calls can never crash JNI.
     *
     * @return true if the engine ended up Ready, false otherwise.
     */
    suspend fun load(
        context: Context,
        modelPath: String,
        preferredBackend: String? = null,
    ): Boolean = mutex.withLock {
        // Fast path: same model on same backend is already live.
        if (DiaEngine.isReady &&
            DiaEngine.currentModelPath == modelPath &&
            (preferredBackend == null || preferredBackend == DiaEngine.activeBackend)
        ) {
            _state.value = ModelLoadState.Ready(
                modelPath = modelPath,
                modelName = File(modelPath).nameWithoutExtension,
                backend = DiaEngine.activeBackend,
            )
            return@withLock true
        }

        // File-not-found and too-small checks happen before we trash the
        // current engine, so a bogus pick doesn't unload a good model.
        val file = File(modelPath)
        if (!file.exists()) {
            _state.value = ModelLoadState.Error("Model file not found: $modelPath")
            return@withLock false
        }
        if (file.length() < 1_000_000) {
            _state.value = ModelLoadState.Error(
                "Model file too small (${file.length() / 1024} KB). May be corrupted."
            )
            return@withLock false
        }

        val name = file.nameWithoutExtension
        _state.value = ModelLoadState.Loading(
            modelPath = modelPath,
            modelName = name,
            progress = "Preparing engine…",
        )

        // Fan engine state changes (Loading sub-states) into our state too,
        // so the UI sees "Trying GPU…" / "Initializing CPU…" updates without
        // having to subscribe to two flows.
        val bridgeJob = scope.launch {
            DiaEngine.state.collect { engineState ->
                val current = _state.value
                if (current is ModelLoadState.Loading && current.modelPath == modelPath) {
                    when (engineState) {
                        is ModelState.Loading ->
                            _state.value = current.copy(progress = engineState.progress)
                        is ModelState.InsufficientMemory ->
                            _state.value = ModelLoadState.Error(engineState.message, oom = true)
                        is ModelState.Error ->
                            _state.value = ModelLoadState.Error(engineState.message)
                        else -> Unit
                    }
                }
            }
        }

        try {
            withContext(Dispatchers.Default) {
                DiaEngine.initialize(context.applicationContext, modelPath, preferredBackend)
            }
        } catch (t: Throwable) {
            Log.e(TAG, "load() crashed for $modelPath", t)
            _state.value = ModelLoadState.Error(t.message ?: t.javaClass.simpleName)
            bridgeJob.cancel()
            return@withLock false
        }
        bridgeJob.cancel()

        // Translate whatever DiaEngine ended up with into our state.
        return@withLock when (val end = DiaEngine.state.value) {
            is ModelState.Ready -> {
                _state.value = ModelLoadState.Ready(
                    modelPath = modelPath,
                    modelName = name,
                    backend = DiaEngine.activeBackend,
                )
                // Persist as the last-used model now that it's known-good.
                ModelRegistry.saveLocalPath(context, modelPath)
                true
            }
            is ModelState.InsufficientMemory -> {
                _state.value = ModelLoadState.Error(end.message, oom = true)
                false
            }
            is ModelState.Error -> {
                _state.value = ModelLoadState.Error(end.message)
                false
            }
            is ModelState.Loading,
            is ModelState.NotLoaded -> {
                _state.value = ModelLoadState.Error("Engine did not finish loading")
                false
            }
        }
    }

    /**
     * Reload the current model — useful for "switch GPU/CPU" actions in the
     * chat overflow menu. No-op if no model is loaded.
     */
    suspend fun reload(context: Context, preferredBackend: String? = null): Boolean {
        val path = currentPath ?: return false
        // Force the close path by clearing in-engine identity first.
        mutex.withLock { DiaEngine.unload() }
        return load(context, path, preferredBackend)
    }

    /** Unload the model and free native memory. */
    suspend fun unload() = mutex.withLock {
        DiaEngine.unload()
        _state.value = ModelLoadState.Idle
    }

    /**
     * Best-effort autoload at app launch. Reads the saved path; if it exists
     * and the user has [DiaPrefs.autoLoadModel] enabled, kicks off a load.
     * Errors are surfaced through [state]; callers should always render
     * `state` regardless of whether they triggered the load themselves.
     */
    fun autoloadIfPreferred(context: Context) {
        if (!DiaPrefs.autoLoadModel.value) return
        if (DiaEngine.isReady) return
        val saved = ModelRegistry.savedLocalPath(context) ?: return
        if (!File(saved).exists()) return
        scope.launch { load(context, saved) }
    }
}

/**
 * Public model state surfaced by [ModelManager]. Distinct from
 * [ModelState] (the lower-level engine state) so we can layer UI-level
 * concerns (current path, name, OOM hint) without touching DiaEngine.
 */
sealed interface ModelLoadState {
    data object Idle : ModelLoadState
    data class Loading(
        val modelPath: String,
        val modelName: String,
        val progress: String,
    ) : ModelLoadState
    data class Ready(
        val modelPath: String,
        val modelName: String,
        val backend: String,
    ) : ModelLoadState
    data class Error(
        val message: String,
        /** True if the failure was an out-of-memory condition. */
        val oom: Boolean = false,
    ) : ModelLoadState
}
