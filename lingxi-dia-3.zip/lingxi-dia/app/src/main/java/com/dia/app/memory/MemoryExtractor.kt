package com.dia.app.memory

import android.util.Log
import com.dia.app.llm.LlmGateway
import com.dia.app.prefs.DiaSettings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

/**
 * 自动记忆：从对话中提取「以后还用得上」的关键信息。
 *
 * 两条路径：
 *  1. [quickExtract]：正则规则，零成本、立即生效（我叫…/我喜欢…/记住…）
 *  2. [scheduleLlmExtract]：对话空闲时让模型总结要点（JSON），可被新消息打断
 */
object MemoryExtractor {

    private const val TAG = "MemoryExtractor"
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    @Volatile
    private var job: Job? = null

    /** 用户发送新消息时调用：中断正在进行的后台提取，把模型让给用户。 */
    fun cancel() {
        val j = job ?: return
        if (j.isActive) {
            j.cancel()
            LlmGateway.cancelCurrent()
        }
        job = null
    }

    /** 规则提取：返回新写入的条目。 */
    fun quickExtract(userText: String): List<MemoryItem> {
        if (!DiaSettings.memoryEnabled.value) return emptyList()
        val found = MemoryRules.extract(userText)
        return found.mapNotNull { (content, cat) -> MemoryStore.add(content, cat, source = "auto") }
    }

    /**
     * 让模型从最近对话中提取记忆。[transcript] 为「用户：…\n灵犀：…」格式。
     * [onSaved] 在写入后回调（用于在对话里显示「已记住 …」）。
     */
    fun scheduleLlmExtract(transcript: String, onSaved: (List<MemoryItem>) -> Unit = {}) {
        if (!DiaSettings.memoryEnabled.value || !DiaSettings.autoMemory.value) return
        if (!LlmGateway.isAvailable()) return
        if (transcript.isBlank()) return
        cancel()
        job = scope.launch {
            try {
                val existing = MemoryStore.items.value.take(40).joinToString("\n") { "- ${it.content}" }
                val system = """你是记忆整理助手。从对话中找出关于「用户本人」的、长期有用的信息，
例如：姓名称呼、身份职业、所在城市、家人朋友、兴趣爱好、饮食/作息偏好、正在进行的项目、重要日期、明确的要求（如“以后回答简短一点”）。
不要记录：一次性的问题、AI 的回答内容、闲聊、常识、敏感信息（密码、银行卡、身份证号）。
已有记忆（不要重复）：
${existing.ifBlank { "（无）" }}

只输出 JSON 数组，每项形如 {"content":"用户的女儿叫小雨，今年6岁","category":"人际关系"}。
category 只能是：个人信息、偏好、工作学习、人际关系、计划待办、其他。
content 用第三人称“用户…”写成一句完整的话。没有值得记的就输出 []。"""
                val prompt = "【对话】\n${transcript.takeLast(2400)}\n\n请输出 JSON 数组："
                val out = LlmGateway.complete(
                    system = system,
                    prompt = prompt,
                    temperature = 0.1,
                    timeoutMs = 60_000L,
                )
                val saved = parseAndSave(out)
                if (saved.isNotEmpty()) onSaved(saved)
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.w(TAG, "llm extract failed: ${e.message}")
            }
        }
    }

    internal fun parseAndSave(raw: String): List<MemoryItem> {
        val start = raw.indexOf('[')
        val end = raw.lastIndexOf(']')
        if (start < 0 || end <= start) return emptyList()
        val arr = try { JSONArray(raw.substring(start, end + 1)) } catch (_: Exception) { return emptyList() }
        val out = ArrayList<MemoryItem>()
        for (i in 0 until minOf(arr.length(), 6)) {
            val any = arr.opt(i)
            val (content, cat) = when (any) {
                is JSONObject -> any.optString("content") to any.optString("category", "其他")
                is String -> any to "其他"
                else -> continue
            }
            if (content.isBlank() || content.length > 120) continue
            if (MemoryRules.looksSensitive(content)) continue
            MemoryStore.add(content, cat, source = "auto")?.let { out.add(it) }
        }
        return out
    }
}

/** 规则式记忆提取（纯 Kotlin，可单元测试）。 */
object MemoryRules {

    private data class Rule(val regex: Regex, val category: String, val template: (MatchResult) -> String)

    private fun clean(s: String): String = s.trim().trimEnd('。', '！', '!', '，', ',', '.', '~', '～', '？', '?').trim()

    private val rules = listOf(
        Rule(Regex("(?:请)?(?:帮我)?记住[:：,，]?\\s*(.{2,80})"), "其他") { clean(it.groupValues[1]).replace(Regex("^我的"), "用户的").replace(Regex("^我"), "用户") },
        Rule(Regex("我(?:的名字)?叫([\\u4e00-\\u9fa5A-Za-z·]{1,12})"), "个人信息") { "用户名叫${clean(it.groupValues[1])}" },
        Rule(Regex("(?:你)?(?:可以)?叫我([\\u4e00-\\u9fa5A-Za-z]{1,10})(?:就行|吧|就好)?"), "个人信息") { "用户希望被称呼为「${clean(it.groupValues[1]).removeSuffix("就行").removeSuffix("就好")}」" },
        Rule(Regex("我(?:今年)?(\\d{1,2})岁"), "个人信息") { "用户今年${it.groupValues[1]}岁" },
        Rule(Regex("我(?:住在|在|来自)([\\u4e00-\\u9fa5]{2,10}(?:省|市|区|县|镇))"), "个人信息") { "用户在${clean(it.groupValues[1])}" },
        Rule(Regex("我是(?:一名|一个|个)?([\\u4e00-\\u9fa5]{2,12}(?:师|员|生|家|者|工|长|士|老板|医生|学生|程序员))"), "工作学习") { "用户是${clean(it.groupValues[1])}" },
        Rule(Regex("我(?:很|特别|非常|超)?(?:喜欢|爱)([^，。,.!！?？]{1,30})"), "偏好") { "用户喜欢${clean(it.groupValues[1])}" },
        Rule(Regex("我(?:不喜欢|讨厌|不爱|不吃|不能吃|对)([^，。,.!！?？]{1,30}?)(?:过敏)?(?=[，。,.!！?？]|$)"), "偏好") { m ->
            val whole = m.value
            if (whole.contains("过敏")) "用户对${clean(m.groupValues[1]).removePrefix("对")}过敏" else "用户${clean(whole.removePrefix("我"))}"
        },
        Rule(Regex("(?:以后|今后)(?:请|你)?(?:回答|回复|说话)?([^，。,.!！?？]{2,30})"), "偏好") { "用户要求：以后${clean(it.groupValues[1])}" },
        Rule(Regex("我(?:老婆|妻子|老公|丈夫|女儿|儿子|妈妈|爸爸|母亲|父亲|女朋友|男朋友)叫([\\u4e00-\\u9fa5A-Za-z]{1,10})"), "人际关系") { m ->
            val rel = Regex("我(老婆|妻子|老公|丈夫|女儿|儿子|妈妈|爸爸|母亲|父亲|女朋友|男朋友)").find(m.value)?.groupValues?.get(1) ?: "家人"
            "用户的${rel}叫${clean(m.groupValues[1])}"
        },
        Rule(Regex("我的生日是([^，。,.!！?？]{2,15})"), "个人信息") { "用户的生日是${clean(it.groupValues[1])}" },
    )

    private val questionTail = Regex("[吗嘛呢？?]$")

    fun extract(text: String): List<Pair<String, String>> {
        val out = ArrayList<Pair<String, String>>()
        // 按句切分，避免一句里的问题被当成事实
        val sentences = text.split(Regex("[。！!？?\\n；;]")).map { it.trim() }.filter { it.isNotEmpty() }
        for (s in sentences) {
            if (questionTail.containsMatchIn(s)) continue
            if (s.startsWith("如果") || s.startsWith("假如") || s.contains("什么") || s.contains("怎么")) continue
            for (r in rules) {
                val m = r.regex.find(s) ?: continue
                val content = r.template(m)
                if (content.length < 3 || looksSensitive(content)) continue
                out.add(content to r.category)
                if (r.category == "其他") break
            }
        }
        return out.distinctBy { it.first }.take(4)
    }

    fun looksSensitive(s: String): Boolean {
        val lower = s.lowercase()
        if (lower.contains("密码") || lower.contains("password") || lower.contains("验证码")) return true
        if (Regex("\\d{15,}").containsMatchIn(s)) return true // 银行卡 / 身份证
        if (Regex("\\d{6}(19|20)\\d{2}\\d{4}\\d{3}[\\dXx]").containsMatchIn(s)) return true
        return false
    }
}
