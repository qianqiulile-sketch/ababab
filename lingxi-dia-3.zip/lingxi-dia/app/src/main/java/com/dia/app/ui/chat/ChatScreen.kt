package com.dia.app.ui.chat

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.automirrored.rounded.VolumeOff
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ProvideTextStyle
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLinkStyles
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.content.ContextCompat
import com.dia.app.files.FileRef
import com.dia.app.imagegen.ImageGen
import com.dia.app.llm.LlmGateway
import com.dia.app.llm.ModelLoadState
import com.dia.app.llm.ModelManager
import com.dia.app.prefs.DiaPrefs
import com.dia.app.prefs.DiaSettings
import com.dia.app.ui.theme.CloudDivider
import com.dia.app.ui.theme.DiaPal
import com.dia.app.ui.theme.DiaPalette
import com.dia.app.ui.theme.DiaSerif
import com.dia.app.ui.theme.SealMark
import com.dia.app.ui.theme.inkWashBackground
import com.dia.app.ui.theme.scrollFrame
import com.dia.app.voice.AudioScribeRecorder
import com.dia.app.voice.DiaTts
import com.halilibo.richtext.commonmark.Markdown
import com.halilibo.richtext.ui.CodeBlockStyle
import com.halilibo.richtext.ui.RichTextStyle
import com.halilibo.richtext.ui.material3.RichText
import com.halilibo.richtext.ui.string.RichTextStringStyle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** 百宝箱里会跳转到其它页面的入口。 */
enum class ToolPage { SETTINGS, MODEL_SETUP, LENS_LIVE, SLATE, HOME_MODE, PILOT, GUIDE }

fun Context.findActivity(): Activity? {
    var c: Context? = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(onOpenPage: (ToolPage) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val p = DiaPal.current

    val messages by ChatController.messages.collectAsState()
    val isGenerating by ChatController.isGenerating.collectAsState()
    val loadState by ModelManager.state.collectAsState()
    val title by ChatController.title.collectAsState()
    val thinking by ChatController.thinking.collectAsState()
    val pendingImages by ChatController.pendingImages.collectAsState()
    val pendingFiles by ChatController.pendingFiles.collectAsState()
    val selfLoop by ChatController.selfLoop.collectAsState()
    val draft by ChatController.draft.collectAsState()
    val activeChatId by ChatController.activeChatId.collectAsState()
    val threads by ChatHistoryStore.threads.collectAsState()
    val fontScale by DiaPrefs.chatFontScale.collectAsState()
    val autoSpeak by DiaPrefs.autoSpeak.collectAsState()
    val cloudOn by DiaPrefs.cloudEnabled.collectAsState()
    val webOn by DiaSettings.webEnabled.flow.collectAsState()
    val speakingId by DiaTts.speakingId.collectAsState()

    var input by remember { mutableStateOf("") }
    var showToolbox by remember { mutableStateOf(false) }
    var showHistory by remember { mutableStateOf(false) }
    var showModels by remember { mutableStateOf(false) }
    var showMemory by remember { mutableStateOf(false) }
    var showBackups by remember { mutableStateOf(false) }
    var showBubble by remember { mutableStateOf(false) }
    var showSelfLoop by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<ChatMessage?>(null) }
    var viewingImage by remember { mutableStateOf<String?>(null) }
    val listState = rememberLazyListState()

    LaunchedEffect(Unit) { ChatHistoryStore.init(context.applicationContext) }

    // 外部草稿（悬浮气泡「发到对话」等）
    LaunchedEffect(draft) {
        val d = ChatController.consumeDraft()
        if (!d.isNullOrBlank()) input = if (input.isBlank()) d else input + "\n" + d
    }

    // 界面事件
    LaunchedEffect(Unit) {
        ChatController.events.collect { e ->
            when {
                e == "move_to_back" -> context.findActivity()?.moveTaskToBack(true)
                e.startsWith("toast:") -> Toast.makeText(context, e.removePrefix("toast:"), Toast.LENGTH_SHORT).show()
            }
        }
    }

    LaunchedEffect(messages.size, messages.lastOrNull()?.text?.length) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1)
    }

    val last = messages.lastOrNull()
    LaunchedEffect(last?.id, last?.isStreaming) {
        if (autoSpeak && last != null && !last.isUser && last.kind == ChatMessage.KIND_TEXT &&
            !last.isStreaming && !last.isError && last.text.isNotBlank()
        ) DiaTts.speak(context, last.id, last.text)
    }
    DisposableEffect(Unit) { onDispose { DiaTts.stop() } }

    // ── 系统选择器 ──
    val pickImages = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris: List<Uri> ->
        uris.take(4).forEach { ChatController.addImageUri(it) }
    }
    val pickFiles = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris: List<Uri> ->
        uris.take(5).forEach { ChatController.addFileUri(it) }
    }
    val takePhoto = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { bmp: Bitmap? ->
        if (bmp != null) ChatController.addImage(bmp)
    }
    val cameraPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) takePhoto.launch(null) else Toast.makeText(context, "需要相机权限才能拍照", Toast.LENGTH_SHORT).show()
    }
    fun openCamera() {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            takePhoto.launch(null)
        } else cameraPerm.launch(Manifest.permission.CAMERA)
    }

    val modelReady = LlmGateway.isAvailable() || (loadState is ModelLoadState.Ready)
    val canSend = (input.isNotBlank() || pendingImages.isNotEmpty() || pendingFiles.isNotEmpty()) &&
        (!isGenerating || selfLoop.running)

    fun doSend() {
        val t = input
        input = ""
        ChatController.send(t)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .inkWashBackground(p)
            .windowInsetsPadding(WindowInsets.statusBars),
    ) {
        ChatHeader(
            p = p,
            title = title,
            loadState = loadState,
            cloudOn = cloudOn && DiaPrefs.cloudIsConfigured(),
            thinking = thinking,
            fontScale = fontScale,
            onHistory = { showHistory = true },
            onModel = { showModels = true },
            onNew = { ChatController.newChat() },
            onToggleThinking = { ChatController.setThinking(!thinking) },
            onFont = {
                DiaPrefs.setChatFontScale(
                    when {
                        fontScale < 0.95f -> 1.0f
                        fontScale < 1.15f -> 1.2f
                        else -> 0.85f
                    }
                )
            },
            onMemory = { showMemory = true },
            onBackups = { showBackups = true },
            onBubble = { showBubble = true },
            onTheme = { DiaSettings.themeMode.set(if (p.isDark) "paper" else "ink") },
            onClear = { ChatController.clearCurrent() },
            onSettings = { onOpenPage(ToolPage.SETTINGS) },
        )

        Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                state = listState,
                contentPadding = PaddingValues(vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                if (messages.isEmpty()) {
                    item {
                        EmptyHero(
                            p = p,
                            loadState = loadState,
                            modelReady = modelReady,
                            onPickModel = { showModels = true },
                            onSuggestion = { s ->
                                if (s.endsWith("：") || s.endsWith(" ")) input = s else { input = ""; ChatController.send(s) }
                            },
                        )
                    }
                }
                items(messages, key = { it.id }) { m ->
                    when (m.kind) {
                        ChatMessage.KIND_TOOL -> ToolCard(p, m)
                        ChatMessage.KIND_CONFIRM -> ConfirmCard(p, m) { ok -> ChatController.resolveConfirm(m.id, ok) }
                        ChatMessage.KIND_IMAGE -> GeneratedImageCard(p, m, onOpen = { viewingImage = it }, onSave = { path ->
                            scope.launch {
                                val uri = withContext(Dispatchers.IO) { ImageGen.saveToGallery(context, path) }
                                Toast.makeText(context, if (uri != null) "已保存到相册 Pictures/Dia" else "保存失败", Toast.LENGTH_SHORT).show()
                            }
                        })
                        ChatMessage.KIND_NOTE -> NoteRow(p, m.text)
                        else -> if (m.isUser) {
                            UserBubble(p, m, fontScale, onImage = { viewingImage = it }, onEdit = { editing = m }, onCopy = { copy(context, m.text) })
                        } else {
                            AssistantBubble(
                                p = p, m = m, fontScale = fontScale, speaking = speakingId == m.id,
                                onCopy = { copy(context, m.text) },
                                onSpeak = { DiaTts.toggle(context, m.id, m.text) },
                                onRetry = { ChatController.retryLast() },
                                onDelete = { ChatController.deleteMessage(m.id) },
                            )
                        }
                    }
                }
            }
        }

        if (selfLoop.running) SelfLoopBanner(p, selfLoop) { ChatController.stop() }

        if (pendingImages.isNotEmpty() || pendingFiles.isNotEmpty()) {
            PendingRow(p, pendingImages, pendingFiles)
        }

        InputBar(
            p = p,
            text = input,
            onText = { input = it },
            canSend = canSend,
            generating = isGenerating && !selfLoop.running,
            loopRunning = selfLoop.running,
            webOn = webOn,
            placeholder = when {
                selfLoop.running -> "插话：补充信息或改变讨论方向…"
                !modelReady -> "先选择模型（或输入 /画 描述 直接生图）"
                else -> "和灵犀说点什么…（输入 / 查看命令）"
            },
            onSend = { doSend() },
            onStop = { ChatController.stop() },
            onToolbox = { showToolbox = true },
            onToggleWeb = { DiaSettings.webEnabled.set(!webOn) },
            onVoice = { clip -> ChatController.send("", audio = clip) },
            modifier = Modifier
                .windowInsetsPadding(WindowInsets.navigationBars)
                .windowInsetsPadding(WindowInsets.ime),
        )
    }

    // ── 弹层 ──
    if (showToolbox) {
        val st = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ModalBottomSheet(onDismissRequest = { showToolbox = false }, sheetState = st, containerColor = p.surface) {
            ToolboxSheet(p = p) { action ->
                showToolbox = false
                when (action) {
                    "image" -> pickImages.launch("image/*")
                    "camera" -> openCamera()
                    "file" -> pickFiles.launch(arrayOf("*/*"))
                    "draw" -> input = "/画 "
                    "search" -> input = "/搜 "
                    "translate" -> input = "/译 "
                    "screen_translate" -> {
                        ChatController.send("帮我翻译屏幕上的内容")
                    }
                    "phone" -> input = "/控 "
                    "guide" -> input = "/引导 "
                    "loop" -> showSelfLoop = true
                    "memory" -> showMemory = true
                    "backup" -> showBackups = true
                    "bubble" -> showBubble = true
                    "lens" -> onOpenPage(ToolPage.LENS_LIVE)
                    "slate" -> onOpenPage(ToolPage.SLATE)
                    "home" -> onOpenPage(ToolPage.HOME_MODE)
                    "pilot" -> onOpenPage(ToolPage.PILOT)
                    "guide_page" -> onOpenPage(ToolPage.GUIDE)
                    "settings" -> onOpenPage(ToolPage.SETTINGS)
                    "help" -> ChatController.send("/帮助")
                }
                Unit
            }
        }
    }
    if (showHistory) {
        val st = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ModalBottomSheet(onDismissRequest = { showHistory = false }, sheetState = st, containerColor = p.surface) {
            HistorySheet(
                p = p, threads = threads, activeId = activeChatId,
                onPick = { ChatController.openHistory(it); showHistory = false },
                onDelete = { ChatController.deleteThread(it) },
                onNew = { ChatController.newChat(); showHistory = false },
                onClearAll = { scope.launch { ChatHistoryStore.deleteAll() } },
            )
        }
    }
    if (showModels) {
        val st = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ModalBottomSheet(onDismissRequest = { showModels = false }, sheetState = st, containerColor = p.surface) {
            ModelSheet(
                p = p, loadState = loadState,
                onPickLocal = { path ->
                    DiaPrefs.setCloudEnabled(false)
                    scope.launch { ModelManager.load(context, path) }
                    showModels = false
                },
                onPickCloud = { DiaPrefs.setCloudEnabled(true); showModels = false },
                onImport = { showModels = false; onOpenPage(ToolPage.MODEL_SETUP) },
                onUnload = { scope.launch { ModelManager.unload() }; showModels = false },
                onSwitchBackend = { b -> scope.launch { ModelManager.reload(context, b) }; showModels = false },
            )
        }
    }
    if (showMemory) {
        val st = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ModalBottomSheet(onDismissRequest = { showMemory = false }, sheetState = st, containerColor = p.surface) {
            MemorySheet(p)
        }
    }
    if (showBackups) {
        val st = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ModalBottomSheet(onDismissRequest = { showBackups = false }, sheetState = st, containerColor = p.surface) {
            BackupSheet(p, onAttach = { ref: FileRef -> ChatController.addExistingFile(ref); showBackups = false })
        }
    }
    if (showBubble) {
        val st = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ModalBottomSheet(onDismissRequest = { showBubble = false }, sheetState = st, containerColor = p.surface) {
            BubbleEditorSheet(p)
        }
    }
    if (showSelfLoop) {
        SelfLoopDialog(p, onDismiss = { showSelfLoop = false }) { topic, a, b, rounds ->
            showSelfLoop = false
            DiaSettings.selfLoopRoleA.set(a)
            DiaSettings.selfLoopRoleB.set(b)
            DiaSettings.selfLoopRounds.set(rounds)
            ChatController.startSelfLoop(topic, a, b, rounds)
        }
    }
    editing?.let { m ->
        EditMessageDialog(p, m.text, onDismiss = { editing = null }) { newText ->
            editing = null
            ChatController.editAndResend(m.id, newText)
        }
    }
    viewingImage?.let { path ->
        Dialog(onDismissRequest = { viewingImage = null }) {
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color.Black).clickable { viewingImage = null }) {
                LocalImage(path, Modifier.fillMaxWidth(), maxDim = 2048, contentScale = ContentScale.FillWidth)
            }
        }
    }
}

private fun copy(context: Context, text: String) {
    val clip = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    clip.setPrimaryClip(ClipData.newPlainText("灵犀", text))
    Toast.makeText(context, "已复制", Toast.LENGTH_SHORT).show()
}

// ───────── 头部 ─────────

@Composable
private fun ChatHeader(
    p: DiaPalette,
    title: String,
    loadState: ModelLoadState,
    cloudOn: Boolean,
    thinking: Boolean,
    fontScale: Float,
    onHistory: () -> Unit,
    onModel: () -> Unit,
    onNew: () -> Unit,
    onToggleThinking: () -> Unit,
    onFont: () -> Unit,
    onMemory: () -> Unit,
    onBackups: () -> Unit,
    onBubble: () -> Unit,
    onTheme: () -> Unit,
    onClear: () -> Unit,
    onSettings: () -> Unit,
) {
    val statusColor = when {
        cloudOn -> p.indigo
        loadState is ModelLoadState.Ready -> p.bamboo
        loadState is ModelLoadState.Loading -> p.gold
        loadState is ModelLoadState.Error -> p.error
        else -> p.textTertiary
    }
    val sub = when {
        cloudOn -> "云端 · ${DiaPrefs.cloudModel.collectAsState().value}"
        loadState is ModelLoadState.Ready -> "本地 · ${loadState.modelName} · ${loadState.backend}"
        loadState is ModelLoadState.Loading -> "加载中 · ${loadState.progress}"
        loadState is ModelLoadState.Error -> if (loadState.oom) "内存不足，点此换模型" else "模型加载失败，点此重选"
        else -> "未加载模型 · 点此选择"
    }
    var menu by remember { mutableStateOf(false) }
    Column {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onHistory) { Icon(Icons.Rounded.History, "历史对话", tint = p.textSecondary) }
            Row(
                modifier = Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).clickable(onClick = onModel)
                    .padding(horizontal = 6.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                SealMark("灵", size = 34.dp)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        if (title == "新对话") "灵犀" else title,
                        style = MaterialTheme.typography.titleLarge, color = p.text,
                        maxLines = 1, overflow = TextOverflow.Ellipsis,
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(7.dp).clip(CircleShape).background(statusColor))
                        Spacer(Modifier.width(5.dp))
                        Text(sub, style = MaterialTheme.typography.labelSmall, color = p.textTertiary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Icon(Icons.Rounded.KeyboardArrowDown, null, tint = p.textTertiary, modifier = Modifier.size(14.dp))
                    }
                }
            }
            IconButton(onClick = onNew) { Icon(Icons.Rounded.Add, "新对话", tint = p.textSecondary) }
            Box {
                IconButton(onClick = { menu = true }) { Icon(Icons.Rounded.MoreVert, "更多", tint = p.textSecondary) }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text(if (thinking) "深度思考：开" else "深度思考：关") }, onClick = { menu = false; onToggleThinking() })
                    DropdownMenuItem(text = {
                        Text("字号：" + when { fontScale < 0.95f -> "小"; fontScale < 1.15f -> "标准"; else -> "大" })
                    }, onClick = { menu = false; onFont() })
                    DropdownMenuItem(text = { Text(if (p.isDark) "切换为 宣纸（浅色）" else "切换为 墨夜（深色）") }, onClick = { menu = false; onTheme() })
                    HorizontalDivider()
                    DropdownMenuItem(text = { Text("记忆管理") }, onClick = { menu = false; onMemory() })
                    DropdownMenuItem(text = { Text("文件备份与还原") }, onClick = { menu = false; onBackups() })
                    DropdownMenuItem(text = { Text("悬浮气泡设置") }, onClick = { menu = false; onBubble() })
                    HorizontalDivider()
                    DropdownMenuItem(text = { Text("清空当前对话") }, onClick = { menu = false; onClear() })
                    DropdownMenuItem(text = { Text("设置") }, onClick = { menu = false; onSettings() })
                }
            }
        }
        CloudDivider(p, Modifier.padding(horizontal = 16.dp))
    }
}

// ───────── 空状态 ─────────

@Composable
private fun EmptyHero(
    p: DiaPalette,
    loadState: ModelLoadState,
    modelReady: Boolean,
    onPickModel: () -> Unit,
    onSuggestion: (String) -> Unit,
) {
    Column(
        modifier = Modifier.fillMaxWidth().padding(top = 48.dp, start = 24.dp, end = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        SealMark("灵犀", size = 76.dp)
        Spacer(Modifier.height(16.dp))
        Text("心有灵犀 · 一点即通", style = MaterialTheme.typography.headlineMedium, color = p.text, fontFamily = DiaSerif)
        Spacer(Modifier.height(6.dp))
        Text(
            "聊天、看图、读改文件、联网、翻译、画图、操控手机——都在这一个对话里",
            style = MaterialTheme.typography.bodySmall, color = p.textSecondary,
        )
        Spacer(Modifier.height(20.dp))
        if (!modelReady) {
            val (t, s) = when (loadState) {
                is ModelLoadState.Loading -> "正在加载模型…" to loadState.progress
                is ModelLoadState.Error -> "模型加载失败" to loadState.message.take(120)
                else -> "还没有加载模型" to "点这里选择本地模型，或在设置里配置云端模型"
            }
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(p.surface.copy(alpha = 0.85f))
                    .scrollFrame(p).clickable(onClick = onPickModel).padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                if (loadState is ModelLoadState.Loading) {
                    CircularProgressIndicator(color = p.cinnabar, strokeWidth = 2.dp, modifier = Modifier.size(28.dp))
                    Spacer(Modifier.height(8.dp))
                }
                Text(t, style = MaterialTheme.typography.titleMedium, color = p.text)
                Text(s, style = MaterialTheme.typography.bodySmall, color = p.textTertiary)
            }
            Spacer(Modifier.height(16.dp))
        }
        val suggestions = listOf(
            "联网查一下今天有什么重要新闻",
            "/画 烟雨江南，小桥流水，水墨画风",
            "帮我写一份请假条",
            "/自循环 年轻人该不该躺平",
            "记住我喜欢喝龙井茶",
            "把这句话译成英文：",
        )
        for (row in suggestions.chunked(2)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (s in row) {
                    Box(
                        Modifier.weight(1f).padding(vertical = 4.dp).clip(RoundedCornerShape(12.dp))
                            .background(p.surface.copy(alpha = 0.7f)).border(0.8.dp, p.border, RoundedCornerShape(12.dp))
                            .clickable { onSuggestion(s) }.padding(horizontal = 12.dp, vertical = 10.dp),
                    ) {
                        Text(s, style = MaterialTheme.typography.bodySmall, color = p.textSecondary, maxLines = 2)
                    }
                }
            }
        }
    }
}

// ───────── 消息 ─────────

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun UserBubble(
    p: DiaPalette,
    m: ChatMessage,
    fontScale: Float,
    onImage: (String) -> Unit,
    onEdit: () -> Unit,
    onCopy: () -> Unit,
) {
    var menu by remember { mutableStateOf(false) }
    Column(
        Modifier.fillMaxWidth().padding(start = 56.dp, end = 14.dp, top = 6.dp, bottom = 2.dp),
        horizontalAlignment = Alignment.End,
    ) {
        if (m.imagePaths.isNotEmpty()) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                for (path in m.imagePaths) {
                    LocalImage(
                        path,
                        Modifier.size(96.dp).clip(RoundedCornerShape(10.dp)).clickable { onImage(path) },
                        maxDim = 400, contentScale = ContentScale.Crop,
                    )
                }
            }
            Spacer(Modifier.height(4.dp))
        }
        if (m.fileNames.isNotEmpty()) {
            for (n in m.fileNames) FileChip(p, n, null)
            Spacer(Modifier.height(4.dp))
        }
        if (m.text.isNotBlank()) {
            Box {
                Box(
                    Modifier.clip(RoundedCornerShape(16.dp, 4.dp, 16.dp, 16.dp)).background(p.userBubble)
                        .combinedClickable(onClick = {}, onLongClick = { menu = true })
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                ) {
                    Text(
                        m.text,
                        style = MaterialTheme.typography.bodyLarge.copy(fontSize = (15 * fontScale).sp, lineHeight = (23 * fontScale).sp),
                        color = p.onUserBubble,
                    )
                }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("复制") }, onClick = { menu = false; onCopy() })
                    DropdownMenuItem(text = { Text("编辑后重新发送") }, onClick = { menu = false; onEdit() })
                }
            }
        }
        if (!m.hiddenContext.isNullOrBlank()) {
            Text("（附带了屏幕内容）", style = MaterialTheme.typography.labelSmall, color = p.textTertiary)
        }
    }
}

@Composable
private fun AssistantBubble(
    p: DiaPalette,
    m: ChatMessage,
    fontScale: Float,
    speaking: Boolean,
    onCopy: () -> Unit,
    onSpeak: () -> Unit,
    onRetry: () -> Unit,
    onDelete: () -> Unit,
) {
    val isPersonaB = m.persona != null && m.persona == ChatController.selfLoop.collectAsState().value.roleB
    Row(
        Modifier.fillMaxWidth().padding(start = 12.dp, end = 40.dp, top = 6.dp, bottom = 2.dp),
        verticalAlignment = Alignment.Top,
    ) {
        if (m.persona != null) {
            SealMark(m.persona.take(1), size = 28.dp, color = if (isPersonaB) p.indigo else p.gold)
        } else {
            SealMark("灵", size = 28.dp)
        }
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f)) {
            Text(
                m.persona ?: (m.source ?: "灵犀"),
                style = MaterialTheme.typography.labelSmall, color = p.textTertiary,
                modifier = Modifier.padding(start = 2.dp, bottom = 3.dp),
            )
            if (!m.thinking.isNullOrBlank() || m.isThinking) {
                ThinkingTrace(p, m.thinking.orEmpty(), m.isThinking, fontScale)
                Spacer(Modifier.height(4.dp))
            }
            Box(
                Modifier.clip(RoundedCornerShape(4.dp, 16.dp, 16.dp, 16.dp))
                    .background(p.surface.copy(alpha = 0.92f))
                    .scrollFrame(p, 16.dp)
                    .padding(horizontal = 14.dp, vertical = 11.dp),
            ) {
                when {
                    m.isError -> Column {
                        Text(m.text, style = MaterialTheme.typography.bodyMedium, color = p.error)
                        if (m.isRetryable) {
                            Spacer(Modifier.height(6.dp))
                            Text("点此重试", color = p.cinnabar, style = MaterialTheme.typography.labelMedium,
                                modifier = Modifier.clickable(onClick = onRetry))
                        }
                    }
                    m.text.isEmpty() && m.isStreaming -> TypingDots(p)
                    else -> SelectionContainer { MarkdownContent(p, cleanLaTeX(m.text), fontScale) }
                }
            }
            if (!m.isStreaming && m.text.isNotEmpty() && !m.isError) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onCopy, modifier = Modifier.size(30.dp)) {
                        Icon(Icons.Rounded.ContentCopy, "复制", tint = p.textTertiary, modifier = Modifier.size(15.dp))
                    }
                    IconButton(onClick = onSpeak, modifier = Modifier.size(30.dp)) {
                        Icon(
                            if (speaking) Icons.AutoMirrored.Rounded.VolumeOff else Icons.AutoMirrored.Rounded.VolumeUp,
                            "朗读", tint = if (speaking) p.cinnabar else p.textTertiary, modifier = Modifier.size(15.dp),
                        )
                    }
                    IconButton(onClick = onRetry, modifier = Modifier.size(30.dp)) {
                        Icon(Icons.Rounded.Refresh, "重新生成", tint = p.textTertiary, modifier = Modifier.size(15.dp))
                    }
                    IconButton(onClick = onDelete, modifier = Modifier.size(30.dp)) {
                        Icon(Icons.Rounded.Delete, "删除", tint = p.textTertiary, modifier = Modifier.size(15.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun ToolCard(p: DiaPalette, m: ChatMessage) {
    var expanded by remember { mutableStateOf(false) }
    val running = m.status == "running"
    val color = when (m.status) {
        "error" -> p.error
        "done" -> p.bamboo
        else -> p.gold
    }
    Column(
        Modifier.fillMaxWidth().padding(start = 48.dp, end = 24.dp, top = 2.dp, bottom = 2.dp)
            .clip(RoundedCornerShape(10.dp)).background(p.surfaceAlt.copy(alpha = 0.8f))
            .border(0.6.dp, color.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
            .clickable(enabled = !m.detail.isNullOrBlank()) { expanded = !expanded }
            .padding(horizontal = 12.dp, vertical = 8.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (running) {
                CircularProgressIndicator(color = color, strokeWidth = 1.5.dp, modifier = Modifier.size(14.dp))
            } else {
                Icon(if (m.status == "error") Icons.Rounded.Warning else Icons.Rounded.CheckCircle, null, tint = color, modifier = Modifier.size(15.dp))
            }
            Spacer(Modifier.width(8.dp))
            Text(
                toolIcon(m.toolName) + " " + (m.title ?: m.toolName.orEmpty()),
                style = MaterialTheme.typography.labelLarge, color = p.text,
                maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f),
            )
            if (!m.detail.isNullOrBlank()) {
                Icon(Icons.Rounded.KeyboardArrowDown, null, tint = p.textTertiary,
                    modifier = Modifier.size(16.dp).graphicsLayer { rotationZ = if (expanded) 180f else 0f })
            }
        }
        if (m.text.isNotBlank()) {
            Text(m.text, style = MaterialTheme.typography.bodySmall, color = if (m.status == "error") p.error else p.textSecondary,
                modifier = Modifier.padding(top = 4.dp, start = 22.dp))
        }
        AnimatedVisibility(visible = expanded && !m.detail.isNullOrBlank(), enter = expandVertically() + fadeIn(), exit = shrinkVertically() + fadeOut()) {
            SelectionContainer {
                Text(
                    m.detail.orEmpty(),
                    style = MaterialTheme.typography.bodySmall, color = p.textSecondary,
                    modifier = Modifier.padding(top = 6.dp).heightIn(max = 420.dp),
                )
            }
        }
    }
}

private fun toolIcon(name: String?): String = when (name) {
    "web_search" -> "🔍"
    "read_webpage" -> "🌐"
    "download" -> "⬇️"
    "read_file", "list_files" -> "📄"
    "edit_file", "create_file" -> "✍️"
    "restore_file" -> "♻️"
    "translate", "translate_screen" -> "🈯"
    "generate_image" -> "🎨"
    "open_app", "phone_task" -> "📱"
    "guide" -> "🧭"
    "remember", "forget" -> "📝"
    else -> "🔧"
}

@Composable
private fun ConfirmCard(p: DiaPalette, m: ChatMessage, onResolve: (Boolean) -> Unit) {
    val pending = m.status == "pending"
    Column(
        Modifier.fillMaxWidth().padding(start = 48.dp, end = 24.dp, top = 4.dp, bottom = 4.dp)
            .clip(RoundedCornerShape(12.dp)).background(p.surface)
            .border(1.dp, p.cinnabar.copy(alpha = if (pending) 0.8f else 0.3f), RoundedCornerShape(12.dp))
            .padding(14.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("🔏", fontSize = 16.sp)
            Spacer(Modifier.width(6.dp))
            Text(m.title.orEmpty(), style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold), color = p.text)
        }
        Spacer(Modifier.height(6.dp))
        Text(m.detail.orEmpty(), style = MaterialTheme.typography.bodySmall, color = p.textSecondary)
        Spacer(Modifier.height(10.dp))
        if (pending) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(
                    Modifier.clip(RoundedCornerShape(18.dp)).background(p.cinnabar).clickable { onResolve(true) }
                        .padding(horizontal = 18.dp, vertical = 8.dp),
                ) { Text("同意", color = p.onCinnabar, fontWeight = FontWeight.SemiBold) }
                Box(
                    Modifier.clip(RoundedCornerShape(18.dp)).border(1.dp, p.border, RoundedCornerShape(18.dp))
                        .clickable { onResolve(false) }.padding(horizontal = 18.dp, vertical = 8.dp),
                ) { Text("拒绝", color = p.textSecondary) }
            }
        } else {
            Text(
                if (m.status == "approved") "✓ 已同意" else "✗ 已拒绝",
                color = if (m.status == "approved") p.bamboo else p.textTertiary,
                style = MaterialTheme.typography.labelMedium,
            )
        }
    }
}

@Composable
private fun GeneratedImageCard(p: DiaPalette, m: ChatMessage, onOpen: (String) -> Unit, onSave: (String) -> Unit) {
    val path = m.imagePaths.firstOrNull() ?: return
    Column(Modifier.fillMaxWidth().padding(start = 48.dp, end = 32.dp, top = 4.dp, bottom = 4.dp)) {
        LocalImage(
            path,
            Modifier.fillMaxWidth().heightIn(max = 360.dp).clip(RoundedCornerShape(12.dp)).scrollFrame(p, 12.dp).clickable { onOpen(path) },
            maxDim = 1024, contentScale = ContentScale.FillWidth,
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                m.detail.orEmpty(), style = MaterialTheme.typography.labelSmall, color = p.textTertiary,
                maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f).padding(top = 4.dp),
            )
            IconButton(onClick = { onSave(path) }) { Icon(Icons.Rounded.Save, "保存到相册", tint = p.textSecondary, modifier = Modifier.size(18.dp)) }
        }
    }
}

@Composable
private fun NoteRow(p: DiaPalette, text: String) {
    Box(Modifier.fillMaxWidth().padding(horizontal = 32.dp, vertical = 4.dp), contentAlignment = Alignment.Center) {
        Text(
            text,
            style = MaterialTheme.typography.labelMedium, color = p.textTertiary,
            modifier = Modifier.clip(RoundedCornerShape(10.dp)).background(p.surfaceAlt.copy(alpha = 0.6f))
                .padding(horizontal = 12.dp, vertical = 6.dp),
        )
    }
}

@Composable
fun LocalImage(path: String, modifier: Modifier, maxDim: Int = 1024, contentScale: ContentScale = ContentScale.Fit) {
    val bmp by produceState<Bitmap?>(initialValue = null, path, maxDim) {
        value = withContext(Dispatchers.IO) { ImageUtil.decodeFile(path, maxDim) }
    }
    val b = bmp
    if (b != null) {
        Image(bitmap = b.asImageBitmap(), contentDescription = null, modifier = modifier, contentScale = contentScale)
    } else {
        Box(modifier.background(Color.Gray.copy(alpha = 0.2f)).heightIn(min = 80.dp))
    }
}

@Composable
private fun FileChip(p: DiaPalette, name: String, onRemove: (() -> Unit)?) {
    Row(
        Modifier.padding(vertical = 2.dp).clip(RoundedCornerShape(10.dp)).background(p.surfaceAlt)
            .border(0.6.dp, p.border, RoundedCornerShape(10.dp)).padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text("📎 ", fontSize = 12.sp)
        Text(name, style = MaterialTheme.typography.labelMedium, color = p.text, maxLines = 1, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.widthIn(max = 200.dp))
        if (onRemove != null) {
            Spacer(Modifier.width(4.dp))
            Icon(Icons.Rounded.Close, "移除", tint = p.textTertiary, modifier = Modifier.size(14.dp).clickable(onClick = onRemove))
        }
    }
}

@Composable
private fun ThinkingTrace(p: DiaPalette, text: String, inProgress: Boolean, fontScale: Float) {
    var expanded by remember { mutableStateOf(false) }
    LaunchedEffect(inProgress) { if (inProgress) expanded = true }
    Column {
        Row(
            Modifier.clickable { expanded = !expanded }.padding(vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Rounded.AutoAwesome, null, tint = p.gold, modifier = Modifier.size(13.dp))
            Spacer(Modifier.width(4.dp))
            Text(if (inProgress) "思考中…" else "查看思考过程", style = MaterialTheme.typography.labelMedium, color = p.gold)
        }
        AnimatedVisibility(visible = expanded && text.isNotBlank()) {
            val line = p.gold.copy(alpha = 0.4f)
            Text(
                text,
                style = MaterialTheme.typography.bodySmall.copy(fontSize = (12 * fontScale).sp),
                color = p.textSecondary,
                modifier = Modifier.padding(top = 2.dp)
                    .drawBehind { drawLine(line, Offset(0f, 0f), Offset(0f, size.height), 2.dp.toPx()) }
                    .padding(start = 10.dp),
            )
        }
    }
}

@Composable
private fun MarkdownContent(p: DiaPalette, text: String, fontScale: Float) {
    ProvideTextStyle(
        TextStyle(fontSize = (14.5 * fontScale).sp, lineHeight = (23 * fontScale).sp, color = p.text, letterSpacing = 0.2.sp)
    ) {
        RichText(
            style = RichTextStyle(
                codeBlockStyle = CodeBlockStyle(
                    textStyle = TextStyle(fontSize = (12.5 * fontScale).sp, fontFamily = FontFamily.Monospace, color = p.indigo),
                ),
                stringStyle = RichTextStringStyle(
                    linkStyle = TextLinkStyles(style = SpanStyle(color = p.cinnabar)),
                    boldStyle = SpanStyle(fontWeight = FontWeight.SemiBold, color = p.text),
                    codeStyle = SpanStyle(fontFamily = FontFamily.Monospace, color = p.indigo, background = p.surfaceAlt),
                ),
            ),
        ) { Markdown(content = text) }
    }
}

@Composable
private fun TypingDots(p: DiaPalette) {
    val t = rememberInfiniteTransition(label = "typing")
    Row(horizontalArrangement = Arrangement.spacedBy(5.dp), modifier = Modifier.padding(vertical = 4.dp)) {
        for (i in 0 until 3) {
            val a by t.animateFloat(0.2f, 0.9f, infiniteRepeatable(tween(600, delayMillis = i * 200, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "d$i")
            Box(Modifier.size(6.dp).clip(CircleShape).background(p.cinnabar.copy(alpha = a)))
        }
    }
}

private fun cleanLaTeX(text: String): String {
    var r = text
    r = r.replace(Regex("\\$\\$(.+?)\\$\\$", RegexOption.DOT_MATCHES_ALL)) { it.groupValues[1].trim() }
    r = r.replace(Regex("\\\\frac\\{([^}]*)\\}\\{([^}]*)\\}")) { "${it.groupValues[1]}/${it.groupValues[2]}" }
    r = r.replace(Regex("\\\\sqrt\\{([^}]*)\\}")) { "√${it.groupValues[1]}" }
    r = r.replace("\\times", "×").replace("\\cdot", "·").replace("\\pm", "±")
        .replace("\\leq", "≤").replace("\\geq", "≥").replace("\\neq", "≠").replace("\\approx", "≈")
        .replace("\\infty", "∞").replace("\\pi", "π").replace("\\rightarrow", "→")
    return r
}

// ───────── 自循环横幅 / 附件 / 输入栏 ─────────

@Composable
private fun SelfLoopBanner(p: DiaPalette, s: SelfLoopState, onStop: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp).clip(RoundedCornerShape(12.dp))
            .background(p.gold.copy(alpha = 0.15f)).border(0.8.dp, p.gold.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text("🔄", fontSize = 14.sp)
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f)) {
            Text("自循环 · 第 ${s.round}/${s.total} 轮", style = MaterialTheme.typography.labelLarge, color = p.text)
            Text("「${s.roleA}」⇄「${s.roleB}」· ${s.topic}", style = MaterialTheme.typography.labelSmall, color = p.textSecondary, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Box(
            Modifier.clip(RoundedCornerShape(14.dp)).background(p.cinnabar).clickable(onClick = onStop)
                .padding(horizontal = 12.dp, vertical = 6.dp),
        ) { Text("停止", color = p.onCinnabar, style = MaterialTheme.typography.labelMedium) }
    }
}

@Composable
private fun PendingRow(p: DiaPalette, images: List<String>, files: List<FileRef>) {
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        for (path in images) {
            Box {
                LocalImage(path, Modifier.size(56.dp).clip(RoundedCornerShape(8.dp)), maxDim = 200, contentScale = ContentScale.Crop)
                Box(
                    Modifier.align(Alignment.TopEnd).size(18.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.6f))
                        .clickable { ChatController.removePendingImage(path) },
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Rounded.Close, "移除", tint = Color.White, modifier = Modifier.size(12.dp)) }
            }
        }
        for (f in files) FileChip(p, "${f.id} · ${f.name}") { ChatController.removePendingFile(f.id) }
    }
}

@Composable
private fun InputBar(
    p: DiaPalette,
    text: String,
    onText: (String) -> Unit,
    canSend: Boolean,
    generating: Boolean,
    loopRunning: Boolean,
    webOn: Boolean,
    placeholder: String,
    onSend: () -> Unit,
    onStop: () -> Unit,
    onToolbox: () -> Unit,
    onToggleWeb: () -> Unit,
    onVoice: (com.dia.app.llm.AudioClip) -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val recorder = remember { AudioScribeRecorder() }
    val recState by recorder.state.collectAsState()
    val elapsed by recorder.elapsedMs.collectAsState()
    var hasMic by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
    }
    val micPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        hasMic = it
        if (it) recorder.start()
    }
    DisposableEffect(Unit) { onDispose { recorder.release() } }

    Column(modifier.fillMaxWidth().background(p.surface.copy(alpha = 0.92f))) {
        HorizontalDivider(color = p.border, thickness = 0.6.dp)
        if (recState == AudioScribeRecorder.State.RECORDING) {
            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { recorder.cancel() }) { Icon(Icons.Rounded.Close, "取消", tint = p.textSecondary) }
                Text(
                    "正在录音 · ${"%.1f".format(elapsed / 1000f)} 秒",
                    color = p.cinnabar, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f),
                )
                IconButton(
                    onClick = {
                        val bytes = recorder.stop()
                        if (bytes.isNotEmpty()) onVoice(com.dia.app.llm.AudioClip(pcm = bytes, sampleRate = recorder.sampleRate))
                    },
                    modifier = Modifier.size(44.dp).clip(CircleShape).background(p.cinnabar),
                ) { Icon(Icons.AutoMirrored.Rounded.Send, "发送语音", tint = p.onCinnabar, modifier = Modifier.size(20.dp)) }
            }
            return@Column
        }
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.Bottom,
            horizontalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            IconButton(
                onClick = onToolbox,
                modifier = Modifier.size(44.dp).clip(CircleShape).background(p.cinnabar.copy(alpha = 0.12f)),
            ) { Icon(Icons.Rounded.Add, "百宝箱", tint = p.cinnabar) }
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(22.dp)).background(p.background.copy(alpha = 0.6f))
                    .border(0.8.dp, p.border, RoundedCornerShape(22.dp)).padding(horizontal = 14.dp, vertical = 12.dp),
            ) {
                if (text.isEmpty()) Text(placeholder, color = p.textTertiary, style = MaterialTheme.typography.bodyMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                BasicTextField(
                    value = text, onValueChange = onText,
                    textStyle = TextStyle(color = p.text, fontSize = 15.sp, lineHeight = 22.sp),
                    cursorBrush = SolidColor(p.cinnabar),
                    maxLines = 6,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            Box(
                Modifier.size(44.dp).clip(CircleShape).clickable(onClick = onToggleWeb),
                contentAlignment = Alignment.Center,
            ) {
                Text("网", color = if (webOn) p.indigo else p.textTertiary, fontFamily = DiaSerif, fontWeight = FontWeight.Bold,
                    modifier = Modifier.alpha(if (webOn) 1f else 0.5f))
            }
            when {
                generating -> IconButton(
                    onClick = onStop,
                    modifier = Modifier.size(44.dp).clip(CircleShape).background(p.error),
                ) { Icon(Icons.Rounded.Stop, "停止", tint = p.onCinnabar) }
                canSend || loopRunning -> IconButton(
                    onClick = { if (canSend) onSend() },
                    modifier = Modifier.size(44.dp).clip(CircleShape).background(if (canSend) p.cinnabar else p.surfaceAlt),
                ) { Icon(Icons.AutoMirrored.Rounded.Send, "发送", tint = p.onCinnabar, modifier = Modifier.size(20.dp)) }
                else -> IconButton(
                    onClick = { if (hasMic) recorder.start() else micPerm.launch(Manifest.permission.RECORD_AUDIO) },
                    modifier = Modifier.size(44.dp).clip(CircleShape).background(p.indigo.copy(alpha = 0.15f)),
                ) { Icon(Icons.Rounded.Mic, "语音", tint = p.indigo) }
            }
        }
    }
}

// ───────── 对话框 ─────────

@Composable
private fun EditMessageDialog(p: DiaPalette, initial: String, onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var t by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("编辑消息") },
        text = { OutlinedTextField(value = t, onValueChange = { t = it }, modifier = Modifier.fillMaxWidth(), minLines = 3) },
        confirmButton = { TextButton(onClick = { if (t.isNotBlank()) onConfirm(t) }) { Text("重新发送", color = p.cinnabar) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("取消") } },
    )
}

@Composable
private fun SelfLoopDialog(p: DiaPalette, onDismiss: () -> Unit, onStart: (String, String, String, Int) -> Unit) {
    var topic by remember { mutableStateOf("") }
    var a by remember { mutableStateOf(DiaSettings.selfLoopRoleA.value) }
    var b by remember { mutableStateOf(DiaSettings.selfLoopRoleB.value) }
    var rounds by remember { mutableStateOf(DiaSettings.selfLoopRounds.value.toString()) }
    val presets = listOf(
        Triple("提问者", "解答者", "苏格拉底式追问"),
        Triple("正方", "反方", "辩论"),
        Triple("作者", "编辑", "写作打磨"),
        Triple("产品经理", "工程师", "方案评审"),
    )
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("AI 自循环") },
        text = {
            Column {
                Text("让两个 AI 角色围绕主题自己对话。进行中你可以随时插话补充信息，或点停止。",
                    style = MaterialTheme.typography.bodySmall, color = p.textSecondary)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = topic, onValueChange = { topic = it }, label = { Text("讨论主题") }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(6.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    for ((x, y, label) in presets) {
                        Text(
                            label, style = MaterialTheme.typography.labelMedium, color = p.text,
                            modifier = Modifier.clip(RoundedCornerShape(10.dp)).background(p.surfaceAlt)
                                .clickable { a = x; b = y }.padding(horizontal = 10.dp, vertical = 6.dp),
                        )
                    }
                }
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(value = a, onValueChange = { a = it }, label = { Text("角色甲") }, modifier = Modifier.weight(1f), singleLine = true)
                    OutlinedTextField(value = b, onValueChange = { b = it }, label = { Text("角色乙") }, modifier = Modifier.weight(1f), singleLine = true)
                }
                Spacer(Modifier.height(6.dp))
                OutlinedTextField(value = rounds, onValueChange = { v -> rounds = v.filter { it.isDigit() }.take(2) }, label = { Text("轮数（每轮双方各说一次）") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (topic.isNotBlank()) onStart(topic.trim(), a.trim(), b.trim(), rounds.toIntOrNull()?.coerceIn(1, 30) ?: 6)
            }) { Text("开始", color = p.cinnabar) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("取消") } },
    )
}
