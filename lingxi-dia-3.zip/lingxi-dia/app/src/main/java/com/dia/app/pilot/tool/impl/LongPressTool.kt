package com.dia.app.pilot.tool.impl

import com.dia.app.pilot.tool.BaseTool
import com.dia.app.pilot.tool.ToolParameter
import com.dia.app.pilot.tool.ToolResult

class LongPressTool : BaseTool() {
    override fun getName(): String = "long_press"

    override fun getDescription(): String = "Long-press at coordinates or a node ID to trigger context menus or hold actions."

    override fun getParameters(): List<ToolParameter> = listOf(
        ToolParameter("x", "integer", "X coordinate on screen", false),
        ToolParameter("y", "integer", "Y coordinate on screen", false),
        ToolParameter("node_id", "string", "Optional node ID from get_screen_info", false),
        ToolParameter("duration_ms", "integer", "Duration in ms (default 600)", false),
    )

    override fun execute(params: Map<String, Any>): ToolResult {
        return try {
            val service = requireAccessibilityService() ?: return ToolResult.error("Accessibility service is not running")
            val durationMs = optionalLong(params, "duration_ms", 600)

            val nodeId = optionalString(params, "node_id", "").replace("[", "").replace("]", "").trim()
            if (nodeId.isNotBlank()) {
                val coords = service.getNodeCoordinates(nodeId)
                    ?: return ToolResult.error("Node $nodeId not found. Call get_screen_info first.")
                val success = service.performLongPress(coords[0], coords[1], durationMs)
                return if (success) ToolResult.success("Long-pressed node $nodeId at (${coords[0]},${coords[1]})")
                else ToolResult.error("Failed to long-press node $nodeId")
            }

            val x = requireInt(params, "x")
            val y = requireInt(params, "y")
            val success = service.performLongPress(x, y, durationMs)
            return if (success) ToolResult.success("Long-pressed at ($x, $y)")
            else ToolResult.error("Failed to long-press at ($x, $y)")
        } catch (e: Exception) {
            ToolResult.error("Long-press error: ${e.message}")
        }
    }
}
