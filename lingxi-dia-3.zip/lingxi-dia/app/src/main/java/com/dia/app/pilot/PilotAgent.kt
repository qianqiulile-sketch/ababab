package com.dia.app.pilot

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.dia.app.llm.DiaEngine
import com.dia.app.pilot.tool.ToolRegistry
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import org.json.JSONObject
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import kotlin.coroutines.resume

/**
 * Application-scoped Pilot automation agent.
 *
 * Survives UI recomposition and navigation. A foreground service runs for the
 * duration of an active task so Android doesn't kill the process while Dia is
 * backgrounded controlling another app.
 *
 * Model calls are stateless — each turn ships a fresh prompt to a new engine
 * conversation. PokeClaw-style stuck detection escalates recovery through
 * three levels: hint → strategy switch → force finish.
 */
object PilotAgent {

    private const val TAG = "PilotAgent"
    private const val MAX_STEPS = 40
    private const val SCREEN_TREE_CHAR_BUDGET = 1200
    /** Cloud models have headroom — let them see the full tree. */
    private const val SCREEN_TREE_CHAR_BUDGET_CLOUD = 6000
    private const val HISTORY_LINES = 3
    private const val STUCK_WINDOW = 3
    private const val MAX_CONSECUTIVE_STUCK_HINTS = 2

    private const val SYSTEM_PROMPT = """You are an Android phone automation agent powered by Gemma. You complete tasks by calling ONE tool per turn and reading the screen between turns.

OUTPUT FORMAT: Exactly ONE JSON object. Nothing else. No prose, no markdown, no explanation.
{"tool":"tool_name","params":{"key":"value"}}

YOUR TOOLS:
- open_app(app_name)        Launch an installed app. Use FIRST when the task names an app.
- search_in_app(query)      Inside the current app: finds search bar, taps it, types, presses Enter. ALWAYS use this for "search for X" tasks.
- send_message(contact, message, app?)   Send a message in WhatsApp/Telegram/Messages — does the WHOLE flow (open app, find contact, type, send) in one call. ALWAYS use this for messaging tasks.
- make_call(contact)        Open the dialer with a contact's number ready to call. Use for "call mom", "call dad" etc.
- get_notifications()       Read all active notifications without pulling down the shade. Use for "what are my notifications", "any new messages".
- clipboard(action, text?)  action='get' reads the clipboard, action='set' writes. Use for "what's on my clipboard", "copy this".
- get_installed_apps(keyword?)  List installed apps. Optional keyword filter. Use for "what apps do I have".
- get_screen_info()         Fetch the current screen as a list of nodes.
- tap_node(node_id)         Tap a node. node_id is JUST the bracket id, e.g. "n5" — never the whole line.
- find_and_tap(text)        Find visible text on screen and tap it. For known buttons like "Add", "Send", "Compose".
- input_text(text, node_id?, submit?) Type into a focused EDIT. submit=true presses Enter.
- scroll_to_find(text)      Scroll to find then tap matching text.
- system_key(key)           Press "back", "home", "recents", or "enter".
- open_url(url) | open_url(query)  Open a URL or run a Google search. ONLY for websites, NEVER for apps.
- tap(x,y)                  Tap exact coordinates. Last resort.
- get_device_info(category) Read battery / wifi / time / storage / device / bluetooth / screen.
- wait(duration_ms)         Pause.
- finish(summary)           End. ONLY when the goal is VISIBLY complete on screen.

READING THE SCREEN TREE:
Each line looks like:  [n5] "Settings" TAP @540,300
- The id is "n5" — that's the only thing you ever pass as node_id.
- TAP = clickable, EDIT = text input, hint="..." = empty input placeholder text.
- MIC = a microphone / voice-search button. Do NOT tap this to search. It opens voice input.
- CAM = a camera / lens / scan button. Do NOT tap this to search.
- The first line "APP: com.xxx" tells you which app is in foreground.

CRITICAL RULES:
1. If the task names an APP (Gmail, Swiggy, Amazon, YouTube...), your FIRST call is open_app. Never open_url for apps.
2. When the task says "search for X" — call search_in_app(query="X"). Do not try to find the search bar, tap it, type, and submit yourself. The search_in_app tool does all of that.
3. EMAILS containing @ are addresses, not search strings. If the task contains an email, the goal is to compose a message — open Gmail, tap Compose, fill the To field with the email, fill body, send.
4. Don't open an app that's already open. Check "APP: ..." at the top first.
5. Don't describe what you'll do. Output the JSON tool call and stop.
6. Don't finish until the result is visible on screen (item in cart, message sent, video playing, settings toggled).
7. If a tool fails, read the error and pick a different tool — don't repeat the same call.
8. node_id is ONLY the bracket id like "n5". If you write "[n5] hint=\"Search\" EDIT" the call will fail.
9. When you need to TYPE something (message, search, email body), look for the EDIT node and use input_text. Do NOT tap a person's name or a header — those open profiles/info screens.
10. If the screen has an EDIT field and your goal is to type into it, call input_text DIRECTLY. You don't need to tap the EDIT node first — input_text handles focus automatically.

EXAMPLES:

Task: "Open Swiggy and search for biryani"
Turn 1: {"tool":"open_app","params":{"app_name":"Swiggy"}}
Turn 2 (after Swiggy is on screen): {"tool":"search_in_app","params":{"query":"biryani"}}
Turn 3 (results visible): {"tool":"finish","params":{"summary":"Searched Swiggy for biryani"}}

Task: "Open Zomato and in that search for pizza and then fries"
The FIRST app named is Zomato → open Zomato. The thing to search is the WHOLE remaining query.
Turn 1: {"tool":"open_app","params":{"app_name":"Zomato"}}
Turn 2: {"tool":"search_in_app","params":{"query":"pizza fries"}}
Turn 3: {"tool":"finish","params":{"summary":"Searched Zomato for pizza fries"}}

Task: "Open YouTube and search for cooking videos"
Turn 1: {"tool":"open_app","params":{"app_name":"YouTube"}}
Turn 2: {"tool":"search_in_app","params":{"query":"cooking videos"}}
Turn 3: {"tool":"finish","params":{"summary":"YouTube search complete"}}

Task: "Search YouTube for X and play the first video"
Turn 1: {"tool":"open_app","params":{"app_name":"YouTube"}}
Turn 2: {"tool":"search_in_app","params":{"query":"X"}}
Turn 3 (results page now shows video thumbnails as TAP rows): tap the first non-MIC, non-CAM video item with tap_node using its id from the screen tree.
Turn 4: {"tool":"finish","params":{"summary":"Playing first result"}}

Task: "What's my battery"
Turn 1: {"tool":"get_device_info","params":{"category":"battery"}}
Turn 2: {"tool":"finish","params":{"summary":"Battery: 73%"}}

Task: "Read my notifications"
Turn 1: {"tool":"get_notifications","params":{}}
Turn 2: {"tool":"finish","params":{"summary":"<the actual notifications, summarized>"}}

Task: "Call Mom"
Turn 1: {"tool":"make_call","params":{"contact":"Mom"}}
Turn 2: {"tool":"finish","params":{"summary":"Dialer opened for Mom"}}

Task: "What apps do I have for music"
Turn 1: {"tool":"get_installed_apps","params":{"keyword":"music"}}
Turn 2: {"tool":"finish","params":{"summary":"<the matching apps>"}}

Task: "What's on my clipboard"
Turn 1: {"tool":"clipboard","params":{"action":"get"}}
Turn 2: {"tool":"finish","params":{"summary":"<clipboard content>"}}

Task: "Email alice@example.com saying meeting at 5"
Turn 1: {"tool":"open_app","params":{"app_name":"Gmail"}}
Turn 2: {"tool":"find_and_tap","params":{"text":"Compose"}}
Turn 3: {"tool":"input_text","params":{"text":"alice@example.com"}}   (To field is auto-focused)
Turn 4: {"tool":"system_key","params":{"key":"tab"}} or tap the body field
Turn 5: {"tool":"input_text","params":{"text":"Meeting at 5"}}
Turn 6: {"tool":"find_and_tap","params":{"text":"Send"}}
Turn 7: {"tool":"finish","params":{"summary":"Email sent"}}

Task: "Send a message to Lakshya on WhatsApp saying hey what's up"
Turn 1: {"tool":"send_message","params":{"contact":"Lakshya","message":"hey what's up","app":"WhatsApp"}}
Turn 2: {"tool":"finish","params":{"summary":"Message sent to Lakshya"}}
NOTE: send_message handles EVERYTHING — opening WhatsApp, finding Lakshya, typing, and tapping send. You make ONE tool call, not five. Do NOT call open_app, do NOT call search_in_app, do NOT call input_text. Just call send_message.

IMPORTANT — MESSAGING APPS:
- For ANY task like "send a message to X" / "tell X" / "message X on WhatsApp" → use send_message in a SINGLE call.
- The contact arg is the person's name (first name is fine). The message arg is the message body. The app arg is optional and defaults to WhatsApp.
- Do NOT navigate manually. Do NOT tap the contact name in the toolbar. The send_message tool does it all.

PARSING RULES (read these carefully):
- The FIRST app/website/system name in the task is the app to open. "Open X and search for Y" → open X, search Y. NOT search X for Y.
- Anything after "search for" is the search query, even if it contains a brand name or food name. Restaurant names, product names, brand names AFTER "search" are queries, NOT apps.
- "and then Z" means continue with Z after the previous step. If both are search-like, combine them into one query.
- Read the task as a whole sentence. Do not match isolated words against your examples.

AFTER TYPING — submitting:
- input_text auto-presses Enter when submit=true (default). You usually don't need to do anything else.
- If you typed but nothing happened, call system_key(key="enter") — NEVER find_and_tap("search") after typing. The mic / voice icon often gets matched by "search" and it will undo your work.
- Same for find_and_tap("send") after composing — search for the actual visible label like "Send" with a capital S, or use the node id.

NEVER TAP THESE NODES UNLESS THE TASK IS LITERALLY "USE VOICE SEARCH":
- Anything with the MIC marker on its line.
- Anything with the CAM marker on its line.
These open voice / camera input. They do NOT submit the search and they will not advance the task. Pick a different node.

Now think step by step and emit ONE tool call for the next turn."""

    private val actionTools = setOf(
        "tap", "tap_node", "long_press", "swipe", "input_text", "system_key", "open_app",
        "find_and_tap", "scroll_to_find", "open_url"
    )

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val mainHandler = Handler(Looper.getMainLooper())
    private val running = AtomicBoolean(false)
    private val cancelled = AtomicBoolean(false)
    private var currentJob: Job? = null
    private val idSeq = AtomicLong()

    private val _state = MutableStateFlow(PilotState())
    val state: StateFlow<PilotState> = _state.asStateFlow()

    private val _log = MutableStateFlow<List<PilotLogEntry>>(emptyList())
    val log: StateFlow<List<PilotLogEntry>> = _log.asStateFlow()

    private val _events = MutableSharedFlow<PilotEvent>(extraBufferCapacity = 64)
    val events: SharedFlow<PilotEvent> = _events.asSharedFlow()

    @Volatile
    private var appContext: Context? = null

    @Volatile
    var lastTask: String? = null
        private set

    init {
        ToolRegistry.registerAll()
    }

    fun attach(context: Context) {
        if (appContext == null) appContext = context.applicationContext
    }

    fun isRunning(): Boolean = running.get()

    fun clearLog() { _log.value = emptyList() }

    fun start(task: String) {
        val ctx = appContext
        if (running.getAndSet(true)) return
        cancelled.set(false)

        DiaEngine.cancelPilotSession()
        clearLog()

        // Strip any manual override prefix from the visible task before we
        // store / display it. The classifier still sees the original raw
        // task so the prefix can affect routing.
        val cleanedTask = task
            .removePrefix("cloud:").removePrefix("CLOUD:")
            .removePrefix("[cloud]").removePrefix("[CLOUD]")
            .removePrefix("local:").removePrefix("LOCAL:")
            .removePrefix("[local]").removePrefix("[LOCAL]")
            .trim()

        _state.value = PilotState(running = true, task = cleanedTask, stepIndex = 0, lastMessage = "Starting…")
        lastTask = cleanedTask
        emit(PilotEvent.Started(cleanedTask))
        appendLog(PilotLogEntry.Kind.STARTED, "Started: $cleanedTask")

        ctx?.let {
            PilotForegroundService.start(it, "Pilot · ${cleanedTask.take(40)}", "Starting…")
        }

        currentJob = scope.launch {
            try {
                // Backend routing is now model-driven for ambiguous prompts —
                // we suspend here briefly to ask Gemma to pick LOCAL vs CLOUD.
                pickBackendForTask(task)
                runLoop(cleanedTask)
            } catch (t: Throwable) {
                Log.e(TAG, "runLoop crashed", t)
                fail("Internal error: ${t.message}")
            } finally {
                running.set(false)
                DiaEngine.cancelPilotSession()
                appContext?.let { PilotForegroundService.stop(it) }
            }
        }
    }

    fun stop() {
        cancelled.set(true)
        currentJob?.cancel()
        currentJob = null
        running.set(false)
        DiaEngine.cancelPilotSession()
        appContext?.let { PilotForegroundService.stop(it) }
        _state.update { it.copy(running = false, lastMessage = "Stopped by user") }
        emit(PilotEvent.Finished("Stopped by user"))
        appendLog(PilotLogEntry.Kind.FINISHED, "✓ Stopped by user")
    }

    fun repeatLast() {
        val task = lastTask ?: return
        start(task)
    }

    private fun fail(message: String) {
        _state.update { it.copy(running = false, lastMessage = message) }
        emit(PilotEvent.Failed(message))
        appendLog(PilotLogEntry.Kind.FAILED, "✗ $message")
    }

    // ─── Main loop ───

    private suspend fun runLoop(task: String) {
        val toolSpec = buildCompactToolSpec()
        val history = ArrayDeque<String>()

        notifyProgress("Reading screen…")
        step(0, "Reading screen…")
        var screen = readScreen()

        val recentCalls = ArrayDeque<String>()
        val recentScreenHashes = ArrayDeque<Int>()
        var consecutiveErrors = 0
        var stuckHintCount = 0
        // Guidance injected in the next prompt by the stuck detector.
        var recoveryHint: String? = null
        // If not null, we bypass the LLM on the next step and execute this tool.
        var forcedAction: Pair<String, Map<String, Any>>? = null

        for (stepIdx in 1..MAX_STEPS) {
            if (cancelled.get() || !scope.isActive) return

            val toolName: String
            val paramsMap: Map<String, Any>
            val rawJson: String

            if (forcedAction != null) {
                toolName = forcedAction.first
                paramsMap = forcedAction.second
                rawJson = """{"tool":"$toolName","params":${JSONObject(paramsMap)}}"""
                appendLog(PilotLogEntry.Kind.INFO, "↪ forced: $toolName $paramsMap")
                forcedAction = null
            } else {
                step(stepIdx, "Thinking…")
                notifyProgress("Step $stepIdx · thinking…")

                val prompt = buildPrompt(task, screen, history, toolSpec, stepIdx, recoveryHint)
                recoveryHint = null

                val response = callModel(prompt)
                if (cancelled.get()) return

                var jsonText = extractJson(response)
                if (jsonText.isNullOrBlank()) {
                    val repair = callModel(buildRepairPrompt(response))
                    jsonText = extractJson(repair)
                }
                if (jsonText.isNullOrBlank()) {
                    history.pushTrim("_ parse failure — refreshed screen")
                    screen = readScreen()
                    continue
                }

                val parsed = try { JSONObject(jsonText) } catch (e: Exception) {
                    Log.e(TAG, "Bad JSON: $jsonText", e)
                    history.pushTrim("_ bad json — refreshed screen")
                    screen = readScreen()
                    continue
                }

                val finishMsg = parsed.optString("finish", "")
                if (finishMsg.isNotBlank()) {
                    // Guard: if the "finish" summary mentions future actions, the
                    // model is narrating instead of acting. Don't finish — re-plan.
                    if (looksLikePrematureFinish(finishMsg)) {
                        recoveryHint = "You said you would do something next but didn't do it. Actually execute the action now — don't describe it."
                        screen = readScreen()
                        continue
                    }
                    finish(finishMsg); return
                }

                toolName = parsed.optString("tool", "")
                if (toolName.isBlank()) {
                    history.pushTrim("_ no tool — refreshed screen")
                    screen = readScreen()
                    continue
                }
                if (toolName == "finish") {
                    val summary = parsed.optJSONObject("params")?.optString("summary", "Done") ?: "Done"
                    if (looksLikePrematureFinish(summary)) {
                        recoveryHint = "You described what to do next but didn't do it. Execute the action now."
                        screen = readScreen()
                        continue
                    }
                    finish(summary)
                    return
                }
                paramsMap = jsonToMap(parsed.optJSONObject("params") ?: JSONObject())
                rawJson = jsonText
            }

            // ── Stuck detection ──
            val fingerprint = "$toolName:${paramsMap}"
            recentCalls.addLast(fingerprint)
            while (recentCalls.size > STUCK_WINDOW) recentCalls.removeFirst()
            val sameActionStuck =
                recentCalls.size == STUCK_WINDOW && recentCalls.all { it == fingerprint }

            if (sameActionStuck) {
                stuckHintCount++
                val escalation = strategySwitchFor(toolName, paramsMap, task)
                if (escalation != null && stuckHintCount <= MAX_CONSECUTIVE_STUCK_HINTS) {
                    // Level 2: force a different tool for the next step.
                    appendLog(
                        PilotLogEntry.Kind.INFO,
                        "↻ stuck on $toolName — switching strategy to ${escalation.first}"
                    )
                    forcedAction = escalation
                    recentCalls.clear()
                    // Give the UI time to show whatever last tap did before we force.
                    delay(300)
                    continue
                } else {
                    finish("Stuck repeating $toolName — stopping")
                    return
                }
            }

            // ── Execute ──
            emitTool(toolName, rawJson)
            notifyProgress("Step $stepIdx · $toolName ${shortParamsText(paramsMap)}")

            val result = try {
                ToolRegistry.executeTool(toolName, paramsMap)
            } catch (e: Exception) {
                Log.e(TAG, "Tool crash: $toolName", e)
                com.dia.app.pilot.tool.ToolResult.error("Tool crashed: ${e.message}")
            }

            val resultText = (result.data ?: result.error ?: "").take(220)
            emitToolResult(toolName, resultText)

            // Feature #8: Spoken Pilot status updates via TTS
            if (com.dia.app.prefs.DiaPrefs.pilotSpeak.value) {
                val spoken = when (toolName) {
                    "open_app" -> "Opened app"
                    "search_in_app" -> "Searching"
                    "send_message" -> "Message sent"
                    "make_call" -> "Calling"
                    "tap_node", "tap", "find_and_tap" -> "Tapped"
                    "input_text" -> "Typed"
                    "finish" -> resultText.take(80)
                    else -> null
                }
                if (spoken != null) {
                    try {
                        val ctx = appContext
                        if (ctx != null) com.dia.app.voice.DiaTts.speak(ctx, "pilot_status", spoken)
                    } catch (_: Exception) {}
                }
            }

            history.pushTrim(formatHistory(toolName, result.isSuccess, resultText))
            notifyProgress("Step $stepIdx · ${if (result.isSuccess) "✓" else "✗"} $toolName")
            // Cloud-only: remember every tool call and its outcome so the
            // remote model isn't blind on the next turn.
            recordCloudToolOutcome(rawJson, resultText, result.isSuccess)

            if (!result.isSuccess) {
                consecutiveErrors++
                // Attach a hint for the next prompt explaining what went wrong.
                recoveryHint = errorRecoveryHint(toolName, resultText, paramsMap)
                if (consecutiveErrors >= 4) {
                    finish("Too many consecutive errors — giving up")
                    return
                }
            } else {
                consecutiveErrors = 0
                stuckHintCount = 0
            }

            if (actionTools.contains(toolName)) {
                delay(delayAfter(toolName))
                screen = readScreen()

                // Detect accidental navigation to profile / info / encryption
                // screens (common in WhatsApp when model taps contact name).
                // If we just tapped and the new screen mentions these, auto-
                // inject a "go back" hint so the model doesn't get lost.
                if (toolName == "tap_node" || toolName == "find_and_tap" || toolName == "tap") {
                    val screenLower = screen.lowercase()
                    val accidentalProfile = listOf("encryption", "disappearing messages", "block", "report",
                        "mute notifications", "media, links", "contact info", "about and phone")
                        .count { screenLower.contains(it) } >= 2
                    if (accidentalProfile && recoveryHint == null) {
                        recoveryHint = "You accidentally opened a profile/info screen. " +
                            "Press system_key(key=\"back\") to return to the chat, then use " +
                            "input_text to type your message into the EDIT field."
                    }
                }

                // If we just tapped something that should have opened an
                // input (search icon, address bar, etc.) and the new screen
                // has no EDIT markers, give YouTube/Chrome another beat to
                // finish the transition. Prevents "no editable field" on the
                // very next step.
                val shouldHaveInput = (toolName == "find_and_tap" || toolName == "tap_node" ||
                    toolName == "tap" || toolName == "open_url") &&
                    !screen.contains(" EDIT ")
                if (shouldHaveInput) {
                    delay(800)
                    screen = readScreen()
                }

                val hash = screen.hashCode()
                recentScreenHashes.addLast(hash)
                while (recentScreenHashes.size > STUCK_WINDOW) recentScreenHashes.removeFirst()
                // Screen-unchanged detection
                if (recentScreenHashes.size == STUCK_WINDOW &&
                    recentScreenHashes.all { it == hash }
                ) {
                    // If we just typed and the screen didn't change, the
                    // submit obviously didn't fire. Force enter.
                    if (toolName == "input_text") {
                        forcedAction = "system_key" to mapOf("key" to "enter")
                        appendLog(
                            PilotLogEntry.Kind.INFO,
                            "↻ typed but screen unchanged — forcing Enter"
                        )
                    } else {
                        recoveryHint = "Screen hasn't changed for $STUCK_WINDOW steps. " +
                            "Your last actions had no effect. Try a different approach — " +
                            "use open_url directly, or press system_key(key=\"back\") and re-plan."
                    }
                    recentScreenHashes.clear()
                }
            } else if (toolName == "get_screen_info") {
                screen = result.data ?: screen
            }

            delay(120)
        }

        finish("Reached max steps")
    }

    private fun delayAfter(tool: String): Long = when (tool) {
        "open_app" -> 1500
        "open_url" -> 2200
        "input_text" -> 500
        "system_key" -> 600
        else -> 700
    }

    /**
     * Pick a different tool when the agent is spinning on the same action.
     * Matches PokeClaw's StuckDetector strategy-switch level.
     */
    private fun strategySwitchFor(
        tool: String,
        params: Map<String, Any>,
        task: String,
    ): Pair<String, Map<String, Any>>? {
        return when (tool) {
            "search_in_app" -> {
                // search_in_app failed twice in a row — fall back to the
                // manual two-step path. Tap whatever is labeled "Search",
                // then the model will see the focused field next turn.
                "find_and_tap" to mapOf("text" to "Search")
            }
            "find_and_tap" -> {
                // Text not on screen — force a screen read so the model can
                // find the search bar and use input_text instead.
                "get_screen_info" to emptyMap()
            }
            "scroll_to_find" -> {
                // Give up scrolling — force screen read to find search bar.
                "get_screen_info" to emptyMap()
            }
            "input_text" -> {
                // Typed but nothing happened — submit via Enter.
                "system_key" to mapOf("key" to "enter")
            }
            "tap_node" -> {
                // Node id may be stale — refresh the screen tree.
                "get_screen_info" to emptyMap()
            }
            "open_app" -> {
                // App launch intent failed — fall back to a URL search.
                "open_url" to mapOf("query" to task.take(80))
            }
            else -> null
        }
    }

    /**
     * Produce a concise hint for the next prompt explaining what just went wrong.
     */
    private fun errorRecoveryHint(tool: String, errorText: String, params: Map<String, Any>): String {
        val err = errorText.lowercase()
        return when {
            tool == "tap_node" && err.contains("voice/camera") ->
                "That was a mic/camera button. Look at the screen tree for a non-MIC, non-CAM " +
                    "node to tap. For typing, use input_text directly."
            tool == "input_text" && (err.contains("no editable") || err.contains("no target")) ->
                "No editable field was focused. Call get_screen_info, then tap the search bar " +
                    "(look for class=EditText / SearchView / AutoComplete) and retry input_text with " +
                    "submit=true to type and press Enter."
            tool == "system_key" && err.contains("no focused") ->
                "Nothing is focused. Tap the input first with tap_node or find_and_tap, then retry."
            tool == "find_and_tap" && err.contains("no elements") ->
                "That text is NOT on screen yet. If you need to SEARCH for it, use input_text " +
                    "to type it into the search bar (EDIT node). Call get_screen_info to find the EDIT node, " +
                    "then input_text(text=\"...\", node_id=\"<EDIT node>\"). Do NOT use find_and_tap for search queries."
            tool == "scroll_to_find" && err.contains("not found") ->
                "Could not find that text by scrolling. Try using the search bar instead: " +
                    "call get_screen_info, find the EDIT node, then input_text."
            tool == "tap_node" && err.contains("not found") ->
                "That node id is stale. Call get_screen_info to get fresh ids."
            tool == "open_app" && err.contains("not found") ->
                "That app isn't installed / not indexable. Try open_url with a web query instead."
            else -> "Last action failed: $errorText. Try a different approach."
        }
    }

    private fun readScreen(): String {
        return try {
            val r = ToolRegistry.executeTool("get_screen_info", emptyMap())
            (r.data ?: r.error ?: "(empty)")
        } catch (e: Exception) {
            "(screen error: ${e.message})"
        }
    }

    private fun ArrayDeque<String>.pushTrim(line: String) {
        addLast(line)
        while (size > HISTORY_LINES) removeFirst()
    }

    private fun finish(summary: String) {
        _state.update { it.copy(running = false, lastMessage = summary) }
        emit(PilotEvent.Finished(summary))
        appendLog(PilotLogEntry.Kind.FINISHED, "✓ Done: $summary")
        notifyProgress(summary)
    }

    // ─── Events + log ───

    private fun emit(event: PilotEvent) {
        mainHandler.post { _events.tryEmit(event) }
    }

    private fun step(index: Int, msg: String) {
        _state.update { it.copy(stepIndex = index, lastMessage = msg) }
        emit(PilotEvent.Step(index, msg))
        appendLog(PilotLogEntry.Kind.STEP, "Step $index: $msg")
    }

    private fun emitTool(name: String, params: String) {
        emit(PilotEvent.ToolCall(name, params))
        appendLog(PilotLogEntry.Kind.TOOL_CALL, "▶ $name  ${params.take(160)}")
    }

    private fun emitToolResult(name: String, result: String) {
        emit(PilotEvent.ToolResult(name, result))
        appendLog(PilotLogEntry.Kind.TOOL_RESULT, "  ← ${result.take(160)}")
    }

    private fun appendLog(kind: PilotLogEntry.Kind, text: String) {
        val entry = PilotLogEntry(idSeq.incrementAndGet(), kind, text)
        _log.update { list ->
            val next = list + entry
            if (next.size > 400) next.takeLast(400) else next
        }
    }

    private fun notifyProgress(text: String) {
        val ctx = appContext ?: return
        if (PilotForegroundService.isRunning()) {
            val taskLine = state.value.task.ifEmpty { "Running" }
            PilotForegroundService.update(ctx, "Pilot · ${taskLine.take(40)}", text)
        }
    }

    // ─── LLM + prompt building ───

    /**
     * Decide which backend (local Gemma vs cloud LLM) handles this run, and
     * remember the choice for the duration of the task. Set when the task
     * starts so we don't flip mid-loop.
     */
    @Volatile
    private var currentBackend: com.dia.app.pilot.cloud.TaskRouter.Backend =
        com.dia.app.pilot.cloud.TaskRouter.Backend.LOCAL

    /**
     * Conversation history we keep replaying to the cloud model so it
     * remembers what already happened. Local Gemma is stateless per-turn
     * (we ship the screen tree fresh each time) — cloud benefits from the
     * full memory of past tool calls and their results.
     */
    private val cloudHistory = mutableListOf<com.dia.app.pilot.cloud.CloudLlmClient.Message>()

    private suspend fun pickBackendForTask(task: String) {
        // Pilot now respects the user's global Local/Cloud choice in
        // Settings. No more heuristic auto-routing — keeps behaviour
        // predictable.
        currentBackend = when (com.dia.app.llm.BackendRouter.pick()) {
            com.dia.app.llm.BackendRouter.Backend.LOCAL ->
                com.dia.app.pilot.cloud.TaskRouter.Backend.LOCAL
            com.dia.app.llm.BackendRouter.Backend.CLOUD ->
                com.dia.app.pilot.cloud.TaskRouter.Backend.CLOUD
        }
        cloudHistory.clear()
        appendLog(
            PilotLogEntry.Kind.INFO,
            "▸ backend: ${currentBackend.name.lowercase()}" +
                if (currentBackend == com.dia.app.pilot.cloud.TaskRouter.Backend.CLOUD)
                    " (${com.dia.app.prefs.DiaPrefs.cloudModel.value})"
                else ""
        )
    }

    /**
     * Called by the loop after a tool executes so the cloud model can see
     * the result on the next turn. No-op when running locally.
     */
    fun recordCloudToolOutcome(
        toolJson: String,
        resultText: String,
        success: Boolean,
    ) {
        if (currentBackend != com.dia.app.pilot.cloud.TaskRouter.Backend.CLOUD) return
        // Assistant turn = the JSON tool call
        cloudHistory += com.dia.app.pilot.cloud.CloudLlmClient.Message(
            role = "assistant",
            content = toolJson,
        )
        // User turn = the tool's result, framed so the model treats it as
        // observation rather than instruction.
        val mark = if (success) "✓" else "✗"
        cloudHistory += com.dia.app.pilot.cloud.CloudLlmClient.Message(
            role = "user",
            content = "TOOL_RESULT $mark ${resultText.take(800)}",
        )
        // Keep the rolling window bounded — last 12 turns is plenty for any
        // realistic order-and-pay flow.
        while (cloudHistory.size > 24) {
            cloudHistory.removeAt(0)
        }
    }

    private suspend fun callModel(prompt: String): String {
        return when (currentBackend) {
            com.dia.app.pilot.cloud.TaskRouter.Backend.CLOUD -> callCloud(prompt)
            com.dia.app.pilot.cloud.TaskRouter.Backend.LOCAL -> callLocal(prompt)
        }
    }

    private suspend fun callLocal(prompt: String): String = suspendCancellableCoroutine { cont ->
        val sb = StringBuilder()
        DiaEngine.sendPilotTurn(
            systemInstruction = SYSTEM_PROMPT,
            text = prompt,
            onToken = { partial, done ->
                if (partial.isNotEmpty()) sb.append(partial)
                if (done && cont.isActive) cont.resume(sb.toString())
            },
            onError = { msg ->
                Log.e(TAG, "Model error: $msg")
                if (cont.isActive) cont.resume("""{"finish":"Error: $msg"}""")
            }
        )
    }

    private suspend fun callCloud(prompt: String): String {
        val baseUrl = com.dia.app.prefs.DiaPrefs.cloudBaseUrl.value
        val apiKey = com.dia.app.prefs.DiaPrefs.cloudApiKey.value
        val model = com.dia.app.prefs.DiaPrefs.cloudModel.value
        if (baseUrl.isBlank() || model.isBlank()) {
            return """{"finish":"Cloud not configured. Set base URL and model in Settings."}"""
        }
        val client = com.dia.app.pilot.cloud.CloudLlmClient(baseUrl, apiKey, model)
        val result = client.chat(
            systemPrompt = SYSTEM_PROMPT,
            userPrompt = prompt,
            // For now we keep the cloud call text-only. Adding a screenshot
            // later is a one-line change — pass a base64 PNG into chat().
            screenshotPngBase64 = null,
            history = cloudHistory.toList(),
            temperature = 0.1,
            maxTokens = 4096,
        )
        return result.content
            ?: """{"finish":"Cloud error: ${result.error?.replace("\"", "'")?.take(160)}"}"""
    }

    private fun extractJson(text: String): String? {
        val trimmed = text.trim()
        val fenced = Regex("```(?:json)?(.*?)```", RegexOption.DOT_MATCHES_ALL)
            .find(trimmed)?.groupValues?.getOrNull(1)?.trim()
        val candidate = fenced ?: trimmed
        val start = candidate.indexOf('{')
        if (start == -1) return null

        // Walk through the string from `start`, balancing braces. If the
        // response was truncated (output token cap hit), this gives us the
        // longest valid prefix instead of returning null.
        var depth = 0
        var inString = false
        var escape = false
        var lastValidEnd = -1
        for (i in start until candidate.length) {
            val c = candidate[i]
            if (escape) { escape = false; continue }
            if (c == '\\' && inString) { escape = true; continue }
            if (c == '"') { inString = !inString; continue }
            if (inString) continue
            when (c) {
                '{' -> depth++
                '}' -> {
                    depth--
                    if (depth == 0) { lastValidEnd = i; break }
                }
            }
        }
        if (lastValidEnd == -1) {
            // Truncated. Try to salvage by closing the unclosed string and
            // braces.
            val end = candidate.lastIndexOf('}')
            if (end > start) return candidate.substring(start, end + 1)
            return null
        }
        return candidate.substring(start, lastValidEnd + 1)
    }

    private fun buildRepairPrompt(previous: String): String = """
Not valid JSON. Return ONLY one JSON object like {"tool":"...","params":{...}}.

Previous:
${previous.take(600)}
""".trimIndent()

    private fun jsonToMap(obj: JSONObject): Map<String, Any> {
        val out = LinkedHashMap<String, Any>()
        val keys = obj.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            out[k] = obj.get(k)
        }
        return out
    }

    private fun buildCompactToolSpec(): String = """
Tools:
- get_screen_info() → fresh screen tree
- tap_node(node_id) → tap element by id
- tap(x,y) → tap at coords
- long_press(node_id|x,y)
- swipe(start_x,start_y,end_x,end_y)
- input_text(text, node_id?, clear_first?, submit?) → submit=true presses Enter after typing
- system_key(key=back|home|recents|enter)
- open_app(package_name|app_name)
- open_url(url | query) → open URL or Google-search `query`
- find_and_tap(text)
- scroll_to_find(text)
- get_device_info(category=battery|wifi|storage|device|time)
- wait(duration_ms)
- finish(summary)
""".trimIndent()

    private fun buildPrompt(
        task: String,
        screen: String,
        history: ArrayDeque<String>,
        tools: String,
        stepIdx: Int,
        recoveryHint: String?,
    ): String {
        val budget = if (currentBackend == com.dia.app.pilot.cloud.TaskRouter.Backend.CLOUD)
            SCREEN_TREE_CHAR_BUDGET_CLOUD else SCREEN_TREE_CHAR_BUDGET
        val screenBlock = if (screen.isBlank()) "(empty)" else trimScreenTree(screen, budget)
        val historyBlock = if (history.isEmpty()) "(none)" else history.joinToString("\n")
        val hintBlock = if (!recoveryHint.isNullOrBlank()) "\nHINT: $recoveryHint\n" else ""

        // Cloud branch — the model already remembers everything via the
        // conversation history we replay each turn. Don't double-ship the
        // task / RECENT log; just send the fresh screen and any recovery
        // hint. This is what stops the "Swiggy opened then froze" bug —
        // the cloud previously had no idea what tool calls had succeeded.
        if (currentBackend == com.dia.app.pilot.cloud.TaskRouter.Backend.CLOUD) {
            return buildString {
                if (stepIdx <= 1) append("TASK: ").append(task).append("\n\n")
                append("CURRENT SCREEN:\n").append(screenBlock)
                append(hintBlock)
                append("\nGoal reminder: ").append(task)
                append("\nReturn ONE JSON tool call.")
            }
        }

        // Local Gemma branch — recency-aware prompt with task at top AND
        // bottom so the small model can't lose track across the long
        // screen tree in the middle.
        return buildString {
            append("TASK: ").append(task).append('\n')
            append("\nSCREEN:\n").append(screenBlock)
            if (historyBlock != "(none)") {
                append("\n\nRECENT:\n").append(historyBlock)
            }
            append(hintBlock)
            append("\n\nREMINDER — TASK: ").append(task)
            append("\nOutput exactly one JSON tool call. No prose.")
            append("\nJSON:")
        }
    }

    private fun trimScreenTree(screen: String, maxChars: Int): String {
        if (screen.length <= maxChars) return screen
        val lines = screen.lineSequence().toList()
        val header = lines.takeWhile { it.startsWith("APP:") || it.isBlank() }
        val body = lines.drop(header.size)

        // Reserve a slot for every EDIT line — we never want to drop an input
        // field, that's the agent's only handle on a search box.
        val editLines = body.filter { it.contains(" EDIT ") }
        val normalLines = body.filter { !it.contains(" EDIT ") }

        val sb = StringBuilder()
        header.forEach { sb.append(it).append('\n') }

        var used = 0
        // Edit lines first — guaranteed kept.
        for (line in editLines) {
            sb.append(line).append('\n')
            used += line.length + 1
            if (used >= maxChars) break
        }
        // Then fill in normal lines until we run out of budget.
        val remaining = maxChars - used - 32
        var normalUsed = 0
        for (line in normalLines) {
            if (normalUsed + line.length + 1 > remaining) break
            sb.append(line).append('\n')
            normalUsed += line.length + 1
        }
        if (sb.length < screen.length) sb.append("…(truncated)\n")
        return sb.toString()
    }

    private fun formatHistory(tool: String, success: Boolean, resultText: String): String {
        val mark = if (success) "✓" else "✗"
        val short = resultText.replace('\n', ' ').take(80)
        return "$mark $tool → $short"
    }

    private fun shortParamsText(params: Map<String, Any>): String {
        val preferred = listOf("query", "url", "text", "app_name", "package_name", "node_id", "key", "category")
        val key = preferred.firstOrNull { params.containsKey(it) } ?: params.keys.firstOrNull()
        val v = key?.let { params[it]?.toString() }?.replace('\n', ' ')?.trim().orEmpty()
        return if (v.isEmpty()) "" else "\"${v.take(36)}\""
    }

    @Suppress("unused")
    fun shutdown() { /* no-op — scope outlives UI */ }

    /**
     * Detect when the model says "done" but its summary reveals it hasn't
     * actually completed the task — it's narrating what it WOULD do next.
     */
    private fun looksLikePrematureFinish(summary: String): Boolean {
        val lower = summary.lowercase()
        val indicators = listOf(
            "next step", "i will", "i would", "i'll", "should tap",
            "need to tap", "need to click", "will tap", "will click",
            "the next", "remaining step", "to add it", "to complete",
            "which is labeled", "represented by"
        )
        return indicators.any { lower.contains(it) }
    }
}
