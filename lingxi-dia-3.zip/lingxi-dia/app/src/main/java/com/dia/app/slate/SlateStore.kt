package com.dia.app.slate

import android.content.Context
import android.util.Log
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

/**
 * Lightweight per-notebook metadata for the picker drawer.
 */
data class NotebookMeta(
    val id: String,
    val title: String,
    val mode: NotebookMode,
    val pageCount: Int,
    val updatedAt: Long,
)

/**
 * Persists Slate notebooks as one JSON file per notebook under
 * `filesDir/slate/<id>.json`. Modeled after [com.dia.app.ui.chat.ChatHistoryStore].
 *
 * Pages, strokes, AI notes, and pen state are all serialized. Loading
 * restores the entire notebook including AI handwriting strokes.
 */
object SlateStore {
    private const val TAG = "SlateStore"
    private const val DIR_NAME = "slate"

    private lateinit var dir: File

    private val _notebooks = MutableStateFlow<List<NotebookMeta>>(emptyList())
    val notebooks: StateFlow<List<NotebookMeta>> = _notebooks.asStateFlow()

    private val initialized: Boolean
        get() = ::dir.isInitialized

    suspend fun init(context: Context) = withContext(Dispatchers.IO) {
        if (initialized) return@withContext
        dir = File(context.applicationContext.filesDir, DIR_NAME).apply { mkdirs() }
        _notebooks.value = scan()
    }

    private fun scan(): List<NotebookMeta> {
        if (!::dir.isInitialized || !dir.exists()) return emptyList()
        return dir.listFiles { f -> f.isFile && f.name.endsWith(".json") }
            ?.mapNotNull { f ->
                try { readMeta(f) } catch (e: Exception) {
                    Log.w(TAG, "skip bad notebook ${f.name}: ${e.message}")
                    null
                }
            }
            ?.sortedByDescending { it.updatedAt }
            ?: emptyList()
    }

    private fun readMeta(file: File): NotebookMeta {
        val root = JSONObject(file.readText())
        val id = root.optString("id").ifEmpty { file.nameWithoutExtension }
        val title = root.optString("title").ifEmpty { "Untitled" }
        val mode = NotebookMode.entries.firstOrNull { it.name == root.optString("mode") }
            ?: NotebookMode.NOTES
        val pageCount = root.optJSONArray("pages")?.length() ?: 0
        val updatedAt = root.optLong("updatedAt", file.lastModified())
        return NotebookMeta(id, title, mode, pageCount, updatedAt)
    }

    fun newId(): String = UUID.randomUUID().toString().take(12)

    /** Save (or overwrite) a notebook. Drops empty drafts to keep the picker clean. */
    suspend fun save(state: SlateState) = withContext(Dispatchers.IO) {
        if (!initialized) return@withContext
        // Empty drafts: only the (single) starter page and no strokes/notes.
        if (state.pages.isEmpty() || state.pages.all { it.isEmpty() && it.question.isNullOrBlank() }) {
            delete(state.id)
            return@withContext
        }

        val pagesArr = JSONArray()
        for (p in state.pages) pagesArr.put(serializePage(p))

        val root = JSONObject()
            .put("id", state.id)
            .put("title", state.title.ifBlank { "Untitled" })
            .put("mode", state.mode.name)
            .put("pages", pagesArr)
            .put("currentPage", state.currentPageIndex)
            .put("penColorArgb", state.penColor.toArgb())
            .put("penWidth", state.penWidth.toDouble())
            .put("background", state.pageBackground.name)
            .put("createdAt", readCreatedAt(state.id))
            .put("updatedAt", System.currentTimeMillis())

        try {
            File(dir, "${state.id}.json").writeText(root.toString())
        } catch (e: Exception) {
            Log.e(TAG, "save failed for ${state.id}", e)
            return@withContext
        }
        _notebooks.value = scan()
    }

    /** Load a notebook by id. Returns null if missing. */
    suspend fun load(id: String): SlateState? = withContext(Dispatchers.IO) {
        if (!initialized) return@withContext null
        val file = File(dir, "$id.json")
        if (!file.exists()) return@withContext null
        try {
            val root = JSONObject(file.readText())
            val title = root.optString("title").ifEmpty { "Untitled" }
            val mode = NotebookMode.entries.firstOrNull { it.name == root.optString("mode") }
                ?: NotebookMode.NOTES
            val state = SlateState(id = id, title = title, mode = mode)
            val argb = root.optInt("penColorArgb", SlateState.DefaultInk.toArgb())
            state.penColor = Color(argb)
            state.penWidth = root.optDouble("penWidth", 3.5).toFloat()
            state.pageBackground = PageBackground.entries.firstOrNull {
                it.name == root.optString("background")
            } ?: PageBackground.RULED
            val pagesArr = root.optJSONArray("pages")
            if (pagesArr != null) {
                for (i in 0 until pagesArr.length()) {
                    val pageJson = pagesArr.getJSONObject(i)
                    state.addPage(deserializePage(pageJson, state))
                }
            }
            val current = root.optInt("currentPage", 0).coerceIn(0, (state.pages.size - 1).coerceAtLeast(0))
            state.currentPageIndex = current
            state
        } catch (e: Exception) {
            Log.e(TAG, "load failed for $id", e)
            null
        }
    }

    suspend fun delete(id: String) = withContext(Dispatchers.IO) {
        if (!initialized) return@withContext
        val file = File(dir, "$id.json")
        if (file.exists()) file.delete()
        _notebooks.value = scan()
    }

    suspend fun rename(id: String, newTitle: String) = withContext(Dispatchers.IO) {
        if (!initialized) return@withContext
        val file = File(dir, "$id.json")
        if (!file.exists()) return@withContext
        try {
            val root = JSONObject(file.readText())
            root.put("title", newTitle.ifBlank { "Untitled" })
            root.put("updatedAt", System.currentTimeMillis())
            file.writeText(root.toString())
            _notebooks.value = scan()
        } catch (e: Exception) {
            Log.e(TAG, "rename failed for $id", e)
        }
    }

    /* ─── Serialization ─── */

    private fun serializePage(p: NotebookPage): JSONObject {
        val strokesArr = JSONArray()
        for (s in p.strokes) strokesArr.put(serializeStroke(s))
        val notesArr = JSONArray()
        for (n in p.aiNotes) notesArr.put(serializeAiNote(n))
        return JSONObject()
            .put("id", p.id)
            .put("width", p.width.toDouble())
            .put("height", p.height.toDouble())
            .put("question", p.question ?: "")
            .put("strokes", strokesArr)
            .put("aiNotes", notesArr)
    }

    private fun deserializePage(o: JSONObject, state: SlateState): NotebookPage {
        val id = o.optLong("id", state.newPageId())
        val w = o.optDouble("width", SlateState.PAGE_WIDTH.toDouble()).toFloat()
        val h = o.optDouble("height", SlateState.PAGE_HEIGHT.toDouble()).toFloat()
        val question = o.optString("question").ifBlank { null }
        val page = NotebookPage(id = id, width = w, height = h, question = question)
        val strokes = o.optJSONArray("strokes")
        if (strokes != null) {
            for (i in 0 until strokes.length()) {
                deserializeStroke(strokes.getJSONObject(i), state)?.let { page.strokes.add(it) }
            }
        }
        val notes = o.optJSONArray("aiNotes")
        if (notes != null) {
            for (i in 0 until notes.length()) {
                deserializeAiNote(notes.getJSONObject(i), state)?.let { page.aiNotes.add(it) }
            }
        }
        return page
    }

    private fun serializeStroke(s: Stroke): JSONObject {
        val pts = JSONArray()
        for (p in s.points) {
            pts.put(JSONArray().apply {
                put(p.x.toDouble()); put(p.y.toDouble()); put(p.pressure.toDouble())
            })
        }
        return JSONObject()
            .put("id", s.id)
            .put("color", s.color.toArgb())
            .put("width", s.width.toDouble())
            .put("origin", s.origin.name)
            .put("mode", s.mode.name)
            .put("pts", pts)
    }

    private fun deserializeStroke(o: JSONObject, state: SlateState): Stroke? {
        return try {
            val color = Color(o.optInt("color", SlateState.DefaultInk.toArgb()))
            val width = o.optDouble("width", 3.5).toFloat()
            val origin = StrokeOrigin.entries.firstOrNull {
                it.name == o.optString("origin")
            } ?: StrokeOrigin.USER
            val mode = PenMode.entries.firstOrNull {
                it.name == o.optString("mode")
            } ?: PenMode.PEN
            val s = Stroke(
                id = o.optLong("id", state.newStrokeId()),
                color = color,
                width = width,
                origin = origin,
                mode = mode,
            )
            val pts = o.optJSONArray("pts") ?: return null
            for (i in 0 until pts.length()) {
                val arr = pts.optJSONArray(i) ?: continue
                if (arr.length() >= 2) {
                    s.add(
                        InkPoint(
                            x = arr.optDouble(0, 0.0).toFloat(),
                            y = arr.optDouble(1, 0.0).toFloat(),
                            pressure = arr.optDouble(2, 1.0).toFloat(),
                        )
                    )
                }
            }
            if (s.points.isEmpty()) null else s
        } catch (_: Exception) { null }
    }

    private fun serializeAiNote(n: AiNote): JSONObject {
        return JSONObject()
            .put("id", n.id)
            .put("text", n.text)
            .put("x", n.anchor.x.toDouble())
            .put("y", n.anchor.y.toDouble())
            .put("verdict", n.verdict?.name ?: "")
            .put("correctAnswer", n.correctAnswer ?: "")
    }

    private fun deserializeAiNote(o: JSONObject, state: SlateState): AiNote? {
        return try {
            AiNote(
                id = o.optLong("id", state.newNoteId()),
                text = o.optString("text"),
                anchor = Offset(
                    o.optDouble("x", 0.0).toFloat(),
                    o.optDouble("y", 0.0).toFloat(),
                ),
                verdict = QuizVerdict.entries.firstOrNull {
                    it.name == o.optString("verdict")
                },
                correctAnswer = o.optString("correctAnswer").ifBlank { null },
            )
        } catch (_: Exception) { null }
    }

    private fun readCreatedAt(id: String): Long {
        val file = File(dir, "$id.json")
        if (!file.exists()) return System.currentTimeMillis()
        return try {
            JSONObject(file.readText()).optLong("createdAt", file.lastModified())
        } catch (_: Exception) { file.lastModified() }
    }
}
