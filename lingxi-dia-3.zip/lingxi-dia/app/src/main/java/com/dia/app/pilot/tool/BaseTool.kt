package com.dia.app.pilot.tool

import com.dia.app.DiaAccessibilityService

abstract class BaseTool {
    companion object {
        private const val MAX_WAIT_AFTER_MS = 10000L
        val WAIT_AFTER_PARAM = ToolParameter(
            "wait_after",
            "integer",
            "Optional: milliseconds to wait after this action completes (default 0)",
            false
        )
    }

    abstract fun getName(): String
    abstract fun getDescription(): String
    abstract fun getParameters(): List<ToolParameter>
    abstract fun execute(params: Map<String, Any>): ToolResult

    fun getParametersWithWaitAfter(): List<ToolParameter> {
        val params = getParameters().toMutableList()
        if (getName() !in listOf("wait", "finish", "get_screen_info")) {
            params.add(WAIT_AFTER_PARAM)
        }
        return params
    }

    fun executeWithWaitAfter(params: Map<String, Any>): ToolResult {
        val result = execute(params)
        if (result.isSuccess) {
            val waitMs = optionalLong(params, "wait_after", 0)
            if (waitMs in 1..MAX_WAIT_AFTER_MS) {
                try {
                    Thread.sleep(waitMs)
                } catch (_: InterruptedException) {
                    Thread.currentThread().interrupt()
                }
            }
        }
        return result
    }

    protected fun requireString(params: Map<String, Any>, key: String): String {
        return params[key]?.toString() ?: throw IllegalArgumentException("Missing required parameter: $key")
    }

    protected fun requireInt(params: Map<String, Any>, key: String): Int {
        val value = params[key] ?: throw IllegalArgumentException("Missing required parameter: $key")
        return when (value) {
            is Number -> value.toInt()
            else -> value.toString().toInt()
        }
    }

    protected fun optionalLong(params: Map<String, Any>, key: String, defaultValue: Long): Long {
        val value = params[key] ?: return defaultValue
        return when (value) {
            is Number -> value.toLong()
            else -> value.toString().toLong()
        }
    }

    protected fun optionalString(params: Map<String, Any>, key: String, defaultValue: String): String {
        return params[key]?.toString() ?: defaultValue
    }

    protected fun optionalBoolean(params: Map<String, Any>, key: String, defaultValue: Boolean): Boolean {
        val value = params[key] ?: return defaultValue
        return when (value) {
            is Boolean -> value
            is Number -> value.toInt() != 0
            else -> value.toString().toBoolean()
        }
    }

    /**
     * Extract just the node ID (e.g. "n8") from whatever the model passes.
     * Handles: "n8", "[n8]", "[n8] hint=\"Search\" EDIT @540,120", etc.
     */
    protected fun extractNodeId(raw: String): String {
        // Try to find "nXX" pattern
        val match = Regex("n\\d+").find(raw)
        if (match != null) return match.value
        // Fallback: strip brackets and take first word
        return raw.replace("[", "").replace("]", "").trim().split(" ").first()
    }

    protected fun requireAccessibilityService(): DiaAccessibilityService? {
        return DiaAccessibilityService.getInstance()
    }
}
