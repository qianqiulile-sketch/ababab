package com.dia.app.pilot.cloud

import android.util.Log
import com.dia.app.llm.DiaEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume

/**
 * Asks the on-device Gemma to classify a task as LOCAL or CLOUD.
 *
 * The decision tree we want, in order:
 *   1. Manual prefix (`cloud:` / `local:`) — wins always.
 *   2. Hard rule on obvious complexity signals (multi-step, ordering, money,
 *      forms, email composition) — go CLOUD without bothering the model.
 *   3. Hard rule on the four-or-five "demo-grade" simple tasks Gemma absolutely
 *      handles (open app, send message to X, call X, what's my battery, read
 *      notifications, search inside app) — go LOCAL without asking.
 *   4. Ambiguous → ask Gemma to read the task and pick.
 *
 * Step 4 is what makes the routing actually robust. Gemma 4B is capable of
 * answering one short question reliably; we use that strength to pick the
 * right backend instead of hand-curating regexes.
 *
 * The classifier prompt is short and locks the model to a one-token output,
 * so the call is fast (~250-400 ms on most devices). Falls back to CLOUD on
 * timeout.
 */
object TaskClassifier {

    private const val TAG = "TaskClassifier"

    /** Hard upper bound on the classifier call. After this we default to CLOUD. */
    private const val CLASSIFIER_TIMEOUT_MS = 4000L

    /** Cache the classifier verdict per task string for a session — saves ~300 ms on repeats. */
    private val cache = mutableMapOf<String, TaskRouter.Backend>()

    private const val PILOT_CLASSIFIER_PROMPT = """You are a router. You must decide whether a phone-control task should run on a small on-device model (LOCAL) or a powerful cloud model (CLOUD).

The on-device model is good at exactly these tasks (LOCAL):
- Open or launch a single app
- Send a single text message to one contact (no email)
- Place a phone call
- Search for something inside one app
- Read battery / wifi / storage / time / notifications / clipboard / installed apps
- Press home / back / volume keys
- Toggle a single setting like dark mode or wifi

The cloud model is required for anything else (CLOUD), especially:
- Ordering, buying, adding to cart, checkout
- Booking, scheduling, reservations, alarms, reminders
- Composing or replying to emails (anything with @)
- Filling out forms, signing up, registering, logging in
- Paying, transferring money, splitting bills
- Multi-step tasks ("X and then Y", "after that …")
- Tasks involving multiple apps
- Quantities greater than 1
- Anything vague or that needs planning

Answer with exactly one word: LOCAL or CLOUD. No explanation."""

    private const val GUIDE_CLASSIFIER_PROMPT = """You are a router. You decide whether a "show me how" guidance request should run on a small on-device model (LOCAL) or a powerful cloud model (CLOUD).

LOCAL is good at:
- "How do I open / find / use X" — short, single-feature guidance
- "Where is X" — locating a setting or button
- "Turn on / off X" / "enable / disable X" — single toggle
- Short navigation guidance inside one app

CLOUD is required for:
- Step-by-step ordering, booking, scheduling, paying
- Email composition guidance
- Multi-app workflows
- Filling out forms or signing up
- Anything involving money, transfers, or compound steps
- Long or vague questions

Answer with exactly one word: LOCAL or CLOUD. No explanation."""

    /**
     * Public entry point used by Pilot.
     */
    suspend fun classifyPilot(
        prompt: String,
        cloudConfigured: Boolean,
        autoRoute: Boolean,
    ): TaskRouter.Backend = classify(prompt, cloudConfigured, autoRoute, PILOT_CLASSIFIER_PROMPT)

    /**
     * Public entry point used by Guide.
     */
    suspend fun classifyGuide(
        prompt: String,
        cloudConfigured: Boolean,
        autoRoute: Boolean,
    ): TaskRouter.Backend = classify(prompt, cloudConfigured, autoRoute, GUIDE_CLASSIFIER_PROMPT)

    private suspend fun classify(
        prompt: String,
        cloudConfigured: Boolean,
        autoRoute: Boolean,
        systemPrompt: String,
    ): TaskRouter.Backend {
        val raw = prompt.trim()
        val lower = raw.lowercase()

        // 1. Manual override prefix
        if (lower.startsWith("cloud:") || lower.startsWith("[cloud]")) {
            return if (cloudConfigured) TaskRouter.Backend.CLOUD else TaskRouter.Backend.LOCAL
        }
        if (lower.startsWith("local:") || lower.startsWith("[local]")) {
            return TaskRouter.Backend.LOCAL
        }

        // 2. Cloud disabled / not configured → must use local.
        if (!cloudConfigured) return TaskRouter.Backend.LOCAL

        // 3. "Cloud only" mode (cloud enabled but auto-route off) → always CLOUD.
        if (!autoRoute) return TaskRouter.Backend.CLOUD

        // 4. Auto mode — heuristic + ambiguous → classifier model.

        // 4a. Hard rule: clearly complex → CLOUD without asking the model
        if (HARD_CLOUD_SIGNALS.any { lower.contains(it) }) {
            return cached(lower, TaskRouter.Backend.CLOUD)
        }
        if (EMAIL_REGEX.containsMatchIn(lower)) {
            return cached(lower, TaskRouter.Backend.CLOUD)
        }
        if (QUANTITY_REGEX.containsMatchIn(lower)) {
            return cached(lower, TaskRouter.Backend.CLOUD)
        }

        // 4b. Hard rule: clearly a known simple skill → LOCAL without asking
        if (matchesObviousLocal(lower)) {
            return cached(lower, TaskRouter.Backend.LOCAL)
        }

        // 4c. Ambiguous → ask Gemma. Cache so the same prompt doesn't pay
        //     the latency twice in one session.
        cache[lower]?.let { return it }

        val verdict = withContext(Dispatchers.IO) {
            askModel(systemPrompt, raw)
        }
        return cached(lower, verdict)
    }

    private fun cached(key: String, value: TaskRouter.Backend): TaskRouter.Backend {
        cache[key] = value
        if (cache.size > 64) {
            cache.entries.iterator().next().also { cache.remove(it.key) }
        }
        return value
    }

    /**
     * Suspend-call into Gemma with a short classifier prompt. Returns CLOUD
     * if anything fails so we never trap the user with a flaky local model
     * on an obviously complex task.
     */
    private suspend fun askModel(systemPrompt: String, taskText: String): TaskRouter.Backend {
        val response = withTimeoutOrNull(CLASSIFIER_TIMEOUT_MS) {
            suspendCancellableCoroutine<String> { cont ->
                val sb = StringBuilder()
                DiaEngine.sendPilotTurn(
                    systemInstruction = systemPrompt,
                    text = "TASK: $taskText\n\nAnswer LOCAL or CLOUD:",
                    onToken = { partial, done ->
                        if (partial.isNotEmpty()) sb.append(partial)
                        if (done && cont.isActive) cont.resume(sb.toString())
                    },
                    onError = { msg ->
                        Log.w(TAG, "Classifier error: $msg")
                        if (cont.isActive) cont.resume("")
                    }
                )
            }
        }

        if (response.isNullOrBlank()) {
            Log.w(TAG, "Classifier timed out — defaulting to CLOUD")
            return TaskRouter.Backend.CLOUD
        }

        val token = response.trim().uppercase()
        return when {
            token.startsWith("LOCAL") -> TaskRouter.Backend.LOCAL
            token.startsWith("CLOUD") -> TaskRouter.Backend.CLOUD
            // Sometimes the model wraps the verdict in punctuation/JSON.
            token.contains("LOCAL") && !token.contains("CLOUD") -> TaskRouter.Backend.LOCAL
            token.contains("CLOUD") && !token.contains("LOCAL") -> TaskRouter.Backend.CLOUD
            // Fall back to CLOUD — judges error-prone tasks correctly.
            else -> {
                Log.w(TAG, "Unparsable classifier reply: ${response.take(80)}")
                TaskRouter.Backend.CLOUD
            }
        }
    }

    /**
     * Quick LOCAL match — only the patterns where Gemma is reliably good.
     * Conservative: leaves anything mildly ambiguous to the model classifier.
     */
    private fun matchesObviousLocal(lower: String): Boolean {
        // "what's my battery" / "what's my wifi" / "what's the time"
        if (Regex("^what(?:'s| is)\\s+(my|the)\\s+(battery|wifi|wi-fi|storage|bluetooth|time)\\??$").matches(lower)) return true
        if (lower in setOf(
            "battery", "wifi", "wi-fi", "storage", "bluetooth",
            "what time is it", "what time is it?",
            "go home", "go back", "press home", "press back",
            "show notifications", "show my notifications", "read my notifications",
            "what's on my clipboard", "what is on my clipboard",
            "list my apps", "show my apps", "what apps do i have",
        )) return true

        // "send a message to <name>"  (no email anywhere — that's checked separately)
        if (Regex("^(send (a )?(message|text|sms) to|message|text|tell|whatsapp|ping)\\s+[\\w\\s.&-]{1,40}\\.?$").matches(lower)) return true

        // "call <name>"
        if (Regex("^(call|dial|phone|ring)\\s+[\\w\\s.&-]{1,40}\\.?$").matches(lower)) return true

        // "open <app>" alone
        if (Regex("^(open|launch|start)\\s+[\\w\\s.&-]{1,30}\\.?$").matches(lower)) return true

        // "open X and search for Y"  /  "search for Y in X"
        if (Regex("^(open\\s+)?[\\w\\s.&-]{1,30}\\s+and\\s+search\\s+(for\\s+)?.{1,80}$").matches(lower)) return true
        if (Regex("^search\\s+(for\\s+)?.{1,60}\\s+(on|in)\\s+[\\w\\s.&-]{1,30}\\.?$").matches(lower)) return true

        return false
    }

    // Hard cloud signals that don't need a model call.
    private val HARD_CLOUD_SIGNALS = listOf(
        // Shopping
        "order ", "buy ", "purchase ", "checkout", "place an order", "place order",
        "add to cart", " to cart", "remove from cart", "from cart",
        // Booking
        "book a ", "book me ", "book the ", "book an ", "reserve ", "reservation",
        "schedule ", "reschedule ", "create an event", "set a meeting",
        "set up a meeting", "set a reminder", "remind me to ", "set an alarm",
        "set alarm", "set timer", "set a timer",
        // Email composition
        "compose ", "compose email", "compose an email",
        "draft an email", "write an email", "reply to ", "forward to ",
        // Forms
        "fill out", "fill in", "fill the form", "sign up", "sign me up",
        "register for ", "log in to ", "sign in to ",
        // Money
        "pay ", "transfer ", "send money", "split the bill",
        // Multi-step chain markers
        " and then ", " after that", " followed by", "; then ",
    )

    private val EMAIL_REGEX = Regex("[\\w.+-]+@[\\w-]+\\.[\\w.-]+")
    private val QUANTITY_REGEX = Regex(
        "\\b(?:add|order|buy|get|purchase|place)\\s+(\\d+|two|three|four|five|six|seven|eight|nine|ten)\\b",
        RegexOption.IGNORE_CASE,
    )
}
