package com.dia.app.ui.settings

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.dia.app.files.FileManager
import com.dia.app.imagegen.ImageGen
import com.dia.app.imagegen.LocalImageGen
import com.dia.app.llm.DiaEngine
import com.dia.app.llm.ModelManager
import com.dia.app.prefs.DiaPrefs
import com.dia.app.prefs.DiaSettings
import com.dia.app.prefs.IntPref
import com.dia.app.prefs.StringPref
import com.dia.app.ui.chat.ToggleRow
import com.dia.app.ui.theme.CloudDivider
import com.dia.app.ui.theme.DiaPal
import com.dia.app.ui.theme.DiaPalette
import com.dia.app.ui.theme.DiaSerif
import com.dia.app.ui.theme.inkWashBackground
import com.dia.app.ui.theme.scrollFrame
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** 设置（全中文，按功能分组）。 */
@Composable
fun SettingsScreen(
    onBack: () -> Unit,
    onOpenModelSetup: () -> Unit,
    onEditBubble: () -> Unit,
    onReplayOnboarding: () -> Unit = {},
) {
    val p = DiaPal.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var confirmUnload by remember { mutableStateOf(false) }
    var confirmDownload by remember { mutableStateOf(false) }
    var imgStatus by remember { mutableStateOf("") }
    val localStatus by LocalImageGen.status.collectAsState()

    val importTree = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                imgStatus = try {
                    val n = withContext(Dispatchers.IO) { LocalImageGen.importFromTree(context, uri) }
                    "已导入 $n 个模型文件"
                } catch (e: Exception) { "导入失败：${e.message}" }
            }
        }
    }

    Column(Modifier.fillMaxSize().inkWashBackground(p).windowInsetsPadding(WindowInsets.statusBars)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "返回", tint = p.text) }
            Text("设置", style = MaterialTheme.typography.headlineMedium, color = p.text, fontFamily = DiaSerif)
        }
        CloudDivider(p, Modifier.padding(horizontal = 16.dp))

        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(vertical = 12.dp)) {
            // ── 外观 ──
            item {
                Section(p, "外观") {
                    val mode by DiaSettings.themeMode.flow.collectAsState()
                    ChoiceRow(p, "主题", listOf("ink" to "墨夜（深色）", "paper" to "宣纸（浅色）"), mode) { DiaSettings.themeMode.set(it) }
                    ToggleRow(p, "大字体", "放大全局文字", DiaPrefs.bigText.collectAsState().value) { DiaPrefs.setBigText(it) }
                    ToggleRow(p, "减少动画", "降低动效，更省电", DiaPrefs.reduceMotion.collectAsState().value) { DiaPrefs.setReduceMotion(it) }
                }
            }
            // ── 模型 ──
            item {
                Section(p, "本地模型") {
                    Info(p, "当前模型", DiaEngine.currentModelPath?.substringAfterLast('/') ?: "未加载")
                    ToggleRow(p, "启动时自动加载", "打开灵犀时自动载入上次使用的模型", DiaPrefs.autoLoadModel.collectAsState().value) { DiaPrefs.setAutoLoadModel(it) }
                    val ctx by DiaSettings.contextTokens.flow.collectAsState()
                    ChoiceRow(p, "上下文长度（重新加载模型后生效）", listOf("4096" to "4K（省内存）", "8192" to "8K（推荐）", "16384" to "16K"), ctx.toString()) {
                        DiaSettings.contextTokens.set(it.toInt())
                    }
                    ActionRow(p, "导入 / 管理模型文件", "从手机中选择 .litertlm 模型", onClick = onOpenModelSetup)
                    ActionRow(p, "重新加载模型", "应用新的上下文长度") { scope.launch { ModelManager.reload(context) } }
                    ActionRow(p, "卸载模型", "释放内存", danger = true) { confirmUnload = true }
                }
            }
            // ── 对话 ──
            item {
                Section(p, "对话") {
                    ToggleRow(p, "AI 自主调用工具", "让灵犀自行决定搜索、读文件、画图、操控手机等", DiaSettings.agentTools.flow.collectAsState().value) { DiaSettings.agentTools.set(it) }
                    val steps by DiaSettings.maxToolSteps.flow.collectAsState()
                    ChoiceRow(p, "每轮最多工具次数", listOf("2" to "2", "4" to "4", "6" to "6"), steps.toString()) { DiaSettings.maxToolSteps.set(it.toInt()) }
                    ToggleRow(p, "默认开启深度思考", "新对话默认展示推理过程（Gemma 4）", DiaPrefs.thinkingDefault.collectAsState().value) { DiaPrefs.setThinkingDefault(it) }
                    ToggleRow(p, "自动朗读回复", "用中文语音读出每条回复", DiaPrefs.autoSpeak.collectAsState().value) { DiaPrefs.setAutoSpeak(it) }
                    TextPref(p, "回复语言", DiaSettings.replyLanguage, "简体中文")
                    TextPref(p, "翻译默认目标语言", DiaSettings.translateTarget, "简体中文")
                }
            }
            // ── 记忆 ──
            item {
                Section(p, "记忆") {
                    ToggleRow(p, "启用记忆", "回答时参考关于你的记忆", DiaSettings.memoryEnabled.flow.collectAsState().value) { DiaSettings.memoryEnabled.set(it) }
                    ToggleRow(p, "自动记忆", "自动从对话中提取关键信息", DiaSettings.autoMemory.flow.collectAsState().value) { DiaSettings.autoMemory.set(it) }
                    Hint(p, "在对话页右上角菜单 →「记忆管理」查看、编辑、手写记忆。")
                }
            }
            // ── 联网 ──
            item {
                Section(p, "联网") {
                    ToggleRow(p, "允许联网", "允许 AI 联网搜索、读取网页、下载文件", DiaSettings.webEnabled.flow.collectAsState().value) { DiaSettings.webEnabled.set(it) }
                    val engine by DiaSettings.searchEngine.flow.collectAsState()
                    ChoiceRow(p, "搜索引擎", listOf("bing" to "必应（国内可用）", "duckduckgo" to "DuckDuckGo", "searxng" to "SearXNG 自建"), engine) { DiaSettings.searchEngine.set(it) }
                    if (engine == "searxng") TextPref(p, "SearXNG 地址", DiaSettings.searxngUrl, "https://searx.example.com")
                    ToggleRow(p, "深度搜索", "自动阅读前两个网页正文，回答更准（更慢）", DiaSettings.deepSearch.flow.collectAsState().value) { DiaSettings.deepSearch.set(it) }
                    Hint(p, "下载的文件保存在「下载/Dia」，每次下载前都会请你确认。")
                }
            }
            // ── 生图 ──
            item {
                Section(p, "生图 AI") {
                    val provider by DiaSettings.imageProvider.flow.collectAsState()
                    ChoiceRow(p, "生图方式", ImageGen.PROVIDERS, provider) { DiaSettings.imageProvider.set(it) }
                    when (provider) {
                        "openai" -> {
                            TextPref(p, "接口地址", DiaSettings.imageBaseUrl, "https://api.siliconflow.cn/v1")
                            TextPref(p, "API Key", DiaSettings.imageApiKey, "sk-…", secret = true)
                            TextPref(p, "模型", DiaSettings.imageModel, "Kwai-Kolors/Kolors 或 dall-e-3")
                        }
                        "sdwebui" -> {
                            TextPref(p, "SD WebUI 地址", DiaSettings.imageBaseUrl, "http://192.168.1.10:7860（启动时加 --api --listen）")
                            IntTextPref(p, "采样步数", DiaSettings.localImageSteps)
                        }
                        "local" -> {
                            Info(p, "本机模型状态", LocalImageGen.describe(context))
                            IntTextPref(p, "迭代步数（越多越清晰，越慢）", DiaSettings.localImageSteps)
                            ActionRow(p, "从文件夹导入模型", "选择包含 MediaPipe 生图模型 bins 的文件夹") { importTree.launch(null) }
                            TextPref(p, "模型下载地址（zip）", DiaSettings.localImageModelUrl, "https://…/sd15_mediapipe_bins.zip")
                            ActionRow(p, "下载模型", "体积约 1~2GB，建议在 Wi-Fi 下进行") {
                                if (DiaSettings.localImageModelUrl.value.isBlank()) imgStatus = "请先填写下载地址" else confirmDownload = true
                            }
                            if (localStatus.isNotBlank()) Hint(p, localStatus)
                        }
                        else -> {
                            TextPref(p, "模型（可选）", DiaSettings.imageModel, "flux / turbo")
                            TextPref(p, "令牌（可选）", DiaSettings.imageApiKey, "Pollinations token", secret = true)
                        }
                    }
                    val sizeV by DiaSettings.imageSize.flow.collectAsState()
                    ChoiceRow(p, "尺寸", listOf("1024x1024" to "方图", "768x1024" to "竖图", "1024x768" to "横图", "512x512" to "小图（快）"), sizeV) { DiaSettings.imageSize.set(it) }
                    ToggleRow(p, "中文提示词自动转英文", "用对话模型把描述润色成英文提示词，出图更准", DiaSettings.imagePromptTranslate.flow.collectAsState().value) { DiaSettings.imagePromptTranslate.set(it) }
                    if (imgStatus.isNotBlank()) Hint(p, imgStatus)
                }
            }
            // ── 云端模型 ──
            item {
                Section(p, "云端模型（可选）") {
                    ToggleRow(p, "使用云端模型", "开启后对话改用下面配置的在线大模型", DiaPrefs.cloudEnabled.collectAsState().value) { DiaPrefs.setCloudEnabled(it) }
                    FieldRow(p, "接口地址", DiaPrefs.cloudBaseUrl.collectAsState().value, "https://api.deepseek.com/v1") { DiaPrefs.setCloudBaseUrl(it) }
                    FieldRow(p, "模型名", DiaPrefs.cloudModel.collectAsState().value, "deepseek-chat / qwen-plus / glm-4") { DiaPrefs.setCloudModel(it) }
                    FieldRow(p, "API Key", DiaPrefs.cloudApiKey.collectAsState().value, "sk-…", secret = true) { DiaPrefs.setCloudApiKey(it) }
                    Hint(p, "支持任意 OpenAI 兼容接口：DeepSeek、通义千问(dashscope 兼容模式)、Kimi、智谱、硅基流动、Ollama 等。")
                }
            }
            // ── 悬浮气泡 ──
            item {
                Section(p, "悬浮气泡") {
                    ActionRow(p, "编辑气泡菜单与外观", "开关、改名、自定义提示词、排序", onClick = onEditBubble)
                }
            }
            // ── 文件与权限 ──
            item {
                Section(p, "文件与权限") {
                    ActionRow(
                        p, "所有文件访问",
                        if (FileManager.hasAllFilesAccess()) "已开启：灵犀可以浏览手机目录" else "开启后 AI 可以浏览下载等目录（可选）",
                    ) {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                            try {
                                context.startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${context.packageName}")))
                            } catch (_: Exception) {
                                context.startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
                            }
                        }
                    }
                    ActionRow(p, "无障碍服务", "操控手机、屏幕引导、悬浮气泡框选需要") {
                        context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                    }
                    ActionRow(p, "悬浮窗权限", "显示悬浮气泡和屏幕引导需要") {
                        context.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}")))
                    }
                    ActionRow(p, "通知读取", "让灵犀可以读取通知") {
                        context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                    }
                    ActionRow(p, "重新查看权限引导", "", onClick = onReplayOnboarding)
                }
            }
            // ── 智能家居 ──
            item {
                Section(p, "智能家居（Home Assistant）") {
                    FieldRow(p, "HA 地址", DiaPrefs.haBaseUrl.collectAsState().value, "http://192.168.1.100:8123") { DiaPrefs.setHaBaseUrl(it) }
                    FieldRow(p, "长期访问令牌", DiaPrefs.haToken.collectAsState().value, "HA → 个人资料 → 长期访问令牌", secret = true) { DiaPrefs.setHaToken(it) }
                }
            }
            item {
                Section(p, "关于") {
                    Info(p, "灵犀 Dia", "版本 2.0 · 本地 Gemma + 生图 AI · 中国风对话版")
                }
            }
            item { Spacer(Modifier.height(40.dp)) }
        }
    }

    if (confirmUnload) {
        AlertDialog(
            onDismissRequest = { confirmUnload = false },
            title = { Text("卸载模型？") },
            text = { Text("将释放内存，之后需要重新选择模型。") },
            confirmButton = { TextButton(onClick = { confirmUnload = false; scope.launch { ModelManager.unload() } }) { Text("卸载", color = p.error) } },
            dismissButton = { TextButton(onClick = { confirmUnload = false }) { Text("取消") } },
        )
    }
    if (confirmDownload) {
        AlertDialog(
            onDismissRequest = { confirmDownload = false },
            title = { Text("下载本机生图模型？") },
            text = { Text("将从以下地址下载并解压到应用内：\n${DiaSettings.localImageModelUrl.value}\n\n文件较大，请确认网络环境。") },
            confirmButton = {
                TextButton(onClick = {
                    confirmDownload = false
                    scope.launch {
                        imgStatus = try {
                            val n = withContext(Dispatchers.IO) { LocalImageGen.downloadZip(context, DiaSettings.localImageModelUrl.value) }
                            "下载完成：$n 个文件"
                        } catch (e: Exception) { "下载失败：${e.message}" }
                    }
                }) { Text("下载", color = p.cinnabar) }
            },
            dismissButton = { TextButton(onClick = { confirmDownload = false }) { Text("取消") } },
        )
    }
}

@Composable
private fun Section(p: DiaPalette, title: String, content: @Composable () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp)) {
        Text(title, style = MaterialTheme.typography.titleMedium, color = p.cinnabar, fontFamily = DiaSerif,
            modifier = Modifier.padding(start = 6.dp, bottom = 6.dp))
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(p.surface.copy(alpha = 0.9f))
                .scrollFrame(p).padding(vertical = 6.dp),
        ) { content() }
    }
}

@Composable
private fun Info(p: DiaPalette, title: String, value: String) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp)) {
        Text(title, color = p.text, style = MaterialTheme.typography.titleSmall)
        Text(value, color = p.textTertiary, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun Hint(p: DiaPalette, text: String) {
    Text(text, color = p.textTertiary, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp))
}

@Composable
private fun ActionRow(p: DiaPalette, title: String, subtitle: String, danger: Boolean = false, onClick: () -> Unit) {
    Column(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 10.dp)) {
        Text(title, color = if (danger) p.error else p.text, style = MaterialTheme.typography.titleSmall)
        if (subtitle.isNotBlank()) Text(subtitle, color = p.textTertiary, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun ChoiceRow(p: DiaPalette, title: String, options: List<Pair<String, String>>, selected: String, onSelect: (String) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp)) {
        Text(title, color = p.text, style = MaterialTheme.typography.titleSmall)
        Spacer(Modifier.height(6.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            for ((id, label) in options) {
                val sel = id == selected
                Text(
                    label, style = MaterialTheme.typography.labelMedium,
                    color = if (sel) p.onCinnabar else p.textSecondary,
                    modifier = Modifier.clip(RoundedCornerShape(10.dp)).background(if (sel) p.cinnabar else p.surfaceAlt)
                        .clickable { onSelect(id) }.padding(horizontal = 10.dp, vertical = 6.dp),
                )
            }
        }
    }
}

@Composable
private fun FieldRow(p: DiaPalette, label: String, value: String, placeholder: String, secret: Boolean = false, onChange: (String) -> Unit) {
    var local by remember { mutableStateOf(value) }
    OutlinedTextField(
        value = local,
        onValueChange = { local = it; onChange(it) },
        label = { Text(label) },
        placeholder = { Text(placeholder, color = p.textTertiary) },
        singleLine = true,
        visualTransformation = if (secret) PasswordVisualTransformation() else VisualTransformation.None,
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
    )
}

@Composable
private fun TextPref(p: DiaPalette, label: String, pref: StringPref, placeholder: String, secret: Boolean = false) {
    val v by pref.flow.collectAsState()
    FieldRow(p, label, v, placeholder, secret) { pref.set(it.trim()) }
}

@Composable
private fun IntTextPref(p: DiaPalette, label: String, pref: IntPref) {
    val v by pref.flow.collectAsState()
    FieldRow(p, label, v.toString(), "") { s -> s.filter { it.isDigit() }.take(3).toIntOrNull()?.let { pref.set(it) } }
}
