package com.dia.app.ui.slate

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.NavigateBefore
import androidx.compose.material.icons.automirrored.rounded.NavigateNext
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Quiz
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dia.app.llm.DiaEngine
import com.dia.app.slate.AiInkColor
import com.dia.app.slate.AiNote
import com.dia.app.slate.AiStatus
import com.dia.app.slate.HandwritingSynth
import com.dia.app.slate.NotebookMode
import com.dia.app.slate.NotebookPage
import com.dia.app.slate.PageBackground
import com.dia.app.slate.QuizVerdict
import com.dia.app.slate.SlateAi
import com.dia.app.slate.SlateState
import com.dia.app.slate.SlateStore
import com.dia.app.ui.theme.DiaBackground
import com.dia.app.ui.theme.DiaSurface
import com.dia.app.ui.theme.DiaTextPrimary
import com.dia.app.ui.theme.DiaTextSecondary
import com.dia.app.ui.theme.DiaTextTertiary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val QuizAccent = Color(0xFFFFB300)
private val CorrectColor = Color(0xFF22C55E)
private val IncorrectColor = Color(0xFFEF4444)

/**
 * Slate quiz sub-mode.
 *
 * Phases:
 *   1. Topic entry — user types a topic and taps Start.
 *   2. Generating — Gemma produces 10 questions; show a progress card.
 *   3. Quiz — one page per question. User scribbles their answer. Tap
 *      "Grade" to send the page to Gemma. Gemma replies CORRECT/INCORRECT
 *      plus the canonical answer; we show ✓/✗ and write the canonical
 *      answer in handwritten ink at the bottom of the page.
 *   4. Done — summary card with score + retry / new topic options.
 *
 * The quiz is also persisted via SlateStore so the user can resume.
 */
@Composable
fun SlateQuizScreen(onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    var phase by remember { mutableStateOf<QuizPhase>(QuizPhase.TopicEntry) }
    var topic by remember { mutableStateOf("") }
    var state by remember { mutableStateOf<SlateState?>(null) }

    DisposableEffect(Unit) {
        onDispose {
            val s = state ?: return@onDispose
            scope.launch(Dispatchers.IO) { SlateStore.save(s) }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DiaBackground)
            .windowInsetsPadding(WindowInsets.statusBars)
            .windowInsetsPadding(WindowInsets.navigationBars),
    ) {
        // Top bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, "返回", tint = DiaTextSecondary)
            }
            Spacer(Modifier.width(4.dp))
            Text(
                "测验手写板",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.SemiBold),
                color = DiaTextPrimary,
            )
            Spacer(Modifier.weight(1f))
            if (phase is QuizPhase.Quiz || phase is QuizPhase.Done) {
                state?.let { s ->
                    val score = s.pages.count { it.aiNotes.firstOrNull()?.verdict == QuizVerdict.CORRECT }
                    Text(
                        "$score / ${s.pages.size}",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = QuizAccent,
                    )
                }
            }
        }

        when (val p = phase) {
            is QuizPhase.TopicEntry -> TopicEntry(
                topic = topic,
                onTopicChange = { topic = it },
                onStart = {
                    if (topic.trim().isNotEmpty()) {
                        phase = QuizPhase.Generating(topic.trim())
                        scope.launch {
                            generateQuiz(topic.trim(), scope) { questions ->
                                if (questions == null || questions.isEmpty()) {
                                    phase = QuizPhase.TopicEntry
                                    // Could surface an error toast here.
                                    return@generateQuiz
                                }
                                val s = buildQuizState(topic.trim(), questions)
                                state = s
                                scope.launch(Dispatchers.IO) { SlateStore.save(s) }
                                phase = QuizPhase.Quiz
                            }
                        }
                    }
                },
            )
            is QuizPhase.Generating -> Generating(topic = p.topic)
            is QuizPhase.Quiz -> {
                val s = state ?: return@Column
                QuizPlay(
                    state = s,
                    onGrade = { page ->
                        gradePage(s, page, scope) {
                            scope.launch(Dispatchers.IO) { SlateStore.save(s) }
                            // Auto-advance to the next ungraded page if there is one.
                            val nextUngraded = s.pages.indexOfFirst { it.aiNotes.isEmpty() }
                            if (nextUngraded == -1) phase = QuizPhase.Done
                        }
                    },
                    onFinish = { phase = QuizPhase.Done },
                )
            }
            is QuizPhase.Done -> {
                val s = state ?: return@Column
                DoneSummary(
                    state = s,
                    onRetry = {
                        // Wipe answers + retake.
                        for (page in s.pages) {
                            page.clearAll()
                            page.aiNotes.clear()
                        }
                        s.currentPageIndex = 0
                        scope.launch(Dispatchers.IO) { SlateStore.save(s) }
                        phase = QuizPhase.Quiz
                    },
                    onNewTopic = {
                        topic = ""
                        state = null
                        phase = QuizPhase.TopicEntry
                    },
                )
            }
        }
    }
}

private sealed interface QuizPhase {
    data object TopicEntry : QuizPhase
    data class Generating(val topic: String) : QuizPhase
    data object Quiz : QuizPhase
    data object Done : QuizPhase
}

/* ─── Phase 1: Topic entry ─── */

@Composable
private fun ColumnScope.TopicEntry(
    topic: String,
    onTopicChange: (String) -> Unit,
    onStart: () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            modifier = Modifier
                .size(72.dp)
                .clip(CircleShape)
                .background(QuizAccent.copy(alpha = 0.18f)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Rounded.Quiz, null, tint = QuizAccent, modifier = Modifier.size(34.dp))
        }
        Spacer(Modifier.heightIn(min = 16.dp))
        Spacer(Modifier.size(16.dp))
        Text(
            "选择一个主题",
            style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.SemiBold),
            color = DiaTextPrimary,
        )
        Spacer(Modifier.size(6.dp))
        Text(
            "灵犀会出 10 道题，并为你的手写答案评分。",
            style = MaterialTheme.typography.bodyMedium,
            color = DiaTextSecondary,
        )
        Spacer(Modifier.size(20.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(DiaSurface)
                .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(16.dp))
                .padding(horizontal = 14.dp, vertical = 12.dp),
        ) {
            if (topic.isEmpty()) {
                Text(
                    "例如：世界各国首都 · 光合作用 · 三角函数",
                    color = DiaTextTertiary,
                    style = MaterialTheme.typography.bodyMedium,
                )
            }
            BasicTextField(
                value = topic,
                onValueChange = onTopicChange,
                singleLine = true,
                cursorBrush = SolidColor(QuizAccent),
                textStyle = TextStyle(
                    color = DiaTextPrimary,
                    fontSize = 16.sp,
                ),
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { onStart() }),
            )
        }
        Spacer(Modifier.size(16.dp))
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(16.dp))
                .background(if (topic.isNotBlank()) QuizAccent else Color(0xFF272733))
                .padding(horizontal = 24.dp, vertical = 12.dp),
        ) {
            Text(
                "开始测验",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                color = if (topic.isNotBlank()) Color(0xFF0A0B11) else DiaTextTertiary,
                modifier = Modifier
                    .padding(horizontal = 8.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .let { if (topic.isNotBlank()) it.padding(0.dp) else it },
            )
            // The whole tile is clickable.
            IconButton(
                onClick = { if (topic.isNotBlank()) onStart() },
                modifier = Modifier.matchParentSize(),
            ) {}
        }
    }
}

@Composable
private fun ColumnScope.Generating(topic: String) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        CircularProgressIndicator(color = QuizAccent, strokeWidth = 3.dp)
        Spacer(Modifier.size(20.dp))
        Text(
            "正在生成「$topic」测验…",
            style = MaterialTheme.typography.bodyMedium,
            color = DiaTextSecondary,
        )
    }
}

/* ─── Phase 3: Quiz play ─── */

@Composable
private fun ColumnScope.QuizPlay(
    state: SlateState,
    onGrade: (NotebookPage) -> Unit,
    onFinish: () -> Unit,
) {
    val page = state.currentPage ?: return

    // Question banner on top.
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(DiaSurface)
            .border(1.dp, QuizAccent.copy(alpha = 0.35f), RoundedCornerShape(14.dp))
            .padding(horizontal = 14.dp, vertical = 10.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "${state.currentPageIndex + 1}.",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = QuizAccent,
            )
            Spacer(Modifier.width(10.dp))
            Text(
                page.question.orEmpty(),
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                color = DiaTextPrimary,
            )
        }
    }

    Box(
        modifier = Modifier
            .weight(1f)
            .fillMaxWidth(),
    ) {
        PageCanvas(state = state, page = page)

        // Verdict badge — top-end.
        val verdict = page.aiNotes.firstOrNull()?.verdict
        if (verdict != null && verdict != QuizVerdict.UNGRADED) {
            VerdictBadge(
                verdict = verdict,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(top = 8.dp, end = 12.dp),
            )
        }

        // AI status pill (top center, below question banner).
        if (page.aiStatus != AiStatus.IDLE) {
            Row(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 8.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color.Black.copy(alpha = 0.55f))
                    .border(1.dp, QuizAccent.copy(alpha = 0.35f), RoundedCornerShape(16.dp))
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                if (page.aiStatus == AiStatus.ASKING) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(12.dp),
                        color = QuizAccent,
                        strokeWidth = 1.6.dp,
                    )
                }
                Text(
                    when (page.aiStatus) {
                        AiStatus.ASKING -> "评分中…"
                        AiStatus.ERROR -> page.aiStatusText.ifBlank { "无法评分" }
                        else -> ""
                    },
                    color = if (page.aiStatus == AiStatus.ERROR) Color(0xFFFF5252) else QuizAccent,
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Medium),
                )
            }
        }
    }

    // Action bar — sits BELOW the page area as a sibling Row so its
    // touches never compete with the canvas's pointer handler.
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        QuizNavButton(
            icon = Icons.AutoMirrored.Rounded.NavigateBefore,
            contentDesc = "上一题",
            enabled = state.currentPageIndex > 0,
        ) {
            state.currentPageIndex = (state.currentPageIndex - 1).coerceAtLeast(0)
            state.resetView()
        }
        Spacer(Modifier.weight(1f))
        QuizActionButton(state = state, page = page, onGrade = onGrade, onFinish = onFinish)
        Spacer(Modifier.weight(1f))
        QuizNavButton(
            icon = Icons.AutoMirrored.Rounded.NavigateNext,
            contentDesc = "下一题",
            enabled = state.currentPageIndex < state.pages.size - 1,
        ) {
            state.currentPageIndex = (state.currentPageIndex + 1).coerceAtMost(state.pages.size - 1)
            state.resetView()
        }
    }

    // Toolbar fixed at the very bottom.
    SlateToolbar(state = state)
}

@Composable
private fun QuizNavButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    contentDesc: String,
    enabled: Boolean,
    onClick: () -> Unit,
) {
    IconButton(
        onClick = { if (enabled) onClick() },
        modifier = Modifier
            .size(46.dp)
            .clip(CircleShape)
            .background(Color.Black.copy(alpha = if (enabled) 0.55f else 0.25f))
            .border(1.dp, Color.White.copy(alpha = 0.12f), CircleShape),
    ) {
        Icon(
            icon,
            contentDesc,
            tint = if (enabled) Color.White.copy(alpha = 0.9f) else Color.White.copy(alpha = 0.3f),
        )
    }
}

@Composable
private fun QuizActionButton(
    state: SlateState,
    page: NotebookPage,
    onGrade: (NotebookPage) -> Unit,
    onFinish: () -> Unit,
) {
    val graded = page.aiNotes.firstOrNull()?.verdict in listOf(QuizVerdict.CORRECT, QuizVerdict.INCORRECT)
    val isLast = state.currentPageIndex == state.pages.size - 1
    val canGrade = !graded && page.strokes.isNotEmpty() && page.aiStatus == AiStatus.IDLE

    val (label, accent) = when {
        graded && isLast -> "完成" to QuizAccent
        graded -> "下一题" to QuizAccent
        else -> "评分" to QuizAccent
    }

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(14.dp))
            .background(if (canGrade || graded) accent else Color(0xFF272733))
            .padding(horizontal = 22.dp, vertical = 12.dp),
    ) {
        Text(
            label,
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
            color = if (canGrade || graded) Color(0xFF0A0B11) else DiaTextTertiary,
        )
        IconButton(
            onClick = {
                when {
                    graded && isLast -> onFinish()
                    graded -> {
                        state.currentPageIndex = (state.currentPageIndex + 1).coerceAtMost(state.pages.size - 1)
                        state.resetView()
                    }
                    canGrade -> onGrade(page)
                }
            },
            modifier = Modifier.matchParentSize(),
        ) {}
    }
}

@Composable
private fun VerdictBadge(verdict: QuizVerdict, modifier: Modifier = Modifier) {
    val (icon, color, label) = when (verdict) {
        QuizVerdict.CORRECT -> Triple(Icons.Rounded.Check, CorrectColor, "正确")
        QuizVerdict.INCORRECT -> Triple(Icons.Rounded.Close, IncorrectColor, "错误")
        QuizVerdict.UNGRADED -> Triple(Icons.Rounded.Quiz, DiaTextSecondary, "未评分")
    }
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(50))
            .background(color.copy(alpha = 0.18f))
            .border(1.dp, color.copy(alpha = 0.4f), RoundedCornerShape(50))
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Icon(icon, null, tint = color, modifier = Modifier.size(16.dp))
        Text(
            label,
            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
            color = color,
        )
    }
}

/* ─── Phase 4: Done summary ─── */

@Composable
private fun ColumnScope.DoneSummary(
    state: SlateState,
    onRetry: () -> Unit,
    onNewTopic: () -> Unit,
) {
    val correct = state.pages.count { it.aiNotes.firstOrNull()?.verdict == QuizVerdict.CORRECT }
    val total = state.pages.size

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            modifier = Modifier
                .size(96.dp)
                .clip(CircleShape)
                .background(QuizAccent.copy(alpha = 0.18f)),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                "$correct/$total",
                style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                color = QuizAccent,
            )
        }
        Spacer(Modifier.size(20.dp))
        Text(
            when {
                correct == total -> "满分 — 全部答对！"
                correct >= total * 0.7 -> "做得很棒。"
                correct >= total * 0.4 -> "表现不错。"
                else -> "值得再试一次。"
            },
            style = MaterialTheme.typography.titleMedium,
            color = DiaTextPrimary,
        )
        Spacer(Modifier.size(24.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            ActionPill(label = "Retry quiz", primary = false, onClick = onRetry)
            ActionPill(label = "New topic", primary = true, onClick = onNewTopic)
        }
    }
}

@Composable
private fun ActionPill(label: String, primary: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(14.dp))
            .background(if (primary) QuizAccent else DiaSurface)
            .border(
                1.dp,
                if (primary) Color.Transparent else Color.White.copy(alpha = 0.1f),
                RoundedCornerShape(14.dp),
            )
            .padding(horizontal = 22.dp, vertical = 12.dp),
    ) {
        Text(
            label,
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
            color = if (primary) Color(0xFF0A0B11) else DiaTextPrimary,
        )
        IconButton(onClick = onClick, modifier = Modifier.matchParentSize()) {}
    }
}

/* ─── Quiz inference flows ─── */

private fun generateQuiz(
    topic: String,
    scope: kotlinx.coroutines.CoroutineScope,
    onResult: (List<String>?) -> Unit,
) {
    DiaEngine.cancelPilotSession()
    scope.launch(Dispatchers.Main) {
        delay(150)
        SlateAi.generateQuiz(topic, scope) { questions ->
            onResult(questions)
        }
    }
}

private fun buildQuizState(topic: String, questions: List<String>): SlateState {
    val id = SlateStore.newId()
    val state = SlateState(id, "测验 · $topic", NotebookMode.QUIZ)
    state.pageBackground = PageBackground.RULED
    for (q in questions.take(10)) {
        state.addPage(
            NotebookPage(
                id = state.newPageId(),
                width = SlateState.PAGE_WIDTH,
                height = SlateState.PAGE_HEIGHT,
                question = q,
            )
        )
    }
    return state
}

private fun gradePage(
    state: SlateState,
    page: NotebookPage,
    scope: kotlinx.coroutines.CoroutineScope,
    onCommitted: () -> Unit,
) {
    if (page.aiStatus != AiStatus.IDLE) return
    page.aiStatus = AiStatus.ASKING
    page.aiStatusText = ""

    val question = page.question.orEmpty()
    DiaEngine.cancelPilotSession()

    scope.launch(Dispatchers.Main) {
        delay(150)
        SlateAi.gradeAnswer(question, page, scope) { result ->
            if (result == null) {
                page.aiStatus = AiStatus.ERROR
                page.aiStatusText = "无法评分，请重试。"
                scope.launch {
                    delay(2400)
                    if (page.aiStatus == AiStatus.ERROR) page.aiStatus = AiStatus.IDLE
                }
                return@gradeAnswer
            }

            // Pin a verdict note on the page (without text — verdict-only)
            // PLUS write the canonical answer in handwriting if incorrect.
            val verdict = if (result.correct) QuizVerdict.CORRECT else QuizVerdict.INCORRECT
            // Handwritten reply: short and clean. "✓ 3" for correct,
            // "Answer: 3" for incorrect — no narration.
            val replyText = if (result.correct) "\u2713  ${result.canonical}" else "Answer: ${result.canonical}"
            val anchor = com.dia.app.slate.pickAiAnchor(page)
            val note = AiNote(
                id = state.newNoteId(),
                text = replyText,
                anchor = anchor,
                verdict = verdict,
                correctAnswer = result.canonical,
            )
            // Replace existing notes (in case the user is regrading).
            page.aiNotes.clear()
            page.addAiNote(note)

            // Animate the canonical answer in handwriting on the page so
            // the student can see what was right.
            val lineHeight = com.dia.app.slate.estimateLineHeight(page)
            val maxWidth = (page.width - anchor.x - 80f).coerceAtLeast(220f)
            val maxBottom = page.height - 80f
            val strokes = HandwritingSynth.synthesize(
                text = replyText,
                anchor = anchor,
                lineHeight = lineHeight,
                maxWidth = maxWidth,
                color = if (verdict == QuizVerdict.CORRECT) CorrectColor else IncorrectColor,
                maxBottomY = maxBottom,
            )
            scope.launch(Dispatchers.Main) {
                try {
                    if (strokes.isNotEmpty()) {
                        SlateAi.animateStrokes(strokes, state, page)
                    }
                } finally {
                    page.aiStatus = AiStatus.IDLE
                    onCommitted()
                }
            }
        }
    }
}
