package com.dia.app.ui.chat

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.util.Log
import com.dia.app.agent.AgentListener
import com.dia.app.agent.AgentRequest
import com.dia.app.agent.AgentTools
import com.dia.app.agent.DiaAgent
import com.dia.app.agent.Persona
import com.dia.app.agent.ToolHost
import com.dia.app.agent.ToolOutcome
import com.dia.app.files.FileManager
import com.dia.app.files.FileRef
import com.dia.app.llm.AudioClip
import com.dia.app.llm.LlmGateway
import com.dia.app.memory.MemoryExtractor
import com.dia.app.memory.MemoryStore
import com.dia.app.prefs.DiaPrefs
import com.dia.app.prefs.DiaSettings
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

data class SelfLoopState(
    val running: Boolean = false,
    val topic: String = "",
    val roleA: String = "",
    val roleB: String = "",
    val round: Int = 0,
    val total: Int = 0,
)

/**
 * 灵犀的「对话中枢」——整个 App 的核心。
 *
 * 所有功能都汇聚在这一个对话里：普通聊天、看图、语音、读改文件、联网搜索与下载、
 * 翻译、生图、操控手机、屏幕引导、记忆、AI 自循环……悬浮气泡也通过这里提问。
 * 它是应用级单例（不随页面销毁），所以离开界面后任务仍会继续。
 */
object ChatController {

    private const val TAG = "ChatController"

    private lateinit var appCtx: Context
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    private val _activeChatId = MutableStateFlow(UUID.randomUUID().toString())
    val activeChatId: StateFlow<String> = _activeChatId.asStateFlow()

    private val _title = MutableStateFlow("新对话")
    val title: StateFlow<String> = _title.asStateFlow()

    private val _thinking = MutableStateFlow(false)
    val thinking: StateFlow<Boolean> = _thinking.asStateFlow()

    /** 待发送的图片（本地路径） */
    private val _pendingImages = MutableStateFlow<List<String>>(emptyList())
    val pendingImages: StateFlow<List<String>> = _pendingImages.asStateFlow()

    /** 待发送的文件 */
    private val _pendingFiles = MutableStateFlow<List<FileRef>>(emptyList())
    val pendingFiles: StateFlow<List<FileRef>> = _pendingFiles.asStateFlow()

    /** 外部（悬浮气泡 / 分享）带进来的草稿 */
    private val _draft = MutableStateFlow<String?>(null)
    val draft: StateFlow<String?> = _draft.asStateFlow()

    private val _selfLoop = MutableStateFlow(SelfLoopState())
    val selfLoop: StateFlow<SelfLoopState> = _selfLoop.asStateFlow()

    /** 界面事件：move_to_back / toast:文字 */
    private val _events = MutableSharedFlow<String>(extraBufferCapacity = 16)
    val events: SharedFlow<String> = _events.asSharedFlow()

    private val confirms = ConcurrentHashMap<String, CompletableDeferred<Boolean>>()
    private var job: Job? = null
    private var userTurns = 0

    fun attach(context: Context) {
        if (::appCtx.isInitialized) return
        appCtx = context.applicationContext
        _thinking.value = DiaPrefs.thinkingDefault.value
    }

    val context: Context get() = appCtx

    // ───────── 消息列表工具 ─────────

    private fun append(m: ChatMessage) { _messages.update { it + m } }

    private fun updateMsg(id: String, f: (ChatMessage) -> ChatMessage) {
        _messages.update { list -> list.map { if (it.id == id) f(it) else it } }
    }

    private fun insertBefore(anchorId: String?, m: ChatMessage) {
        _messages.update { list ->
            val i = if (anchorId == null) -1 else list.indexOfFirst { it.id == anchorId }
            if (i < 0) list + m else list.subList(0, i) + m + list.subList(i, list.size)
        }
    }

    private fun removeMsg(id: String) { _messages.update { list -> list.filter { it.id != id } } }

    fun note(text: String) {
        append(ChatMessage(text = text, isUser = false, kind = ChatMessage.KIND_NOTE))
    }

    // ───────── 附件 ─────────

    fun addImage(bitmap: Bitmap) {
        val path = try { ImageUtil.save(appCtx, bitmap) } catch (e: Exception) { Log.e(TAG, "save image", e); return }
        _pendingImages.update { (it + path).takeLast(4) }
    }

    fun addImageUri(uri: Uri) {
        scope.launch {
            val bmp = withContext(Dispatchers.IO) { ImageUtil.loadFromUri(appCtx, uri) }
            if (bmp != null) addImage(bmp) else _events.tryEmit("toast:图片读取失败")
        }
    }

    fun addFileUri(uri: Uri) {
        scope.launch {
            try {
                val ref = withContext(Dispatchers.IO) { FileManager.attach(uri) }
                if (ref.mime.startsWith("image/")) {
                    addImageUri(uri)
                } else {
                    _pendingFiles.update { list -> if (list.any { it.id == ref.id }) list else list + ref }
                }
            } catch (e: Exception) {
                _events.tryEmit("toast:文件附加失败：${e.message}")
            }
        }
    }

    /** 把已附加过的文件再次加到本条消息。 */
    fun addExistingFile(ref: FileRef) {
        _pendingFiles.update { list -> if (list.any { it.id == ref.id }) list else list + ref }
    }

    fun removePendingImage(path: String) { _pendingImages.update { it - path } }
    fun removePendingFile(id: String) { _pendingFiles.update { list -> list.filter { it.id != id } } }

    fun setDraft(text: String?) { _draft.value = text }
    fun consumeDraft(): String? { val d = _draft.value; _draft.value = null; return d }

    fun setThinking(on: Boolean) { _thinking.value = on }

    // ───────── 发送 ─────────

    /**
     * 发送一条消息。
     * @param hiddenContext 额外附带给模型、但不在界面显示的内容（如屏幕文字）
     * @param onFinal 回复完成后回调最终文本（悬浮气泡用）
     */
    fun send(
        text: String,
        audio: AudioClip? = null,
        hiddenContext: String? = null,
        onFinal: ((String) -> Unit)? = null,
        useAttachments: Boolean = true,
    ) {
        val trimmed = text.trim()
        val images = if (useAttachments) _pendingImages.value else emptyList()
        val files = if (useAttachments) _pendingFiles.value else emptyList()
        if (trimmed.isEmpty() && audio == null && images.isEmpty() && files.isEmpty()) return

        // 自循环中：作为「插话」加入对话，下一轮发言会回应
        if (_selfLoop.value.running) {
            if (trimmed.isNotEmpty()) {
                append(ChatMessage(text = trimmed, isUser = true))
                note("已插话，下一位发言者会回应你的新信息")
            }
            return
        }
        if (_isGenerating.value) {
            onFinal?.invoke("灵犀正在回复上一条消息，请稍后再试。")
            return
        }

        // 斜杠命令
        if (trimmed.startsWith("/") && audio == null && handleCommand(trimmed)) return

        MemoryExtractor.cancel()
        if (useAttachments) {
            _pendingImages.value = emptyList()
            _pendingFiles.value = emptyList()
        }

        val userMsg = ChatMessage(
            text = trimmed.ifEmpty { if (audio != null) "🎤 语音消息" else "" },
            isUser = true,
            imagePaths = images,
            fileIds = files.map { it.id },
            fileNames = files.map { it.name },
            hiddenContext = hiddenContext,
        )
        val history = _messages.value
        append(userMsg)
        if (trimmed.isNotEmpty()) {
            val saved = MemoryExtractor.quickExtract(trimmed)
            if (saved.isNotEmpty()) note("📝 已记住：" + saved.joinToString("；") { it.content })
        }
        runTurn(
            history = history,
            userText = if (trimmed.isEmpty() && audio != null) "（请听这段语音并回应）" else trimmed,
            hiddenContext = hiddenContext,
            imagePaths = images,
            audio = audio,
            files = files,
            forcedTool = null,
            onFinal = onFinal,
        )
    }

    /** 悬浮气泡「问灵犀」：结合屏幕内容提问。 */
    fun askFromBubble(question: String, screenText: String?, onFinal: (String) -> Unit) {
        if (!LlmGateway.isAvailable()) {
            onFinal("模型还没加载，请先打开灵犀选择模型。")
            return
        }
        val ctx = screenText?.takeIf { it.isNotBlank() }?.let { "用户当前手机屏幕上的文字：\n$it" }
        scope.launch { send(question, hiddenContext = ctx, onFinal = onFinal, useAttachments = false) }
    }

    private fun runTurn(
        history: List<ChatMessage>,
        userText: String,
        hiddenContext: String?,
        imagePaths: List<String>,
        audio: AudioClip?,
        files: List<FileRef>,
        forcedTool: Pair<String, JSONObject>?,
        onFinal: ((String) -> Unit)?,
    ) {
        if (!LlmGateway.isAvailable()) {
            append(ChatMessage(
                text = "还没有可用的模型：请点顶部选择一个本地模型（.litertlm），或在 设置 → 云端模型 中配置。\n\n小提示：不加载模型也可以用「/画 描述」直接生图。",
                isUser = false, isError = true,
            ))
            persist()
            onFinal?.invoke("模型未加载")
            return
        }
        val aid = UUID.randomUUID().toString()
        append(ChatMessage(id = aid, text = "", isUser = false, isStreaming = true, source = LlmGateway.label()))
        _isGenerating.value = true

        job = scope.launch {
            var finalText = ""
            try {
                val bitmaps = withContext(Dispatchers.IO) { imagePaths.mapNotNull { ImageUtil.decodeFile(it, 1024) } }
                val req = AgentRequest(
                    history = history.filter { it.kind != ChatMessage.KIND_NOTE },
                    userText = userText,
                    hiddenContext = hiddenContext,
                    images = bitmaps,
                    audio = listOfNotNull(audio),
                    files = files,
                    thinking = _thinking.value,
                    forcedTool = forcedTool,
                )
                finalText = DiaAgent.run(req, listenerFor(aid))
                finishAssistant(aid, finalText)
            } catch (e: kotlinx.coroutines.CancellationException) {
                finishAssistant(aid, currentText(aid), stopped = true)
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "turn failed", e)
                updateMsg(aid) {
                    it.copy(text = "出错了：${e.message ?: e.javaClass.simpleName}", isStreaming = false, isError = true, isRetryable = true, isThinking = false)
                }
                finalText = "出错了：${e.message}"
            } finally {
                _isGenerating.value = false
                cancelPendingConfirms()
                persist()
                onFinal?.invoke(finalText.ifBlank { lastToolSummary() })
                afterTurn()
            }
        }
    }

    private fun currentText(id: String): String = _messages.value.firstOrNull { it.id == id }?.text.orEmpty()

    private fun lastToolSummary(): String =
        _messages.value.lastOrNull { it.kind == ChatMessage.KIND_TOOL }?.let { "${it.title}\n${it.detail.orEmpty()}" }.orEmpty()

    private fun finishAssistant(id: String, text: String, stopped: Boolean = false) {
        val msg = _messages.value.firstOrNull { it.id == id } ?: return
        val t = text.trim()
        if (t.isEmpty() && msg.thinking.isNullOrBlank()) {
            if (stopped) updateMsg(id) { it.copy(text = "（已停止）", isStreaming = false, isThinking = false) }
            else removeMsg(id)
        } else {
            updateMsg(id) { it.copy(text = if (stopped && t.isNotEmpty()) "$t\n\n（已停止）" else t, isStreaming = false, isThinking = false) }
        }
    }

    private fun listenerFor(aid: String, persona: String? = null): AgentListener = object : AgentListener {
        override val context: Context get() = appCtx

        override fun onText(text: String) {
            updateMsg(aid) { it.copy(text = text, isThinking = false) }
        }

        override fun onThought(delta: String) {
            updateMsg(aid) { it.copy(thinking = it.thinking.orEmpty() + delta, isThinking = true) }
        }

        override fun onToolStart(name: String, title: String): String {
            val card = ChatMessage(
                text = "", isUser = false, kind = ChatMessage.KIND_TOOL, toolName = name,
                title = title, status = "running", persona = persona,
            )
            insertBefore(aid, card)
            currentCard = card.id
            return card.id
        }

        override fun onToolEnd(cardId: String, outcome: ToolOutcome) {
            updateMsg(cardId) {
                it.copy(status = if (outcome.ok) "done" else "error", detail = outcome.display.take(20000), text = "")
            }
            outcome.imagePath?.let { path ->
                insertBefore(aid, ChatMessage(
                    text = "", isUser = false, kind = ChatMessage.KIND_IMAGE,
                    imagePaths = listOf(path), detail = outcome.display.removePrefix("提示词："),
                ))
            }
            if (currentCard == cardId) currentCard = null
        }

        @Volatile
        private var currentCard: String? = null

        override fun progress(text: String) {
            val c = currentCard ?: return
            updateMsg(c) { it.copy(text = text) }
        }

        override suspend fun confirm(title: String, detail: String): Boolean {
            val msg = ChatMessage(
                text = "", isUser = false, kind = ChatMessage.KIND_CONFIRM,
                title = title, detail = detail, status = "pending",
            )
            val d = CompletableDeferred<Boolean>()
            confirms[msg.id] = d
            insertBefore(aid, msg)
            _events.tryEmit("confirm")
            return try {
                d.await()
            } finally {
                confirms.remove(msg.id)
                updateMsg(msg.id) { if (it.status == "pending") it.copy(status = "rejected") else it }
            }
        }

        override fun moveAppToBack() {
            _events.tryEmit("move_to_back")
        }
    }

    /** 确认卡片上点「同意 / 拒绝」。 */
    fun resolveConfirm(id: String, approved: Boolean) {
        updateMsg(id) { it.copy(status = if (approved) "approved" else "rejected") }
        confirms[id]?.complete(approved)
    }

    private fun cancelPendingConfirms() {
        for ((_, d) in confirms) d.complete(false)
        confirms.clear()
    }

    fun stop() {
        cancelPendingConfirms()
        job?.cancel()
        job = null
        LlmGateway.cancelCurrent()
        _isGenerating.value = false
        if (_selfLoop.value.running) _selfLoop.value = _selfLoop.value.copy(running = false)
    }

    private fun afterTurn() {
        userTurns++
        if (!DiaSettings.autoMemory.value || !DiaSettings.memoryEnabled.value) return
        if (userTurns % 2 != 0) return
        val transcript = _messages.value
            .filter { it.kind == ChatMessage.KIND_TEXT && !it.isError && it.text.isNotBlank() }
            .takeLast(8)
            .joinToString("\n") { (if (it.isUser) "用户：" else "灵犀：") + it.text.take(400) }
        MemoryExtractor.scheduleLlmExtract(transcript) { saved ->
            scope.launch { note("📝 已记住：" + saved.joinToString("；") { it.content }) ; persist() }
        }
    }

    // ───────── 斜杠命令 ─────────

    /** @return true 表示已处理 */
    private fun handleCommand(text: String): Boolean {
        val cmd = text.substringBefore(' ').substringBefore('\n').lowercase()
        val arg = text.substring(cmd.length).trim()
        fun forced(tool: String, args: JSONObject) {
            val history = _messages.value
            append(ChatMessage(text = text, isUser = true))
            runTurn(history, arg, null, emptyList(), null, emptyList(), tool to args, null)
        }
        when (cmd) {
            "/画", "/图", "/draw", "/img" -> {
                if (arg.isBlank()) { note("用法：/画 一只在竹林里看书的熊猫，水墨风"); return true }
                append(ChatMessage(text = text, isUser = true))
                generateImageDirect(arg)
            }
            "/搜", "/search" -> if (arg.isBlank()) note("用法：/搜 关键词") else forced("web_search", JSONObject().put("query", arg))
            "/译", "/翻译" -> if (arg.isBlank()) note("用法：/译 要翻译的内容") else forced("translate", JSONObject().put("text", arg))
            "/控", "/操作" -> if (arg.isBlank()) note("用法：/控 打开微信给张三发“晚点到”") else forced("phone_task", JSONObject().put("task", arg))
            "/引导" -> if (arg.isBlank()) note("用法：/引导 怎么在设置里打开深色模式") else forced("guide", JSONObject().put("question", arg))
            "/记", "/记住" -> {
                if (arg.isBlank()) { note("用法：/记 我对花生过敏"); return true }
                append(ChatMessage(text = text, isUser = true))
                val m = MemoryStore.add(arg, "其他", "manual")
                note(if (m != null) "📝 已记住：${m.content}" else "内容太短，没有记录")
                persist()
            }
            "/自循环", "/loop" -> {
                startSelfLoop(arg.ifBlank { "人工智能会如何改变普通人的生活" })
            }
            "/帮助", "/help" -> {
                note("可用命令：\n/画 描述 —— 直接生图\n/搜 关键词 —— 联网搜索并总结\n/译 内容 —— 翻译\n/控 任务 —— 让灵犀操控手机\n/引导 问题 —— 屏幕上手把手指引\n/记 内容 —— 写入记忆\n/自循环 主题 —— 让两个 AI 角色自己讨论")
            }
            else -> return false
        }
        return true
    }

    /** 不经过大模型直接生图（没有加载模型时也可用）。 */
    fun generateImageDirect(prompt: String) {
        if (_isGenerating.value) return
        _isGenerating.value = true
        val card = ChatMessage(text = "", isUser = false, kind = ChatMessage.KIND_TOOL, toolName = "generate_image",
            title = AgentTools.cardTitle("generate_image", JSONObject().put("prompt", prompt)), status = "running")
        append(card)
        val host = object : ToolHost {
            override val context: Context get() = appCtx
            override suspend fun confirm(title: String, detail: String): Boolean = true
            override fun progress(text: String) { updateMsg(card.id) { it.copy(text = text) } }
            override fun moveAppToBack() {}
        }
        job = scope.launch {
            try {
                val outcome = AgentTools.generateImage(prompt, "", host)
                updateMsg(card.id) { it.copy(status = if (outcome.ok) "done" else "error", detail = outcome.display, text = if (outcome.ok) "" else outcome.forModel) }
                outcome.imagePath?.let { append(ChatMessage(text = "", isUser = false, kind = ChatMessage.KIND_IMAGE, imagePaths = listOf(it), detail = outcome.display.removePrefix("提示词："))) }
            } catch (e: kotlinx.coroutines.CancellationException) {
                updateMsg(card.id) { it.copy(status = "error", text = "已停止") }
                throw e
            } catch (e: Exception) {
                updateMsg(card.id) { it.copy(status = "error", text = "生图失败：${e.message}") }
            } finally {
                _isGenerating.value = false
                persist()
            }
        }
    }

    // ───────── AI 自循环 ─────────

    fun startSelfLoop(
        topic: String,
        roleA: String = DiaSettings.selfLoopRoleA.value,
        roleB: String = DiaSettings.selfLoopRoleB.value,
        rounds: Int = DiaSettings.selfLoopRounds.value,
    ) {
        if (_isGenerating.value || _selfLoop.value.running) return
        if (!LlmGateway.isAvailable()) {
            note("自循环需要先加载模型。")
            return
        }
        val a = roleA.ifBlank { "甲" }
        val b = roleB.ifBlank { "乙" }
        val total = rounds.coerceIn(1, 30)
        MemoryExtractor.cancel()
        note("🔄 自循环开始 · 主题「$topic」\n「$a」与「$b」将进行 $total 轮讨论。你可以随时在下方输入插话，或点 ■ 停止。")
        val startIndex = _messages.value.size
        _selfLoop.value = SelfLoopState(true, topic, a, b, 0, total)
        _isGenerating.value = true
        job = scope.launch {
            try {
                for (i in 0 until total * 2) {
                    ensureActive()
                    if (!_selfLoop.value.running) break
                    val speaker = if (i % 2 == 0) a else b
                    val other = if (i % 2 == 0) b else a
                    val round = i / 2 + 1
                    _selfLoop.update { it.copy(round = round) }
                    val history = _messages.value.drop(startIndex).filter { it.kind != ChatMessage.KIND_NOTE }
                    val aid = UUID.randomUUID().toString()
                    append(ChatMessage(id = aid, text = "", isUser = false, isStreaming = true, persona = speaker, source = "自循环 · 第${round}轮"))
                    val text = DiaAgent.run(
                        AgentRequest(
                            history = history,
                            userText = "",
                            persona = Persona(speaker, other, topic, round, total),
                        ),
                        listenerFor(aid, speaker),
                    )
                    finishAssistant(aid, text)
                    persist()
                }
                note("✅ 自循环结束。可以继续提问，例如「总结一下刚才的讨论」。")
            } catch (e: kotlinx.coroutines.CancellationException) {
                note("⏹ 自循环已停止")
                throw e
            } catch (e: Exception) {
                note("自循环中断：${e.message}")
            } finally {
                _messages.value.lastOrNull { it.isStreaming }?.let { m -> finishAssistant(m.id, m.text, stopped = true) }
                _selfLoop.value = _selfLoop.value.copy(running = false)
                _isGenerating.value = false
                persist()
            }
        }
    }

    // ───────── 会话管理 ─────────

    fun retryLast() {
        if (_isGenerating.value) return
        val list = _messages.value
        val lastUserIdx = list.indexOfLast { it.isUser }
        if (lastUserIdx < 0) return
        val user = list[lastUserIdx]
        _messages.value = list.subList(0, lastUserIdx)
        _pendingImages.value = user.imagePaths
        _pendingFiles.value = user.fileIds.mapNotNull { FileManager.find(it) }
        send(user.text, hiddenContext = user.hiddenContext)
    }

    /** 编辑一条用户消息并重新发送（之后的消息会被替换）。 */
    fun editAndResend(id: String, newText: String) {
        if (_isGenerating.value) return
        val list = _messages.value
        val idx = list.indexOfFirst { it.id == id && it.isUser }
        if (idx < 0) return
        val old = list[idx]
        _messages.value = list.subList(0, idx)
        _pendingImages.value = old.imagePaths
        _pendingFiles.value = old.fileIds.mapNotNull { FileManager.find(it) }
        send(newText, hiddenContext = old.hiddenContext)
    }

    fun deleteMessage(id: String) {
        removeMsg(id)
        persist()
    }

    fun newChat() {
        if (_isGenerating.value) stop()
        persist()
        _messages.value = emptyList()
        _activeChatId.value = UUID.randomUUID().toString()
        _title.value = "新对话"
        _pendingImages.value = emptyList()
        _pendingFiles.value = emptyList()
    }

    /** 打开历史对话：可以直接接着聊（每轮都会把历史重新整理进提示词）。 */
    fun openHistory(threadId: String) {
        if (threadId == _activeChatId.value && _messages.value.isNotEmpty()) return
        if (_isGenerating.value) stop()
        persist()
        scope.launch {
            val loaded = ChatHistoryStore.loadMessages(threadId)
            _activeChatId.value = threadId
            _messages.value = loaded
            _title.value = ChatHistoryStore.threads.value.firstOrNull { it.id == threadId }?.title
                ?: ChatHistoryStore.deriveTitle(loaded)
        }
    }

    fun deleteThread(threadId: String) {
        scope.launch {
            ChatHistoryStore.delete(threadId)
            if (threadId == _activeChatId.value) {
                _messages.value = emptyList()
                _activeChatId.value = UUID.randomUUID().toString()
                _title.value = "新对话"
            }
        }
    }

    fun clearCurrent() {
        if (_isGenerating.value) stop()
        val id = _activeChatId.value
        scope.launch { ChatHistoryStore.delete(id) }
        _messages.value = emptyList()
        _activeChatId.value = UUID.randomUUID().toString()
        _title.value = "新对话"
    }

    fun persist() {
        val msgs = _messages.value
        if (msgs.isEmpty() || !::appCtx.isInitialized) return
        val id = _activeChatId.value
        val title = if (_title.value == "新对话" || _title.value.isBlank()) {
            ChatHistoryStore.deriveTitle(msgs).also { _title.value = it }
        } else _title.value
        val model = LlmGateway.label()
        scope.launch(Dispatchers.IO) {
            try { ChatHistoryStore.save(id, title, msgs, model) } catch (e: Exception) { Log.e(TAG, "persist", e) }
        }
    }
}
