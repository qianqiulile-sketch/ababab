package com.dia.app.ui.chat

import java.util.UUID

/**
 * 对话里的一条消息。除了普通的用户 / 灵犀文本，还用 [kind] 表示：
 *  - [KIND_TOOL]    工具调用卡片（联网搜索、读文件、操控手机…）
 *  - [KIND_CONFIRM] 需要用户同意的操作（改文件、下载、操控手机…）
 *  - [KIND_IMAGE]   生成的图片
 *  - [KIND_NOTE]    系统提示（如“已记住：…”），不会发给模型
 */
data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val text: String,
    val isUser: Boolean,
    val timestamp: Long = System.currentTimeMillis(),
    val isStreaming: Boolean = false,
    val isError: Boolean = false,
    /** True when this error message can be retried. */
    val isRetryable: Boolean = false,
    /** 模型的思考过程（Gemma 4 thinking）。 */
    val thinking: String? = null,
    /** True while the thinking channel is actively streaming. */
    val isThinking: Boolean = false,
    /** 内联 `<think>` 解析状态。 */
    val insideInlineThink: Boolean = false,
    /** 产生此消息的模型（“本地 · …” / “云端 · …”）。 */
    val source: String? = null,

    val kind: String = KIND_TEXT,
    /** 自循环中的角色名（甲 / 乙） */
    val persona: String? = null,
    /** 工具名，如 web_search */
    val toolName: String? = null,
    /** 工具 / 确认卡片标题 */
    val title: String? = null,
    /** 工具结果 / 确认详情（可展开查看） */
    val detail: String? = null,
    /** running / done / error ；确认卡片：pending / approved / rejected */
    val status: String? = null,
    /** 消息附带的图片（用户发送的或生成的），本地文件路径 */
    val imagePaths: List<String> = emptyList(),
    /** 消息附带的文件 id（FileManager 中的 f1、f2…） */
    val fileIds: List<String> = emptyList(),
    /** 附带文件的显示名称 */
    val fileNames: List<String> = emptyList(),
    /** 用户消息：在发给模型时额外附带的上下文（例如悬浮气泡读到的屏幕文字），不在界面显示 */
    val hiddenContext: String? = null,
) {
    companion object {
        const val KIND_TEXT = "text"
        const val KIND_TOOL = "tool"
        const val KIND_CONFIRM = "confirm"
        const val KIND_IMAGE = "image"
        const val KIND_NOTE = "note"
    }
}
