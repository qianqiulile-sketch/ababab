package com.dia.app

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.lifecycleScope
import com.dia.app.pilot.PilotAgent
import com.dia.app.prefs.DiaPrefs
import com.dia.app.screen.NavBus
import com.dia.app.screen.ScreenAssistant
import com.dia.app.slate.SlateStore
import com.dia.app.ui.chat.ChatController
import com.dia.app.ui.chat.ChatHistoryStore
import com.dia.app.voice.DiaTts
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    companion object {
        @Volatile
        var pendingQuickAction: String? = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        PilotAgent.attach(applicationContext)
        DiaPrefs.init(applicationContext)
        ScreenAssistant.attach(applicationContext)
        ChatController.attach(applicationContext)
        lifecycleScope.launch { ChatHistoryStore.init(applicationContext) }
        lifecycleScope.launch { SlateStore.init(applicationContext) }
        com.dia.app.llm.ModelManager.autoloadIfPreferred(applicationContext)
        pendingQuickAction = intent?.action
        handleShare(intent)
        setContent { DiaApp() }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        pendingQuickAction = intent.action
        when (intent.action) {
            DiaQuickLaunchService.ACTION_CHAT -> NavBus.requestChat()
        }
        handleShare(intent)
    }

    /** 其它应用「分享到灵犀」：文字放进输入框，文件 / 图片作为附件。 */
    private fun handleShare(intent: Intent?) {
        if (intent == null) return
        when (intent.action) {
            Intent.ACTION_SEND -> {
                intent.getStringExtra(Intent.EXTRA_TEXT)?.takeIf { it.isNotBlank() }?.let { ChatController.setDraft(it) }
                streamExtra(intent)?.let { attach(it, intent.type) }
                NavBus.requestChat()
            }
            Intent.ACTION_SEND_MULTIPLE -> {
                streamListExtra(intent).take(5).forEach { attach(it, intent.type) }
                NavBus.requestChat()
            }
            Intent.ACTION_VIEW -> {
                intent.data?.let { attach(it, intent.type) }
                NavBus.requestChat()
            }
        }
    }

    private fun attach(uri: Uri, type: String?) {
        if (type?.startsWith("image/") == true) ChatController.addImageUri(uri) else ChatController.addFileUri(uri)
    }

    @Suppress("DEPRECATION")
    private fun streamExtra(intent: Intent): Uri? =
        if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
        else intent.getParcelableExtra(Intent.EXTRA_STREAM)

    @Suppress("DEPRECATION")
    private fun streamListExtra(intent: Intent): List<Uri> =
        (if (Build.VERSION.SDK_INT >= 33) intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM, Uri::class.java)
        else intent.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM)).orEmpty()

    override fun onDestroy() {
        super.onDestroy()
        DiaTts.shutdown()
    }
}
