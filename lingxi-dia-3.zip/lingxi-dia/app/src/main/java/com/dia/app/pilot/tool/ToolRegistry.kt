package com.dia.app.pilot.tool

import com.dia.app.pilot.tool.impl.*

object ToolRegistry {
    private val tools = LinkedHashMap<String, BaseTool>()

    fun registerAll() {
        tools.clear()
        register(GetScreenInfoTool())
        register(FinishTool())
        register(TapTool())
        register(TapNodeTool())
        register(LongPressTool())
        register(SwipeTool())
        register(FindAndTapTool())
        register(ScrollToFindTool())
        register(InputTextTool())
        register(SystemKeyTool())
        register(OpenAppTool())
        register(OpenUrlTool())
        register(SearchInAppTool())
        register(SendMessageTool())
        register(MakeCallTool())
        register(GetNotificationsTool())
        register(ClipboardTool())
        register(GetInstalledAppsTool())
        register(GetDeviceInfoTool())
        register(WaitTool())
    }

    fun register(tool: BaseTool) {
        tools[tool.getName()] = tool
    }

    fun getTool(name: String): BaseTool? = tools[name]

    fun getAllTools(): List<BaseTool> = tools.values.toList()

    fun executeTool(name: String, params: Map<String, Any>): ToolResult {
        // Fuzzy tool name matching — the model sometimes uses slight variants.
        val tool = tools[name]
            ?: tools[name.replace("-", "_")]
            ?: tools[name.replace("_", "")]
            ?: tools.entries.firstOrNull { it.key.contains(name, ignoreCase = true) }?.value
            ?: return ToolResult.error("Unknown tool: $name. Available: ${tools.keys.joinToString()}")
        return try {
            tool.executeWithWaitAfter(params)
        } catch (e: Exception) {
            ToolResult.error("Tool execution failed: ${e.message}")
        }
    }
}
