package com.dia.app.pilot.tool.impl

import com.dia.app.DiaAccessibilityService
import com.dia.app.pilot.tool.BaseTool
import com.dia.app.pilot.tool.ToolParameter
import com.dia.app.pilot.tool.ToolResult

class OpenAppTool : BaseTool() {
    override fun getName(): String = "open_app"

    override fun getDescription(): String = "Open an app by name. If already open, returns success."

    override fun getParameters(): List<ToolParameter> = listOf(
        ToolParameter("package_name", "string", "App package name", false),
        ToolParameter("app_name", "string", "App display name (e.g. YouTube)", false),
    )

    override fun execute(params: Map<String, Any>): ToolResult {
        return try {
            val service = requireAccessibilityService()
                ?: return ToolResult.error("Accessibility service is not running")
            val ctx = service.applicationContext
            val pm = ctx.packageManager

            // Accept various param key formats — model sometimes truncates keys
            val pkg = (params["package_name"] ?: params["package"] ?: params["pkg"] ?: "")
                .toString().trim()
            val appName = (params["app_name"] ?: params["app_na"] ?: params["name"]
                ?: params["app"] ?: params["appName"] ?: "").toString().trim()

            if (pkg.isEmpty() && appName.isEmpty()) {
                return ToolResult.error("Provide app_name or package_name")
            }

            // Resolve the target package
            var targetPkg: String? = null

            // Try package name first (skip if it's our own package)
            if (pkg.isNotEmpty() && pkg != "com.dia.app") {
                // Verify it exists
                val intent = pm.getLaunchIntentForPackage(pkg)
                if (intent != null) targetPkg = pkg
            }

            // Try app name search
            if (targetPkg == null && appName.isNotEmpty()) {
                val match = pm.getInstalledApplications(0).firstOrNull { appInfo ->
                    val label = pm.getApplicationLabel(appInfo).toString()
                    label.equals(appName, ignoreCase = true) ||
                        label.contains(appName, ignoreCase = true)
                }
                targetPkg = match?.packageName
            }

            if (targetPkg == null || targetPkg == "com.dia.app") {
                return ToolResult.error("App not found: ${appName.ifEmpty { pkg }}. Check the exact app name.")
            }

            // Check if already in foreground
            val currentPkg = try {
                service.rootInActiveWindow?.packageName?.toString()
            } catch (_: Exception) { null }

            if (currentPkg != null && currentPkg == targetPkg) {
                return ToolResult.success("$targetPkg is already open. Proceed with the task inside the app.")
            }

            val intent = pm.getLaunchIntentForPackage(targetPkg)
            if (intent != null) {
                intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(intent)
                return ToolResult.success("Opened $targetPkg")
            }

            return ToolResult.error("Cannot launch $targetPkg")
        } catch (e: Exception) {
            ToolResult.error("App launch error: ${e.message}")
        }
    }
}
