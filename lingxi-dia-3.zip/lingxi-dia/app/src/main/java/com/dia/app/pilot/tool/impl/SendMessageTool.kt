package com.dia.app.pilot.tool.impl

import android.graphics.Rect
import android.os.Bundle
import android.view.accessibility.AccessibilityNodeInfo
import com.dia.app.DiaAccessibilityService
import com.dia.app.pilot.tool.BaseTool
import com.dia.app.pilot.tool.ToolParameter
import com.dia.app.pilot.tool.ToolResult
import java.util.Locale

/**
 * High-level "send a message" tool — does the entire WhatsApp/Telegram flow
 * in ONE tool call. Inspired by PokeClaw's SendMessageTool: instead of
 * making the LLM plan navigate-to-contact-then-type-then-tap-send, we do
 * all of that deterministically inside a single tool. This is the only
 * way a 4B local model produces messaging demos that work.
 *
 * Strategy (app-agnostic):
 *   1. Resolve the package name from the app argument.
 *   2. Open the app and wait for its window to become active.
 *   3. If we are already in that contact's chat (toolbar text matches),
 *      skip navigation.
 *   4. Otherwise, search-or-scroll the chat list and tap the contact.
 *   5. Find the BOTTOMMOST EditText on screen — the message input is
 *      always at the bottom; the search bar is at the top. This is the
 *      key insight that breaks the "model taps contact name header" loop.
 *   6. Set the message text via ACTION_SET_TEXT.
 *   7. Tap a node whose content-description contains "send" (in any
 *      language). If none, press IME Enter.
 *   8. Verify the composer field is empty afterwards (= message left).
 */
class SendMessageTool : BaseTool() {

    override fun getName(): String = "send_message"

    override fun getDescription(): String =
        "Send a text message to a contact via a messaging app (WhatsApp, Telegram, " +
            "Messages, etc). Handles the entire flow: opens the app, finds the contact, " +
            "types, and sends. Use this whenever the user asks to message someone."

    override fun getParameters(): List<ToolParameter> = listOf(
        ToolParameter("contact", "string", "Contact name to message (e.g. 'Mom', 'Lakshya')", true),
        ToolParameter("message", "string", "The message text to send", true),
        ToolParameter("app", "string", "Messaging app (default: WhatsApp)", false),
    )

    override fun execute(params: Map<String, Any>): ToolResult {
        val service = requireAccessibilityService()
            ?: return ToolResult.error("Accessibility service is not running")

        val contact = requireString(params, "contact").trim()
        val message = requireString(params, "message").trim()
        val app = optionalString(params, "app", "WhatsApp").trim().ifEmpty { "WhatsApp" }

        try {
            // Step 1 — resolve package
            val pkg = resolvePackage(service, app)
                ?: return ToolResult.error("App '$app' is not installed.")

            // Step 2 — launch + wait
            launchApp(service, pkg)
            Thread.sleep(1500)
            if (!waitForActiveWindow(service, pkg, 8000)) {
                return ToolResult.error("$app did not become active. Is it installed and not blocked?")
            }
            Thread.sleep(800) // let the chat list paint

            // Step 3 — already in this contact's chat?
            if (!isAlreadyInChatWith(service, contact)) {
                // Step 4 — find + tap contact
                if (!findAndTapContact(service, contact)) {
                    return ToolResult.error(
                        "Could not find contact '$contact' in $app. " +
                            "Make sure the contact is in your chats."
                    )
                }
                Thread.sleep(2500) // chat opens
                waitForActiveWindow(service, pkg, 4000)
            }

            // Step 5 — find bottommost EditText and type
            var typed = false
            for (retry in 0 until 5) {
                if (typeInBottomEditText(service, message)) { typed = true; break }
                Thread.sleep(900)
            }
            if (!typed) {
                return ToolResult.error("Could not find message input field in $app.")
            }
            Thread.sleep(500)

            // Step 6 — tap send (or press Enter)
            val sent = tapSendOrEnter(service, message)
            return if (sent) {
                ToolResult.success("Sent '$message' to $contact via $app")
            } else {
                ToolResult.error(
                    "Typed message but could not find Send button. The user may need to tap " +
                        "the send arrow manually."
                )
            }
        } catch (e: InterruptedException) {
            Thread.currentThread().interrupt()
            return ToolResult.error("Interrupted")
        } catch (e: Exception) {
            return ToolResult.error("send_message failed: ${e.message}")
        }
    }

    // ── Package resolution ──

    private fun resolvePackage(service: DiaAccessibilityService, app: String): String? {
        val ctx = service.applicationContext
        val pm = ctx.packageManager
        val key = app.lowercase(Locale.US)

        // Common messaging apps
        val knownPackages = mapOf(
            "whatsapp" to "com.whatsapp",
            "whatsapp business" to "com.whatsapp.w4b",
            "telegram" to "org.telegram.messenger",
            "messenger" to "com.facebook.orca",
            "instagram" to "com.instagram.android",
            "messages" to "com.google.android.apps.messaging",
            "sms" to "com.google.android.apps.messaging",
            "signal" to "org.thoughtcrime.securesms",
            "discord" to "com.discord",
            "slack" to "com.Slack",
            "teams" to "com.microsoft.teams",
        )
        val mapped = knownPackages[key] ?: knownPackages.entries
            .firstOrNull { key.contains(it.key) || it.key.contains(key) }?.value

        if (mapped != null && pm.getLaunchIntentForPackage(mapped) != null) {
            return mapped
        }

        // Fall back to label lookup
        val match = pm.getInstalledApplications(0).firstOrNull { info ->
            val label = pm.getApplicationLabel(info).toString().lowercase(Locale.US)
            label == key || label.contains(key) || key.contains(label)
        }
        return match?.packageName
    }

    private fun launchApp(service: DiaAccessibilityService, packageName: String) {
        val ctx = service.applicationContext
        val intent = ctx.packageManager.getLaunchIntentForPackage(packageName) ?: return
        intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(intent)
    }

    private fun waitForActiveWindow(service: DiaAccessibilityService, pkg: String, timeoutMs: Long): Boolean {
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline) {
            val root = service.rootInActiveWindow
            if (root != null) {
                val current = root.packageName?.toString()
                if (current == pkg) return true
            }
            Thread.sleep(400)
        }
        return false
    }

    // ── Already-in-chat detection ──

    private fun isAlreadyInChatWith(service: DiaAccessibilityService, contact: String): Boolean {
        val root = service.rootInActiveWindow ?: return false
        val target = normalize(contact)
        val topNodes = mutableListOf<AccessibilityNodeInfo>()
        collectNodesInTopRegion(root, 350, topNodes)
        for (node in topNodes) {
            val combined = (node.text?.toString().orEmpty() + " " + node.contentDescription?.toString().orEmpty())
            if (containsContact(combined, target)) return true
        }
        return false
    }

    private fun collectNodesInTopRegion(node: AccessibilityNodeInfo, maxY: Int, out: MutableList<AccessibilityNodeInfo>) {
        val bounds = Rect().apply { node.getBoundsInScreen(this) }
        if (bounds.top in 0..maxY && (node.text != null || node.contentDescription != null)) {
            out.add(node)
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            collectNodesInTopRegion(child, maxY, out)
        }
    }

    // ── Contact navigation ──

    /**
     * Try, in order:
     *   1. Tap the search icon (content-desc "Search") if there's no
     *      visible search bar yet.
     *   2. Type the contact name into whatever EditText appears.
     *   3. Wait for results, tap the first chat-list ROW whose label
     *      matches the contact (NOT the search field itself).
     *   4. Verify the chat actually opened (toolbar shows contact name).
     */
    private fun findAndTapContact(service: DiaAccessibilityService, contact: String): Boolean {
        val target = normalize(contact)

        // Step 1: open search bar in chat list
        val root = service.rootInActiveWindow ?: return false
        val searchIcon = findClickableSearchIcon(root)
        if (searchIcon != null) {
            val r = Rect().apply { searchIcon.getBoundsInScreen(this) }
            service.performTap(r.centerX(), r.centerY())
            Thread.sleep(700)
        }

        // Step 2: type contact into the focused EditText (top of screen).
        // We track the search-field's bounds so step 3 can EXCLUDE it from
        // contact-row matches — otherwise the model thinks the search bar
        // (now containing "Lakshya") IS the chat row.
        var searchFieldBounds: Rect? = null
        val rootAfter = service.rootInActiveWindow ?: return false
        val searchEdit = findTopMostEditText(rootAfter)
        if (searchEdit != null) {
            searchFieldBounds = Rect().apply { searchEdit.getBoundsInScreen(this) }
            searchEdit.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            searchEdit.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            val args = Bundle().apply {
                putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, contact)
            }
            searchEdit.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
            // WhatsApp/Telegram filter results live; give them 1.5 s to repaint.
            Thread.sleep(1500)
        }

        // Step 3: tap the first matching contact ROW (excluding the search bar).
        for (attempt in 0 until 4) {
            val r = service.rootInActiveWindow ?: continue
            val match = findContactRow(r, target, searchFieldBounds)
            if (match != null) {
                tapNode(service, match)
                // Step 4: verify the chat opened — toolbar now shows the
                // contact name AND there's an EditText at the BOTTOM of the
                // screen (not the top, which is the search bar we just left).
                Thread.sleep(1500)
                if (verifyChatOpened(service, target)) {
                    return true
                }
                // Wrong tap — back out to retry.
                service.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK)
                Thread.sleep(500)
            }
            scrollDown(service)
            Thread.sleep(700)
        }
        return false
    }

    /**
     * After tapping a search result, confirm we are now in the chat:
     *   - The contact's name appears in the toolbar area (top 350 px), and
     *   - There's an EditText in the BOTTOM half of the screen (= composer).
     * If only the top EditText exists, we're still on the chat list.
     */
    private fun verifyChatOpened(service: DiaAccessibilityService, target: String): Boolean {
        val root = service.rootInActiveWindow ?: return false
        val dm = service.resources.displayMetrics
        val midY = dm.heightPixels / 2

        // (a) toolbar contains the contact name
        val toolbarHit = run {
            val topNodes = mutableListOf<AccessibilityNodeInfo>()
            collectNodesInTopRegion(root, 350, topNodes)
            topNodes.any { node ->
                containsContact(
                    (node.text?.toString().orEmpty() + " " + node.contentDescription?.toString().orEmpty()),
                    target,
                )
            }
        }
        if (!toolbarHit) return false

        // (b) bottom half has an EditText (the message composer)
        val edits = mutableListOf<AccessibilityNodeInfo>()
        collectEditTexts(root, edits)
        return edits.any { node ->
            val r = Rect()
            node.getBoundsInScreen(r)
            r.centerY() > midY
        }
    }

    private fun findClickableSearchIcon(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val all = mutableListOf<AccessibilityNodeInfo>()
        collectAll(root, all)
        return all.firstOrNull { node ->
            if (!node.isClickable) return@firstOrNull false
            val desc = node.contentDescription?.toString()?.lowercase(Locale.US).orEmpty()
            val text = node.text?.toString()?.lowercase(Locale.US).orEmpty()
            (desc.contains("search") || text.contains("search")) &&
                !desc.contains("voice") && !desc.contains("camera")
        }
    }

    private fun findTopMostEditText(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val edits = mutableListOf<AccessibilityNodeInfo>()
        collectEditTexts(root, edits)
        return edits.minByOrNull {
            val r = Rect(); it.getBoundsInScreen(r); r.centerY()
        }
    }

    private fun findContactRow(
        root: AccessibilityNodeInfo,
        target: String,
        excludeBounds: Rect?,
    ): AccessibilityNodeInfo? {
        val all = mutableListOf<AccessibilityNodeInfo>()
        collectAll(root, all)

        // Reject anything whose bounds overlap the search field — that's the
        // EditText we just typed into, not a real chat row.
        fun overlapsExcluded(node: AccessibilityNodeInfo): Boolean {
            if (excludeBounds == null) return false
            val r = Rect().apply { node.getBoundsInScreen(this) }
            return Rect.intersects(r, excludeBounds)
        }

        // Reject EditText themselves — chat rows are TextViews / FrameLayouts.
        fun isInputField(node: AccessibilityNodeInfo): Boolean {
            val cls = node.className?.toString().orEmpty()
            return node.isEditable || cls.contains("EditText", true) ||
                cls.contains("AutoComplete", true) || cls.contains("SearchView", true)
        }

        // Reject small square ImageViews — these are profile pictures that
        // open the contact's profile page instead of the chat.
        fun isProfilePicture(node: AccessibilityNodeInfo): Boolean {
            val cls = node.className?.toString().orEmpty()
            if (!cls.contains("Image", true) && !cls.contains("CircleImage", true) &&
                !cls.contains("ShapeableImage", true)) return false
            val r = Rect().apply { node.getBoundsInScreen(this) }
            // Profile pics are small squares (< 200px wide, aspect ~1:1).
            val w = r.width(); val h = r.height()
            if (w <= 0 || h <= 0) return false
            val aspect = w.toFloat() / h.toFloat()
            return w < 200 && aspect in 0.7f..1.4f
        }

        // Score each candidate by how well its label matches the target.
        // Exact match wins; "starts with" beats first-word; partial loses.
        // Wide nodes (chat rows) get a bonus over narrow ones (profile pics).
        data class Scored(val node: AccessibilityNodeInfo, val score: Int, val topY: Int)
        val scored = mutableListOf<Scored>()
        for (node in all) {
            if (overlapsExcluded(node) || isInputField(node) || isProfilePicture(node)) continue
            val label = (node.text?.toString().orEmpty() + " " +
                node.contentDescription?.toString().orEmpty())
            val score = matchScore(label, target, node)
            if (score > 0) {
                val r = Rect().apply { node.getBoundsInScreen(this) }
                scored.add(Scored(node, score, r.top))
            }
        }
        if (scored.isEmpty()) return null

        // Best score; tiebreak: topmost on screen (= first result).
        val winner = scored
            .sortedWith(compareByDescending<Scored> { it.score }.thenBy { it.topY })
            .first()
        // Prefer clickable rows — bubble up if needed.
        return if (winner.node.isClickable) winner.node
        else clickableAncestor(winner.node) ?: winner.node
    }

    /**
     * Scoring rubric:
     *   100 — full target appears as a whole-word match anywhere in the label.
     *   60  — every word of target appears in the label, in order, with gaps.
     *   30  — target's first word is a whole-word match (fallback only).
     *   0   — no match.
     *
     * BONUS: wide nodes (chat rows) get +10 over narrow ones (profile pics).
     * This prevents tapping the circular profile picture instead of the
     * chat-list row — both have the contact name, but the row is what
     * opens the chat.
     */
    private fun matchScore(label: String, target: String, node: AccessibilityNodeInfo? = null): Int {
        val l = normalize(label)
        val t = target
        if (l.isEmpty() || t.isEmpty()) return 0

        var base = 0

        // Whole-target match — highest priority.
        val tokenized = " ${l} "
        if (tokenized.contains(" $t ")) base = 100
        else if (l.contains(t)) base = 90
        else {
            // All target words appear in order.
            val tWords = t.split(' ').filter { it.length >= 2 }
            if (tWords.isNotEmpty()) {
                var idx = 0
                for (w in tWords) {
                    val found = l.indexOf(w, idx)
                    if (found < 0) { idx = -1; break }
                    idx = found + w.length
                }
                if (idx >= 0) base = 60
            }
            // Fallback: first word as whole-word match.
            if (base == 0) {
                val tWordsFallback = t.split(' ').filter { it.length >= 2 }
                val firstWord = tWordsFallback.firstOrNull() ?: t.substringBefore(' ')
                if (firstWord.length >= 3 && tokenized.contains(" $firstWord ")) base = 30
            }
        }

        if (base == 0) return 0

        // Width bonus: chat-list rows are typically > 60% of screen width.
        // Profile pictures are small squares (< 200px wide). Prefer wide.
        if (node != null) {
            val r = Rect()
            node.getBoundsInScreen(r)
            val width = r.width()
            val height = r.height()
            // A chat row is much wider than it is tall (aspect > 2:1).
            // A profile pic is roughly square (aspect ~1:1).
            if (width > 0 && height > 0) {
                val aspect = width.toFloat() / height.toFloat()
                if (aspect > 2.0f) base += 10  // wide row bonus
                if (aspect < 1.5f && width < 200) base -= 5  // small square penalty
            }
        }

        return base
    }

    private fun clickableAncestor(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        var cur = node?.parent
        var hops = 0
        while (cur != null && hops < 6) {
            if (cur.isClickable) return cur
            cur = cur.parent
            hops++
        }
        return null
    }

    private fun scrollDown(service: DiaAccessibilityService) {
        // Best-effort: most chat lists in WhatsApp/Telegram already filter
        // by search text, so usually we don't need to scroll. If we do,
        // we issue a synthetic vertical drag using the existing performTap
        // sequencing — kept lightweight to avoid pulling in the gesture
        // dispatch path. The search-bar narrow-down above is the primary
        // strategy and is what makes the contact lookup deterministic.
        val dm = service.resources.displayMetrics
        val midX = dm.widthPixels / 2
        val topY = (dm.heightPixels * 0.3f).toInt()
        try {
            service.performTap(midX, topY)
            Thread.sleep(120)
        } catch (_: Exception) {}
    }

    // ── Type into bottommost EditText ──

    private fun typeInBottomEditText(service: DiaAccessibilityService, message: String): Boolean {
        val root = service.rootInActiveWindow ?: return false
        val edits = mutableListOf<AccessibilityNodeInfo>()
        collectEditTexts(root, edits)
        if (edits.isEmpty()) return false

        // The composer ALWAYS lives in the bottom half of the screen. Reject
        // any EditText whose centerY is in the top half — that's the search
        // bar / address bar, never the message input.
        val dm = service.resources.displayMetrics
        val midY = dm.heightPixels / 2

        val bottomHalf = edits.filter {
            val r = Rect().apply { it.getBoundsInScreen(this) }
            r.centerY() > midY
        }
        // If everything is in the top half we're not in a chat — refuse so the
        // outer retry loop can try again instead of typing into a search bar.
        val pool = if (bottomHalf.isNotEmpty()) bottomHalf else return false

        val bottom = pool.maxByOrNull {
            val r = Rect(); it.getBoundsInScreen(r); r.centerY()
        } ?: return false

        bottom.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        bottom.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        Thread.sleep(400)

        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, message)
        }
        return bottom.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    // ── Tap Send / Enter ──

    private fun tapSendOrEnter(service: DiaAccessibilityService, expectedMessage: String): Boolean {
        val root = service.rootInActiveWindow ?: return false

        // Find any clickable node whose desc/text contains "send".
        val all = mutableListOf<AccessibilityNodeInfo>()
        collectAll(root, all)

        val sendBtn = all
            .filter { it.isClickable && looksLikeSend(it) }
            // Prefer ones near the bottom right (where Send always lives).
            .maxByOrNull {
                val r = Rect(); it.getBoundsInScreen(r)
                r.centerY() * 1000 + r.centerX()
            }

        if (sendBtn != null) {
            tapNode(service, sendBtn)
            Thread.sleep(500)
            if (composerIsEmpty(service, expectedMessage)) return true
        }

        // Fallback: Enter key via accessibility IME action.
        service.performImeEnter()
        Thread.sleep(400)
        return composerIsEmpty(service, expectedMessage)
    }

    private fun looksLikeSend(node: AccessibilityNodeInfo): Boolean {
        val desc = node.contentDescription?.toString()?.lowercase(Locale.US).orEmpty()
        val text = node.text?.toString()?.lowercase(Locale.US).orEmpty()
        // Match "send", "enviar", "envoyer", etc — the word "send" is enough
        // for English. Restrict to short labels so we don't match "send a
        // message to..." headings.
        if (desc.length > 30 && text.length > 30) return false
        return desc.contains("send") || text == "send" || text.startsWith("send ")
    }

    private fun composerIsEmpty(service: DiaAccessibilityService, expected: String): Boolean {
        val root = service.rootInActiveWindow ?: return true
        val edits = mutableListOf<AccessibilityNodeInfo>()
        collectEditTexts(root, edits)
        val bottom = edits.maxByOrNull {
            val r = Rect(); it.getBoundsInScreen(r); r.centerY()
        } ?: return true
        val current = bottom.text?.toString()?.trim().orEmpty()
        if (current.isEmpty()) return true
        // Some apps replace the typed text with hint after sending.
        return !current.equals(expected.trim(), ignoreCase = true) &&
            !current.contains(expected.trim(), ignoreCase = true)
    }

    // ── Helpers ──

    private fun collectAll(node: AccessibilityNodeInfo, out: MutableList<AccessibilityNodeInfo>) {
        out.add(node)
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            collectAll(child, out)
        }
    }

    private fun collectEditTexts(node: AccessibilityNodeInfo, out: MutableList<AccessibilityNodeInfo>) {
        val cls = node.className?.toString().orEmpty()
        if (node.isEditable || cls.contains("EditText", true) ||
            cls.contains("AutoComplete", true) || cls.contains("SearchView", true)) {
            val r = Rect().apply { node.getBoundsInScreen(this) }
            if (r.width() > 100 && r.height() > 20) out.add(node)
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            collectEditTexts(child, out)
        }
    }

    private fun tapNode(service: DiaAccessibilityService, node: AccessibilityNodeInfo) {
        // Prefer ACTION_CLICK; fall back to coordinate tap.
        val clicked = try { node.performAction(AccessibilityNodeInfo.ACTION_CLICK) } catch (_: Exception) { false }
        if (!clicked) {
            val r = Rect().apply { node.getBoundsInScreen(this) }
            if (r.width() > 0 && r.height() > 0) {
                service.performTap(r.centerX(), r.centerY())
            }
        }
    }

    private fun normalize(s: String): String =
        s.lowercase(Locale.US).replace(Regex("\\s+"), " ").trim()

    private fun containsContact(haystack: String, needle: String): Boolean {
        val h = normalize(haystack)
        val n = needle
        if (h == n) return true
        if (h.contains(n)) return true
        // All target words appear in order — handles "Lakshya … Rathi"
        // when there's other text between.
        val tWords = n.split(' ').filter { it.length >= 2 }
        if (tWords.isNotEmpty()) {
            var idx = 0
            for (w in tWords) {
                val found = h.indexOf(w, idx)
                if (found < 0) return false
                idx = found + w.length
            }
            return true
        }
        return false
    }
}
