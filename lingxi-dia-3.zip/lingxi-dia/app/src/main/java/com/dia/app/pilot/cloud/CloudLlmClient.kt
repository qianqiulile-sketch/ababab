package com.dia.app.pilot.cloud

import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Lightweight OpenAI-compatible chat client. Works with:
 *   • OpenAI:        https://api.openai.com/v1
 *   • OpenRouter:    https://openrouter.ai/api/v1   (Anthropic, Mistral, Llama)
 *   • Gemini:        https://generativelanguage.googleapis.com/v1beta/openai
 *   • Ollama:        http://<host>:11434/v1          (any local model)
 *   • LM Studio:     http://<host>:1234/v1
 *   • Anthropic via OpenRouter, etc.
 *
 * No external HTTP library — uses HttpURLConnection so we don't add new
 * dependencies before the deadline. Synchronous: caller is expected to be on
 * a worker thread (PilotAgent already runs on Dispatchers.IO).
 */
class CloudLlmClient(
    private val baseUrl: String,
    private val apiKey: String,
    private val model: String,
) {
    companion object {
        private const val TAG = "CloudLlmClient"
        private const val CONNECT_TIMEOUT_MS = 15_000
        private const val READ_TIMEOUT_MS = 60_000
    }

    data class ChatResult(
        val content: String?,
        val error: String? = null,
    )

    /**
     * One past turn in the conversation we keep replaying back to the cloud
     * LLM so it remembers what already happened. Keep these short — the
     * agent loop already includes the latest screen state in the user
     * message it sends each turn.
     */
    data class Message(
        val role: String,            // "user" | "assistant"
        val content: String,
    )

    /**
     * Send a chat request with system + user message. The user message can
     * contain text, screen tree, and optionally one PNG screenshot encoded
     * as base64 — the cloud model gets richer context than the local one.
     */
    fun chat(
        systemPrompt: String,
        userPrompt: String,
        screenshotPngBase64: String? = null,
        history: List<Message> = emptyList(),
        temperature: Double = 0.1,
        maxTokens: Int = 4096,
    ): ChatResult {
        return try {
            // Be tolerant of the user's base URL. Common shapes:
            //   https://api.openai.com/v1                  ← good
            //   https://api.openai.com                     ← we add /v1
            //   http://10.0.2.2:11434                      ← we add /v1 (Ollama openai-compat)
            //   http://10.0.2.2:11434/v1                   ← good
            //   http://10.0.2.2:11434/api                  ← Ollama NATIVE, we use /api/chat
            //   https://openrouter.ai/api/v1               ← good
            //   https://generativelanguage.googleapis.com/v1beta/openai ← good (Gemini)
            val (endpoint, useOllamaNative) = resolveEndpoint(baseUrl)
            val conn = (endpoint.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = CONNECT_TIMEOUT_MS
                readTimeout = READ_TIMEOUT_MS
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                if (apiKey.isNotBlank()) {
                    setRequestProperty("Authorization", "Bearer $apiKey")
                }
                // OpenRouter requires a Referer / X-Title for routing.
                setRequestProperty("HTTP-Referer", "https://dia.app")
                setRequestProperty("X-Title", "Dia · Pilot")
            }

            val body = if (useOllamaNative) {
                buildOllamaBody(systemPrompt, userPrompt, screenshotPngBase64, history, temperature)
            } else {
                buildBody(systemPrompt, userPrompt, screenshotPngBase64, history, temperature, maxTokens)
            }
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val response = stream?.bufferedReader()?.use { it.readText() }.orEmpty()

            if (code !in 200..299) {
                Log.w(TAG, "HTTP $code @ $endpoint: ${response.take(500)}")
                val helpful = if (code == 404) {
                    "HTTP 404 — endpoint not found at $endpoint. " +
                        "• Ollama Cloud: https://ollama.com  " +
                        "• OpenAI: https://api.openai.com/v1  " +
                        "• OpenRouter: https://openrouter.ai/api/v1  " +
                        "• Gemini openai-compat: https://generativelanguage.googleapis.com/v1beta/openai  " +
                        "Server message: ${shortenError(response)}"
                } else if (code == 401 || code == 403) {
                    "HTTP $code — unauthorized. Check your API key. ${shortenError(response)}"
                } else {
                    "HTTP $code — ${shortenError(response)}"
                }
                return ChatResult(null, helpful)
            }

            val content = if (useOllamaNative) parseOllamaContent(response)
            else parseContent(response)
            if (content.isNullOrBlank()) {
                return ChatResult(null, "Empty response from cloud model")
            }
            ChatResult(content)
        } catch (e: javax.net.ssl.SSLHandshakeException) {
            ChatResult(null, "TLS error talking to ${shortBase()}: ${e.message}")
        } catch (e: java.net.UnknownHostException) {
            ChatResult(null, "Cannot reach ${shortBase()}. Check network and base URL.")
        } catch (e: java.net.SocketTimeoutException) {
            ChatResult(null, "Cloud request timed out (${READ_TIMEOUT_MS / 1000}s).")
        } catch (e: Exception) {
            Log.e(TAG, "Cloud request failed", e)
            ChatResult(null, e.message ?: e.javaClass.simpleName)
        }
    }

    /**
     * Returns (endpoint, useOllamaNative). Normalises the user's base URL
     * so the most common typo ("forgot the /v1") still works.
     *
     * For ollama.com cloud: use /v1/chat/completions (OpenAI-compat) because
     * it supports the standard image_url format for vision models. The native
     * /api/chat also works but the OpenAI-compat path is more consistent
     * with other providers.
     */
    private fun resolveEndpoint(rawBase: String): Pair<URL, Boolean> {
        val cleaned = rawBase.trim().trimEnd('/')

        // User explicitly wants Ollama's native /api endpoint (local only)
        if (cleaned.endsWith("/api")) {
            return URL("$cleaned/chat") to true
        }

        // Ollama Cloud or any host with /v1 → OpenAI-compat (supports images)
        if (cleaned.contains("ollama.com", ignoreCase = true)) {
            // ollama.com supports /v1/chat/completions with vision
            val host = cleaned.substringBefore("/api").substringBefore("/v1").trimEnd('/')
            return URL("$host/v1/chat/completions") to false
        }

        // OpenAI-compat path already present
        if (cleaned.endsWith("/v1") || cleaned.contains("/v1/") ||
            cleaned.endsWith("openai") /* gemini openai-compat */) {
            return URL("$cleaned/chat/completions") to false
        }

        // Bare host (e.g. http://10.0.2.2:11434, https://api.openai.com)
        // Default to OpenAI-compat under /v1.
        return URL("$cleaned/v1/chat/completions") to false
    }

    /**
     * Build a request body for Ollama's NATIVE /api/chat endpoint.
     * Images go in the message's "images" array as raw base64 strings
     * (no data URI prefix). See: https://github.com/ollama/ollama/blob/main/docs/api.md#chat
     */
    private fun buildOllamaBody(
        systemPrompt: String,
        userPrompt: String,
        screenshotPngBase64: String?,
        history: List<Message>,
        temperature: Double,
    ): JSONObject {
        val messages = JSONArray()
        messages.put(JSONObject().put("role", "system").put("content", systemPrompt))
        for (m in history) {
            messages.put(JSONObject().put("role", m.role).put("content", m.content))
        }
        // User message — with optional image in Ollama's native format.
        val userMsg = JSONObject().put("role", "user").put("content", userPrompt)
        if (!screenshotPngBase64.isNullOrBlank()) {
            Log.d(TAG, "Ollama native: attaching image (${screenshotPngBase64.length} chars base64)")
            userMsg.put("images", JSONArray().put(screenshotPngBase64))
        } else {
            Log.d(TAG, "Ollama native: text-only (no image)")
        }
        messages.put(userMsg)

        return JSONObject()
            .put("model", model)
            .put("messages", messages)
            .put("stream", false)
            .put("options", JSONObject().put("temperature", temperature))
    }

    private fun parseOllamaContent(json: String): String? {
        return try {
            val root = JSONObject(json)
            root.optJSONObject("message")?.optString("content")
        } catch (_: Exception) { null }
    }

    private fun buildBody(
        systemPrompt: String,
        userPrompt: String,
        screenshotPngBase64: String?,
        history: List<Message>,
        temperature: Double,
        maxTokens: Int,
    ): JSONObject {
        val messages = JSONArray()

        // System message
        messages.put(
            JSONObject()
                .put("role", "system")
                .put("content", systemPrompt)
        )

        // Past turns — model remembers what it already did.
        for (m in history) {
            messages.put(
                JSONObject()
                    .put("role", m.role)
                    .put("content", m.content)
            )
        }

        // Current user message — text-only OR text + image.
        if (screenshotPngBase64.isNullOrBlank()) {
            Log.d(TAG, "Cloud request: text-only (no image)")
            messages.put(
                JSONObject()
                    .put("role", "user")
                    .put("content", userPrompt)
            )
        } else {
            Log.d(TAG, "Cloud request: text + image (${screenshotPngBase64.length} chars base64)")
            val parts = JSONArray()
            parts.put(JSONObject().put("type", "text").put("text", userPrompt))
            parts.put(
                JSONObject()
                    .put("type", "image_url")
                    .put(
                        "image_url",
                        JSONObject().put(
                            "url",
                            "data:image/png;base64,$screenshotPngBase64"
                        )
                    )
            )
            messages.put(
                JSONObject()
                    .put("role", "user")
                    .put("content", parts)
            )
        }

        return JSONObject()
            .put("model", model)
            .put("messages", messages)
            .put("temperature", temperature)
            .put("max_tokens", maxTokens)
            .put("stream", false)
    }

    private fun parseContent(json: String): String? {
        return try {
            val root = JSONObject(json)
            val choices = root.optJSONArray("choices") ?: return null
            if (choices.length() == 0) return null
            val first = choices.getJSONObject(0)
            val message = first.optJSONObject("message") ?: return null
            // Standard OpenAI shape — content can be a string OR an array of
            // parts (Gemini's openai-compat returns parts on rare occasions).
            when (val c = message.opt("content")) {
                is String -> c
                is JSONArray -> {
                    val sb = StringBuilder()
                    for (i in 0 until c.length()) {
                        val part = c.optJSONObject(i) ?: continue
                        sb.append(part.optString("text"))
                    }
                    sb.toString()
                }
                else -> null
            }
        } catch (e: Exception) {
            Log.w(TAG, "Bad cloud JSON", e)
            null
        }
    }

    private fun shortBase(): String =
        try { URL(baseUrl).host } catch (_: Exception) { baseUrl }

    private fun shortenError(body: String): String {
        return try {
            val obj = JSONObject(body)
            val err = obj.optJSONObject("error")
                ?: return body.take(200)
            err.optString("message").ifEmpty { body.take(200) }
        } catch (_: Exception) {
            body.take(200)
        }
    }
}
