package com.dia.app.prefs

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.compositionLocalOf
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Application-scoped user preferences. All reads/writes go through here so
 * the values are observable from Compose via StateFlow.
 *
 * Persisted to SharedPreferences so settings survive app restarts.
 */
object DiaPrefs {
    private const val PREFS_NAME = "dia_prefs"
    private const val KEY_BIG_TEXT = "big_text_enabled"
    private const val KEY_HIGH_CONTRAST = "high_contrast_enabled"
    private const val KEY_SLOW_VOICE = "slow_voice_enabled"
    private const val KEY_REDUCE_MOTION = "reduce_motion_enabled"

    // Cloud LLM (Pilot router) — OpenAI-compatible endpoint config.
    private const val KEY_CLOUD_ENABLED = "cloud_pilot_enabled"
    private const val KEY_CLOUD_BASE_URL = "cloud_pilot_base_url"
    private const val KEY_CLOUD_API_KEY = "cloud_pilot_api_key"
    private const val KEY_CLOUD_MODEL = "cloud_pilot_model"
    private const val KEY_CLOUD_AUTOROUTE = "cloud_pilot_autoroute"

    // Chat behaviour.
    private const val KEY_AUTO_LOAD_MODEL = "auto_load_model"
    private const val KEY_AUTO_SPEAK = "auto_speak_responses"
    private const val KEY_THINKING_DEFAULT = "thinking_default"
    private const val KEY_CHAT_FONT_SCALE = "chat_font_scale"

    // Accessibility: auto-listen on Pilot/Guide open.
    private const val KEY_AUTO_LISTEN = "auto_listen_on_open"
    // Accessibility: spoken Pilot status updates via TTS.
    private const val KEY_PILOT_SPEAK = "pilot_speak_status"

    // Home Assistant config
    private const val KEY_HA_BASE_URL = "ha_base_url"
    private const val KEY_HA_TOKEN = "ha_token"
    private const val KEY_HOME_WAKE_WORD = "home_wake_word_enabled"

    // First-launch tour walkthrough
    private const val KEY_TOUR_COMPLETED = "tour_completed"
    private const val KEY_LAUNCH_COUNT = "launch_count"

    private lateinit var prefs: SharedPreferences

    private val _bigText = MutableStateFlow(false)
    val bigText: StateFlow<Boolean> = _bigText.asStateFlow()

    private val _highContrast = MutableStateFlow(false)
    val highContrast: StateFlow<Boolean> = _highContrast.asStateFlow()

    private val _slowVoice = MutableStateFlow(false)
    val slowVoice: StateFlow<Boolean> = _slowVoice.asStateFlow()

    private val _reduceMotion = MutableStateFlow(false)
    val reduceMotion: StateFlow<Boolean> = _reduceMotion.asStateFlow()

    private val _cloudEnabled = MutableStateFlow(false)
    val cloudEnabled: StateFlow<Boolean> = _cloudEnabled.asStateFlow()

    private val _cloudBaseUrl = MutableStateFlow("")
    val cloudBaseUrl: StateFlow<String> = _cloudBaseUrl.asStateFlow()

    private val _cloudApiKey = MutableStateFlow("")
    val cloudApiKey: StateFlow<String> = _cloudApiKey.asStateFlow()

    private val _cloudModel = MutableStateFlow("")
    val cloudModel: StateFlow<String> = _cloudModel.asStateFlow()

    /**
     * When true, Pilot decides per-task whether to run on cloud or local
     * based on TaskRouter heuristics. When false, every task uses local.
     */
    private val _cloudAutoRoute = MutableStateFlow(true)
    val cloudAutoRoute: StateFlow<Boolean> = _cloudAutoRoute.asStateFlow()

    /**
     * When true, Dia auto-initializes the last-used local model when a mode
     * (chat / lens / pilot / …) is opened. Default ON: with [ModelManager]
     * serializing loads, autoloading is safe everywhere and the chat panel
     * shows a graceful spinner over itself while the engine warms up. Users
     * can toggle this off in Settings if they prefer to pick each time.
     */
    private val _autoLoadModel = MutableStateFlow(true)
    val autoLoadModel: StateFlow<Boolean> = _autoLoadModel.asStateFlow()

    /** Speak every assistant response out loud automatically. */
    private val _autoSpeak = MutableStateFlow(false)
    val autoSpeak: StateFlow<Boolean> = _autoSpeak.asStateFlow()

    /** Default thinking-mode state for new chats (Gemma 4). */
    private val _thinkingDefault = MutableStateFlow(false)
    val thinkingDefault: StateFlow<Boolean> = _thinkingDefault.asStateFlow()

    /** Chat font scale: 0.85 (small), 1.0 (default), 1.2 (large). */
    private val _chatFontScale = MutableStateFlow(1.0f)
    val chatFontScale: StateFlow<Float> = _chatFontScale.asStateFlow()

    /** Auto-start voice input when opening Pilot or Guide. */
    private val _autoListen = MutableStateFlow(false)
    val autoListen: StateFlow<Boolean> = _autoListen.asStateFlow()

    /** Speak Pilot tool status updates via TTS for blind/low-vision users. */
    private val _pilotSpeak = MutableStateFlow(false)
    val pilotSpeak: StateFlow<Boolean> = _pilotSpeak.asStateFlow()

    private val _haBaseUrl = MutableStateFlow("")
    val haBaseUrl: StateFlow<String> = _haBaseUrl.asStateFlow()

    private val _haToken = MutableStateFlow("")
    val haToken: StateFlow<String> = _haToken.asStateFlow()

    private val _homeWakeWord = MutableStateFlow(false)
    val homeWakeWord: StateFlow<Boolean> = _homeWakeWord.asStateFlow()

    /** True once the user has finished (or skipped) the first-launch tour. */
    private val _tourCompleted = MutableStateFlow(false)
    val tourCompleted: StateFlow<Boolean> = _tourCompleted.asStateFlow()

    /** How many times the app has been launched. Used to gate the tour to first run. */
    private val _launchCount = MutableStateFlow(0)
    val launchCount: StateFlow<Int> = _launchCount.asStateFlow()

    fun init(context: Context) {
        if (this::prefs.isInitialized) return
        prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        _bigText.value = prefs.getBoolean(KEY_BIG_TEXT, false)
        _highContrast.value = prefs.getBoolean(KEY_HIGH_CONTRAST, false)
        _slowVoice.value = prefs.getBoolean(KEY_SLOW_VOICE, false)
        _reduceMotion.value = prefs.getBoolean(KEY_REDUCE_MOTION, false)
        _cloudEnabled.value = prefs.getBoolean(KEY_CLOUD_ENABLED, false)
        _cloudBaseUrl.value = prefs.getString(KEY_CLOUD_BASE_URL, "").orEmpty()
        _cloudApiKey.value = prefs.getString(KEY_CLOUD_API_KEY, "").orEmpty()
        _cloudModel.value = prefs.getString(KEY_CLOUD_MODEL, "").orEmpty()
        _cloudAutoRoute.value = prefs.getBoolean(KEY_CLOUD_AUTOROUTE, true)
        _autoLoadModel.value = prefs.getBoolean(KEY_AUTO_LOAD_MODEL, true)
        _autoSpeak.value = prefs.getBoolean(KEY_AUTO_SPEAK, false)
        _thinkingDefault.value = prefs.getBoolean(KEY_THINKING_DEFAULT, false)
        _chatFontScale.value = prefs.getFloat(KEY_CHAT_FONT_SCALE, 1.0f)
        _autoListen.value = prefs.getBoolean(KEY_AUTO_LISTEN, false)
        _pilotSpeak.value = prefs.getBoolean(KEY_PILOT_SPEAK, false)
        _haBaseUrl.value = prefs.getString(KEY_HA_BASE_URL, "").orEmpty()
        _haToken.value = prefs.getString(KEY_HA_TOKEN, "").orEmpty()
        _homeWakeWord.value = prefs.getBoolean(KEY_HOME_WAKE_WORD, false)
        _tourCompleted.value = prefs.getBoolean(KEY_TOUR_COMPLETED, false)
        // Bump launch count on every init() so HomeScreen / DiaApp can decide
        // whether to surface the tour again on a future launch if needed.
        val nextCount = prefs.getInt(KEY_LAUNCH_COUNT, 0) + 1
        prefs.edit().putInt(KEY_LAUNCH_COUNT, nextCount).apply()
        _launchCount.value = nextCount
    }

    fun setBigText(enabled: Boolean) {
        if (!this::prefs.isInitialized) return
        prefs.edit().putBoolean(KEY_BIG_TEXT, enabled).apply()
        _bigText.value = enabled
    }

    fun setHighContrast(enabled: Boolean) {
        if (!this::prefs.isInitialized) return
        prefs.edit().putBoolean(KEY_HIGH_CONTRAST, enabled).apply()
        _highContrast.value = enabled
    }

    fun setSlowVoice(enabled: Boolean) {
        if (!this::prefs.isInitialized) return
        prefs.edit().putBoolean(KEY_SLOW_VOICE, enabled).apply()
        _slowVoice.value = enabled
    }

    fun setReduceMotion(enabled: Boolean) {
        if (!this::prefs.isInitialized) return
        prefs.edit().putBoolean(KEY_REDUCE_MOTION, enabled).apply()
        _reduceMotion.value = enabled
    }

    fun setCloudEnabled(enabled: Boolean) {
        if (!this::prefs.isInitialized) return
        prefs.edit().putBoolean(KEY_CLOUD_ENABLED, enabled).apply()
        _cloudEnabled.value = enabled
    }

    fun setCloudBaseUrl(url: String) {
        if (!this::prefs.isInitialized) return
        val cleaned = url.trim().trimEnd('/')
        prefs.edit().putString(KEY_CLOUD_BASE_URL, cleaned).apply()
        _cloudBaseUrl.value = cleaned
    }

    fun setCloudApiKey(key: String) {
        if (!this::prefs.isInitialized) return
        prefs.edit().putString(KEY_CLOUD_API_KEY, key.trim()).apply()
        _cloudApiKey.value = key.trim()
    }

    fun setCloudModel(model: String) {
        if (!this::prefs.isInitialized) return
        prefs.edit().putString(KEY_CLOUD_MODEL, model.trim()).apply()
        _cloudModel.value = model.trim()
    }

    fun setCloudAutoRoute(enabled: Boolean) {
        if (!this::prefs.isInitialized) return
        prefs.edit().putBoolean(KEY_CLOUD_AUTOROUTE, enabled).apply()
        _cloudAutoRoute.value = enabled
    }

    fun setAutoLoadModel(enabled: Boolean) {
        if (!this::prefs.isInitialized) return
        prefs.edit().putBoolean(KEY_AUTO_LOAD_MODEL, enabled).apply()
        _autoLoadModel.value = enabled
    }

    fun setAutoSpeak(enabled: Boolean) {
        if (!this::prefs.isInitialized) return
        prefs.edit().putBoolean(KEY_AUTO_SPEAK, enabled).apply()
        _autoSpeak.value = enabled
    }

    fun setThinkingDefault(enabled: Boolean) {
        if (!this::prefs.isInitialized) return
        prefs.edit().putBoolean(KEY_THINKING_DEFAULT, enabled).apply()
        _thinkingDefault.value = enabled
    }

    /** Clamp to [0.7 .. 1.4] to avoid runaway scaling. */
    fun setChatFontScale(scale: Float) {
        if (!this::prefs.isInitialized) return
        val clamped = scale.coerceIn(0.7f, 1.4f)
        prefs.edit().putFloat(KEY_CHAT_FONT_SCALE, clamped).apply()
        _chatFontScale.value = clamped
    }

    fun setAutoListen(enabled: Boolean) {
        if (!this::prefs.isInitialized) return
        prefs.edit().putBoolean(KEY_AUTO_LISTEN, enabled).apply()
        _autoListen.value = enabled
    }

    fun setPilotSpeak(enabled: Boolean) {
        if (!this::prefs.isInitialized) return
        prefs.edit().putBoolean(KEY_PILOT_SPEAK, enabled).apply()
        _pilotSpeak.value = enabled
    }

    fun setHaBaseUrl(url: String) {
        if (!this::prefs.isInitialized) return
        val cleaned = url.trim().trimEnd('/')
        prefs.edit().putString(KEY_HA_BASE_URL, cleaned).apply()
        _haBaseUrl.value = cleaned
    }

    fun setHaToken(token: String) {
        if (!this::prefs.isInitialized) return
        prefs.edit().putString(KEY_HA_TOKEN, token.trim()).apply()
        _haToken.value = token.trim()
    }

    fun setHomeWakeWord(enabled: Boolean) {
        if (!this::prefs.isInitialized) return
        prefs.edit().putBoolean(KEY_HOME_WAKE_WORD, enabled).apply()
        _homeWakeWord.value = enabled
    }

    fun setTourCompleted(completed: Boolean) {
        if (!this::prefs.isInitialized) return
        prefs.edit().putBoolean(KEY_TOUR_COMPLETED, completed).apply()
        _tourCompleted.value = completed
    }

    /** True if cloud is enabled AND has the minimum config to make a request. */
    fun cloudIsConfigured(): Boolean {
        return _cloudEnabled.value &&
            _cloudBaseUrl.value.isNotBlank() &&
            _cloudModel.value.isNotBlank()
    }
}

/** Convenience holder so any composable can react to accessibility prefs. */
data class AccessibilityPrefs(
    val bigText: Boolean = false,
    val highContrast: Boolean = false,
) {
    /** Multiplier applied to font sizes / icon sizes when big text is on. */
    val textScale: Float get() = if (bigText) 1.4f else 1.0f
    /** Extra weight added to icon strokes / borders for visibility. */
    val contrastBoost: Float get() = if (highContrast) 1.0f else 0.0f
}

val LocalAccessibility = compositionLocalOf { AccessibilityPrefs() }
