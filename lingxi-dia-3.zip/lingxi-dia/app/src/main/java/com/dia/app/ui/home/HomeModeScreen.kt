package com.dia.app.ui.home

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.Air
import androidx.compose.material.icons.rounded.Devices
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.LightMode
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MicOff
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Thermostat
import androidx.compose.material.icons.rounded.ToggleOn
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dia.app.home.HaClient
import com.dia.app.home.HomeModeEngine
import com.dia.app.prefs.DiaPrefs
import com.dia.app.ui.theme.DiaBackground
import com.dia.app.ui.theme.DiaSurface
import com.dia.app.ui.theme.DiaTextPrimary
import com.dia.app.ui.theme.DiaTextSecondary
import com.dia.app.ui.theme.DiaTextTertiary

/**
 * Home Mode = Dia's voice room. Big Alexa-style listening orb in the
 * middle, smart-home tiles below. Wake-word loop is optional and the
 * mic button is always available for tap-to-talk.
 */
@Composable
fun HomeModeScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val state by HomeModeEngine.state.collectAsState()
    val lastCmd by HomeModeEngine.lastCommand.collectAsState()
    val lastResp by HomeModeEngine.lastResponse.collectAsState()
    val connected by HomeModeEngine.connected.collectAsState()
    val entities by HomeModeEngine.entities.collectAsState()
    val wakeWordEnabled by DiaPrefs.homeWakeWord.collectAsState()
    var inputText by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        HomeModeEngine.attach(context)
        HomeModeEngine.start()
    }
    DisposableEffect(Unit) { onDispose { HomeModeEngine.stop() } }

    val accent = when (state) {
        HomeModeEngine.State.LISTENING -> Color(0xFF4ADE80)
        HomeModeEngine.State.THINKING -> Color(0xFF29B6F6)
        HomeModeEngine.State.SPEAKING -> Color(0xFFFFB74D)
        HomeModeEngine.State.ERROR -> Color(0xFFEF5350)
        HomeModeEngine.State.IDLE -> Color(0xFF7B61FF)
    }
    val stateLabel = when (state) {
        HomeModeEngine.State.IDLE -> if (wakeWordEnabled) "说「Hey Dia」" else "点击麦克风"
        HomeModeEngine.State.LISTENING -> "聆听中\u2026"
        HomeModeEngine.State.THINKING -> "思考中\u2026"
        HomeModeEngine.State.SPEAKING -> "播报中\u2026"
        HomeModeEngine.State.ERROR -> "请重试"
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DiaBackground)
            .windowInsetsPadding(WindowInsets.statusBars)
            .windowInsetsPadding(WindowInsets.navigationBars)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        // ── Header ──
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, "返回", tint = DiaTextSecondary)
            }
            Spacer(Modifier.width(6.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text("家居", style = MaterialTheme.typography.titleLarge, color = DiaTextPrimary)
                Text(
                    "语音 + 智能家居",
                    style = MaterialTheme.typography.bodySmall,
                    color = DiaTextSecondary,
                )
            }
            // Connection indicator
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .clip(CircleShape)
                    .background(if (connected) Color(0xFF4ADE80) else DiaTextTertiary)
            )
            Spacer(Modifier.width(6.dp))
            Text(
                if (connected) "HA 在线" else "HA 离线",
                color = if (connected) Color(0xFF4ADE80) else DiaTextTertiary,
                style = MaterialTheme.typography.labelSmall,
            )
            IconButton(onClick = { HomeModeEngine.refresh() }) {
                Icon(
                    Icons.Rounded.Refresh,
                    "刷新",
                    tint = DiaTextSecondary,
                    modifier = Modifier.size(18.dp),
                )
            }
        }

        // ── Big voice orb ──
        VoiceOrb(
            accent = accent,
            state = state,
            wakeWordEnabled = wakeWordEnabled,
            onMicTap = { HomeModeEngine.triggerListen() },
        )

        Text(
            stateLabel,
            color = accent,
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth(),
        )

        // ── Wake word toggle ──
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(DiaSurface)
                .border(1.dp, Color.White.copy(alpha = 0.06f), RoundedCornerShape(14.dp))
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                Icons.Rounded.GraphicEq,
                null,
                tint = if (wakeWordEnabled) accent else DiaTextSecondary,
                modifier = Modifier.size(20.dp),
            )
            Spacer(Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    "唤醒词",
                    color = DiaTextPrimary,
                    style = MaterialTheme.typography.titleSmall,
                )
                Text(
                    "持续监听唤醒词「Hey Dia」",
                    color = DiaTextSecondary,
                    style = MaterialTheme.typography.labelSmall,
                )
            }
            Switch(
                checked = wakeWordEnabled,
                onCheckedChange = {
                    DiaPrefs.setHomeWakeWord(it)
                    if (it) HomeModeEngine.startWakeWord() else HomeModeEngine.stopWakeWord()
                },
                colors = SwitchDefaults.colors(
                    checkedThumbColor = accent,
                    checkedTrackColor = accent.copy(alpha = 0.35f),
                ),
            )
        }

        // ── Last interaction transcript ──
        if (lastCmd.isNotBlank() || lastResp.isNotBlank()) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(DiaSurface)
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                if (lastCmd.isNotBlank()) {
                    Text("你", color = DiaTextTertiary, style = MaterialTheme.typography.labelSmall)
                    Text(lastCmd, color = DiaTextPrimary, style = MaterialTheme.typography.bodyMedium)
                }
                if (lastResp.isNotBlank()) {
                    Text("灵犀", color = DiaTextTertiary, style = MaterialTheme.typography.labelSmall)
                    Text(
                        lastResp,
                        color = accent,
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }
            }
        }

        // ── Devices ──
        Text(
            "设备",
            color = DiaTextSecondary,
            style = MaterialTheme.typography.labelMedium.copy(letterSpacing = 1.sp, fontWeight = FontWeight.Bold),
        )
        if (entities.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 80.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(DiaSurface)
                    .border(1.dp, Color.White.copy(alpha = 0.06f), RoundedCornerShape(14.dp))
                    .padding(16.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    if (connected) "未找到可控制的设备"
                    else "请在「设置 → Home Assistant」中连接 Home Assistant",
                    color = DiaTextTertiary,
                    style = MaterialTheme.typography.bodySmall,
                    textAlign = TextAlign.Center,
                )
            }
        } else {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                items(entities, key = { it.entityId }) { entity ->
                    EntityCard(entity, accent) {
                        HomeModeEngine.processCommand(
                            "Turn ${if (entity.state == "on") "off" else "on"} ${entity.friendlyName}"
                        )
                    }
                }
            }
        }

        Spacer(Modifier.weight(1f))

        // ── Type fallback ──
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(DiaSurface)
                .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(24.dp))
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            BasicTextField(
                value = inputText,
                onValueChange = { inputText = it },
                textStyle = TextStyle(color = DiaTextPrimary, fontSize = 15.sp),
                cursorBrush = SolidColor(accent),
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 8.dp),
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = {
                    if (inputText.isNotBlank()) {
                        HomeModeEngine.processCommand(inputText.trim())
                        inputText = ""
                    }
                }),
                decorationBox = { inner ->
                    if (inputText.isEmpty()) {
                        Text("输入指令\u2026", color = DiaTextTertiary, fontSize = 15.sp)
                    }
                    inner()
                },
            )
            IconButton(
                onClick = {
                    if (inputText.isNotBlank()) {
                        HomeModeEngine.processCommand(inputText.trim())
                        inputText = ""
                    }
                },
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(accent),
            ) {
                Icon(
                    Icons.AutoMirrored.Rounded.Send,
                    "发送",
                    tint = Color.Black,
                    modifier = Modifier.size(18.dp),
                )
            }
        }
    }
}

@Composable
private fun VoiceOrb(
    accent: Color,
    state: HomeModeEngine.State,
    wakeWordEnabled: Boolean,
    onMicTap: () -> Unit,
) {
    val infiniteTransition = rememberInfiniteTransition(label = "orb")
    val pulse by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "pulse",
    )
    val ringAlpha by animateFloatAsState(
        targetValue = when (state) {
            HomeModeEngine.State.LISTENING -> 0.55f
            HomeModeEngine.State.THINKING -> 0.45f
            HomeModeEngine.State.SPEAKING -> 0.6f
            HomeModeEngine.State.ERROR -> 0.4f
            HomeModeEngine.State.IDLE -> if (wakeWordEnabled) 0.25f else 0.15f
        },
        animationSpec = tween(500),
        label = "ringAlpha",
    )
    val active = state == HomeModeEngine.State.LISTENING

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 220.dp),
        contentAlignment = Alignment.Center,
    ) {
        // Outer ring
        Canvas(modifier = Modifier.size(220.dp)) {
            val r = size.minDimension / 2f
            drawCircle(
                color = accent.copy(alpha = ringAlpha * 0.3f * pulse),
                radius = r * 0.9f,
                style = Stroke(width = 1.5f),
            )
            drawCircle(
                color = accent.copy(alpha = ringAlpha * 0.5f * pulse),
                radius = r * 0.74f,
                style = Stroke(width = 1.5f),
            )
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        accent.copy(alpha = ringAlpha * 0.45f),
                        accent.copy(alpha = 0f),
                    ),
                    center = Offset(size.width / 2f, size.height / 2f),
                    radius = r * 1.1f,
                ),
                radius = r * 1.1f,
            )
        }

        // Mic core
        val coreScale = if (active) pulse else 1f
        Box(
            modifier = Modifier
                .size(108.dp)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            accent.copy(alpha = if (active) 0.95f else 0.75f),
                            accent.copy(alpha = if (active) 0.55f else 0.35f),
                        ),
                    )
                )
                .clickable(onClick = onMicTap),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                imageVector = if (active) Icons.Rounded.Mic else if (state == HomeModeEngine.State.IDLE && wakeWordEnabled) Icons.Rounded.GraphicEq else Icons.Rounded.Mic,
                contentDescription = "说话",
                tint = Color.Black.copy(alpha = 0.8f),
                modifier = Modifier.size((46 * coreScale).dp),
            )
        }
    }
}

@Composable
private fun EntityCard(entity: HaClient.HaEntity, accent: Color, onTap: () -> Unit) {
    val isOn = entity.state == "on"
    val icon = when (entity.domain) {
        "light" -> Icons.Rounded.LightMode
        "switch" -> Icons.Rounded.ToggleOn
        "fan" -> Icons.Rounded.Air
        "lock" -> Icons.Rounded.Lock
        "climate" -> Icons.Rounded.Thermostat
        "media_player" -> Icons.Rounded.MusicNote
        else -> Icons.Rounded.Devices
    }
    val tileAccent = if (isOn) accent else DiaTextSecondary
    Column(
        modifier = Modifier
            .width(116.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(if (isOn) accent.copy(alpha = 0.10f) else DiaSurface)
            .border(
                1.dp,
                if (isOn) accent.copy(alpha = 0.35f) else Color.White.copy(alpha = 0.06f),
                RoundedCornerShape(16.dp),
            )
            .clickable(onClick = onTap)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Icon(icon, null, tint = tileAccent, modifier = Modifier.size(22.dp))
        Text(
            entity.friendlyName,
            color = DiaTextPrimary,
            style = MaterialTheme.typography.titleSmall,
            maxLines = 1,
        )
        Text(
            entity.state,
            color = tileAccent,
            style = MaterialTheme.typography.labelSmall,
            maxLines = 1,
        )
    }
}
