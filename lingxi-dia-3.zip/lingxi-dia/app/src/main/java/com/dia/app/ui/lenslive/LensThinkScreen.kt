package com.dia.app.ui.lenslive

import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.VolumeOff
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Calculate
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Lightbulb
import androidx.compose.material.icons.rounded.Sensors
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.dia.app.llm.BackendRouter
import com.dia.app.llm.DiaEngine
import com.dia.app.ui.theme.DiaLensListening
import com.dia.app.ui.theme.DiaLensProcessing
import com.dia.app.ui.theme.DiaLensSpeaking
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.sqrt

private const val TAG = "LensThinkScreen"
private const val STILL_THRESHOLD = 0.4f
private const val STILL_DURATION_MS = 2200L
private const val IDLE_LOOP_DELAY_MS = 4500L

/**
 * Three operating modes for the Think tab. Each maps to a distinct prompt
 * pair (system + user) and a different colour. The user picks one with the
 * mode chips at the bottom; the auto-still trigger reuses the last picked
 * mode so "hold the phone still over a quiz" actually answers the quiz
 * instead of describing it.
 */
/**
 * The three Think modes — Describe / Answer / Solve. Each has terse vs
 * deep prompts (chosen by the thinking toggle) so OFF = just-the-answer,
 * ON = answer + brief reasoning. Mode-specific so users can lean on the
 * right one for the content in front of them.
 */
private enum class ThinkMode2(
    val label: String,
    val accent: Color,
    val emoji: String,
    val tersePrompt: String,
    val deepPrompt: String,
    val terseUserPrompt: String,
    val deepUserPrompt: String,
) {
    DESCRIBE(
        label = "描述",
        accent = Color(0xFF9C7BFF),
        emoji = "👁",
        tersePrompt = """You describe what's in front of the camera in ONE short sentence.

RULES:
1. Identify the main subject only. Under 15 words.
2. No preamble. No "the image shows". Just the description.
3. If text is the main subject, read the text out loud.
4. Always reply in Simplified Chinese (简体中文).""",
        deepPrompt = """You describe what's in front of the camera in detail.

RULES:
1. Identify the main subject and supporting context — environment, objects, action, mood.
2. 2-4 sentences. Vivid but factual.
3. No preamble. Don't start with "the image shows".
4. If text is the main subject, read the text and note the format (sign, label, screen, etc.).
5. Always reply in Simplified Chinese (简体中文).""",
        terseUserPrompt = "Describe the main subject in one short sentence.",
        deepUserPrompt = "Describe what you see in 2-4 sentences with relevant detail.",
    ),
    ANSWER(
        label = "解答",
        accent = Color(0xFFE040FB),
        emoji = "💡",
        tersePrompt = """You answer the question shown in the image with ONLY the answer — no explanation.

RULES:
1. Read the question and any options carefully.
2. Output ONLY the chosen answer.
3. For multiple choice: just the option label and value, e.g. "B. Paris". No reasoning.
4. For short answer: a single phrase or sentence. Maximum 12 words.
5. No preamble. No "the answer is". No "based on the image".
6. If you can't find a question, say "No question detected" — do not describe the image.
7. Always reply in Simplified Chinese (简体中文).""",
        deepPrompt = """You answer the question shown in the image AND explain why.

RULES:
1. Read the question and all options carefully.
2. Give the answer first, then explain in 2-3 sentences why it's correct.
3. For multiple choice: state the option (e.g. "B. Paris"), then explanation.
4. For short answer: lead with the answer, then a short justification.
5. No "the image shows" — just answer.
6. If you can't find a question, say "No question detected".
7. Always reply in Simplified Chinese (简体中文).""",
        terseUserPrompt = "Answer the question shown. Give ONLY the answer, no reasoning.",
        deepUserPrompt = "Answer the question shown, then briefly explain why.",
    ),
    SOLVE(
        label = "求解",
        accent = Color(0xFF40E0D0),
        emoji = "🧮",
        tersePrompt = """You solve the problem shown in the image and output ONLY the final answer.

RULES:
1. No working, no steps, no explanation.
2. Output exactly one line: "Answer: <result>".
3. For code: output ONLY the corrected snippet.
4. No "the problem is". If no problem is visible, say "No problem detected".
5. Write the result in Simplified Chinese (简体中文) where it contains words, but keep the literal "Answer:" prefix.""",
        deepPrompt = """You solve math, physics, code, or logic problems shown in the image, showing your working.

RULES:
1. Identify the problem precisely.
2. Show 3-6 steps of working in plain text. No LaTeX, no markdown.
3. End with one line: "Answer: <result>".
4. For code: explain the bug in 1-2 sentences and show the corrected snippet.
5. Don't describe the image — just solve. If no problem is visible, say "No problem detected".
6. Write your working in Simplified Chinese (简体中文), but keep the literal "Answer:" prefix on the final line.""",
        terseUserPrompt = "Solve the problem shown. Output only the final answer line.",
        deepUserPrompt = "Solve the problem. Show your working briefly, then end with 'Answer: '.",
    );

    fun systemFor(thinking: Boolean) = if (thinking) deepPrompt else tersePrompt
    fun userFor(thinking: Boolean) = if (thinking) deepUserPrompt else terseUserPrompt
}

@Composable
fun LensThinkScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()

    // ── State ──
    var uiState by remember { mutableStateOf<LensLiveUiState>(LensLiveUiState.Initializing) }
    val transcript = remember { mutableStateListOf<TranscriptEntry>() }
    var currentResponse by remember { mutableStateOf("") }
    var ttsEnabled by remember { mutableStateOf(true) }
    var autoOnStill by remember { mutableStateOf(true) }
    var thinkingEnabled by remember { mutableStateOf(com.dia.app.prefs.DiaPrefs.thinkingDefault.value) }
    var mode by remember { mutableStateOf(ThinkMode2.DESCRIBE) }
    val accent = mode.accent
    val queryInFlight = remember { AtomicBoolean(false) }
    var inflightJob by remember { mutableStateOf<Job?>(null) }

    val imageCapture = remember {
        ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY).build()
    }
    val captureExecutor = remember { Executors.newSingleThreadExecutor() }

    // ── Accelerometer state ──
    var isPhoneStill by remember { mutableStateOf(false) }
    var stillStartTime by remember { mutableLongStateOf(0L) }
    var stillProgress by remember { mutableFloatStateOf(0f) }

    // ── TTS ──
    var tts by remember { mutableStateOf<TextToSpeech?>(null) }
    var ttsReady by remember { mutableStateOf(false) }

    // ── Camera ──
    var cameraProvider by remember { mutableStateOf<ProcessCameraProvider?>(null) }
    val previewView = remember {
        PreviewView(context).apply { scaleType = PreviewView.ScaleType.FILL_CENTER }
    }

    // ── Initialize TTS once ──
    DisposableEffect(Unit) {
        val engine = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ttsReady = true
                tts?.language = Locale.SIMPLIFIED_CHINESE
                tts?.setSpeechRate(1.05f)
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) {
                        if (uiState is LensLiveUiState.Speaking) uiState = LensLiveUiState.Scanning
                    }
                    @Deprecated("Deprecated in API")
                    override fun onError(utteranceId: String?) {
                        if (uiState is LensLiveUiState.Speaking) uiState = LensLiveUiState.Scanning
                    }
                })
            }
        }
        tts = engine
        onDispose {
            engine.stop()
            engine.shutdown()
        }
    }

    // ── Accelerometer ──
    DisposableEffect(Unit) {
        val sensorManager = context.getSystemService(android.content.Context.SENSOR_SERVICE) as SensorManager
        val accel = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent) {
                val x = event.values[0]; val y = event.values[1]; val z = event.values[2]
                val mag = sqrt((x * x + y * y + z * z).toDouble()).toFloat()
                val deviation = kotlin.math.abs(mag - SensorManager.GRAVITY_EARTH)
                val nowStill = deviation < STILL_THRESHOLD
                if (nowStill) {
                    if (!isPhoneStill) {
                        isPhoneStill = true
                        stillStartTime = System.currentTimeMillis()
                    }
                    val elapsed = System.currentTimeMillis() - stillStartTime
                    stillProgress = (elapsed.toFloat() / STILL_DURATION_MS).coerceIn(0f, 1f)
                } else {
                    isPhoneStill = false
                    stillStartTime = 0L
                    stillProgress = 0f
                }
            }
            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }
        if (accel != null) sensorManager.registerListener(listener, accel, SensorManager.SENSOR_DELAY_UI)
        onDispose { sensorManager.unregisterListener(listener) }
    }

    // ── Auto-trigger when phone holds still for 2.2s ──
    // Reuses the user's selected action so still-hold over a quiz answers
    // ── Auto-trigger when phone holds still for 2.2s ──
    // Single Ask flow — the model figures out from the frame whether it's
    // a question, a problem, or a scene. The thinking toggle decides
    // whether the answer is terse or explained.
    LaunchedEffect(isPhoneStill, stillStartTime, autoOnStill) {
        if (!autoOnStill) return@LaunchedEffect
        if (isPhoneStill && stillStartTime > 0L && uiState is LensLiveUiState.Scanning && !queryInFlight.get()) {
            val remaining = STILL_DURATION_MS - (System.currentTimeMillis() - stillStartTime)
            if (remaining > 0) delay(remaining)
            if (isPhoneStill && uiState is LensLiveUiState.Scanning && !queryInFlight.get()) {
                inflightJob = doThink(
                    mode = mode,
                    thinking = thinkingEnabled,
                    queryInFlight = queryInFlight,
                    tts = tts.takeIf { ttsEnabled && ttsReady },
                    imageCapture = imageCapture,
                    captureExecutor = captureExecutor,
                    onStateChange = { uiState = it },
                    onResponseUpdate = { currentResponse = it },
                    transcript = transcript,
                    scope = scope,
                )
            }
        }
    }

    // ── Initialize Camera ONCE ──
    LaunchedEffect(Unit) {
        val future = ProcessCameraProvider.getInstance(context)
        future.addListener({ cameraProvider = future.get() }, ContextCompat.getMainExecutor(context))
    }

    // Bind once. Don't rebind on every state change — the original code did
    // this and that was the source of the "video pauses" stutter.
    LaunchedEffect(cameraProvider) {
        val provider = cameraProvider ?: return@LaunchedEffect
        val selector = CameraSelector.DEFAULT_BACK_CAMERA
        val preview = Preview.Builder().build().also { it.surfaceProvider = previewView.surfaceProvider }
        try {
            provider.unbindAll()
            provider.bindToLifecycle(lifecycleOwner, selector, preview, imageCapture)
        } catch (e: Exception) {
            Log.e(TAG, "Camera bind failed", e)
        }
        if (uiState is LensLiveUiState.Initializing) uiState = LensLiveUiState.Scanning
    }

    // Cleanup
    DisposableEffect(Unit) {
        onDispose {
            cameraProvider?.unbindAll()
            tts?.stop()
            DiaEngine.cancelLensQuery()
            queryInFlight.set(false)
        }
    }

    // ── Animation values ──
    val stateColor = when (val s = uiState) {
        is LensLiveUiState.Scanning -> DiaLensListening
        is LensLiveUiState.Thinking -> mode.accent
        is LensLiveUiState.Speaking -> DiaLensSpeaking
        else -> Color(0xFF3A3D46)
    }
    val stateLabel = when (uiState) {
        is LensLiveUiState.Initializing -> "启动中…"
        is LensLiveUiState.Scanning -> mode.label
        is LensLiveUiState.Thinking -> "${mode.label}…"
        is LensLiveUiState.Speaking -> "播报中"
        else -> ""
    }

    val glowTransition = rememberInfiniteTransition(label = "glow")
    val glowAlpha by glowTransition.animateFloat(
        initialValue = 0.1f,
        targetValue = when (uiState) {
            is LensLiveUiState.Thinking -> 0.6f
            is LensLiveUiState.Speaking -> 0.4f
            is LensLiveUiState.Scanning -> 0.2f
            else -> 0.15f
        },
        animationSpec = infiniteRepeatable(tween(2200, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "glowAlpha"
    )
    val animatedStillProgress by animateFloatAsState(
        targetValue = stillProgress,
        animationSpec = tween(150),
        label = "stillRing"
    )
    val auroraTransition = rememberInfiniteTransition(label = "aurora")
    val auroraAngle by auroraTransition.animateFloat(
        0f, 360f,
        infiniteRepeatable(tween(3500, easing = LinearEasing), RepeatMode.Restart),
        label = "auroraAngle"
    )
    val auroraIntensity by animateFloatAsState(
        targetValue = when (uiState) {
            is LensLiveUiState.Thinking -> 0.8f
            is LensLiveUiState.Speaking -> 0.7f
            is LensLiveUiState.Scanning -> 0.25f
            else -> 0f
        },
        animationSpec = tween(600),
        label = "auroraIntensity"
    )
    val auroraActual = auroraIntensity * 0.55f

    // ── UI ──
    Box(modifier = Modifier.fillMaxSize()) {
        AndroidView(factory = { previewView }, modifier = Modifier.fillMaxSize())

        // Top + bottom gradients
        Box(
            modifier = Modifier
                .fillMaxWidth().height(160.dp).align(Alignment.TopCenter)
                .background(
                    Brush.verticalGradient(
                        listOf(Color.Black.copy(alpha = 0.75f), Color.Black.copy(alpha = 0.2f), Color.Transparent)
                    )
                )
        )
        Box(
            modifier = Modifier
                .fillMaxWidth().height(340.dp).align(Alignment.BottomCenter)
                .background(
                    Brush.verticalGradient(
                        listOf(Color.Transparent, Color.Black.copy(alpha = 0.5f), Color.Black.copy(alpha = 0.92f))
                    )
                )
        )

        AuroraBorder(auroraAngle = auroraAngle, auroraActual = auroraActual, tintColor = accent)

        // Top HUD
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 48.dp, start = 16.dp, end = 16.dp)
                .align(Alignment.TopStart),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            // Close
            HudIconButton(icon = Icons.Rounded.Close, contentDesc = "关闭") {
                tts?.stop()
                inflightJob?.cancel()
                DiaEngine.cancelLensQuery()
                onBack()
            }
            Spacer(Modifier.width(10.dp))
            // State pill
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color.Black.copy(alpha = 0.55f))
                    .border(1.dp, stateColor.copy(alpha = 0.3f), RoundedCornerShape(20.dp))
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Box(
                    modifier = Modifier
                        .size(10.dp).clip(CircleShape)
                        .background(stateColor.copy(alpha = 0.3f + glowAlpha * 0.7f))
                        .drawBehind { drawCircle(color = stateColor, radius = 3.dp.toPx()) }
                )
                Text(
                    stateLabel,
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.SemiBold, letterSpacing = 0.5.sp
                    ),
                    color = stateColor,
                )
            }
            Spacer(Modifier.weight(1f))
            // TTS toggle
            HudIconButton(
                icon = if (ttsEnabled) Icons.AutoMirrored.Rounded.VolumeUp else Icons.AutoMirrored.Rounded.VolumeOff,
                contentDesc = if (ttsEnabled) "静音" else "取消静音",
                tint = if (ttsEnabled) Color.White.copy(alpha = 0.85f) else Color.White.copy(alpha = 0.45f),
            ) {
                ttsEnabled = !ttsEnabled
                if (!ttsEnabled) tts?.stop()
            }
            Spacer(Modifier.width(8.dp))
            // Thinking toggle. ON  → Gemma reasons + the prompts ask for an
            // explanation. OFF → terse prompts, just the answer.
            HudIconButton(
                icon = Icons.Rounded.Lightbulb,
                contentDesc = if (thinkingEnabled) "深度思考：开" else "深度思考：关",
                tint = if (thinkingEnabled) accent else Color.White.copy(alpha = 0.4f),
            ) { thinkingEnabled = !thinkingEnabled }
            Spacer(Modifier.width(8.dp))
            // Auto-on-still toggle
            HudIconButton(
                icon = Icons.Rounded.Sensors,
                contentDesc = if (autoOnStill) "自动：开" else "自动：关",
                tint = if (autoOnStill) accent else Color.White.copy(alpha = 0.4f),
            ) { autoOnStill = !autoOnStill }
        }

        // Bottom section
        Column(
            modifier = Modifier
                .fillMaxWidth().align(Alignment.BottomCenter)
                .padding(bottom = 28.dp, start = 16.dp, end = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            // Caption
            val scrollState = rememberScrollState()
            Column(
                modifier = Modifier.fillMaxWidth().height(170.dp).verticalScroll(scrollState),
                verticalArrangement = Arrangement.Bottom,
                horizontalAlignment = Alignment.Start,
            ) {
                AnimatedVisibility(
                    visible = uiState is LensLiveUiState.Thinking && currentResponse.isBlank(),
                    enter = fadeIn(tween(300)) + slideInVertically(tween(300)) { it / 3 },
                    exit = fadeOut(tween(200)),
                ) {
                    ThinkingIndicator(stateColor = accent, isDeep = thinkingEnabled)
                }
                AnimatedVisibility(
                    visible = currentResponse.isNotBlank(),
                    enter = fadeIn(tween(200)) + slideInVertically(tween(250)) { it / 4 },
                    exit = fadeOut(tween(200)),
                ) {
                    Column {
                        ModeTag(mode = mode, thinking = thinkingEnabled)
                        CaptionBubble(
                            text = currentResponse,
                            color = accent,
                            isUser = false,
                            isStreaming = uiState is LensLiveUiState.Thinking,
                        )
                    }
                }
                if (transcript.isNotEmpty() && currentResponse.isBlank() && uiState is LensLiveUiState.Scanning) {
                    val last = transcript.firstOrNull { it.role == "assistant" }
                    if (last != null) {
                        Spacer(Modifier.height(6.dp))
                        CaptionBubble(text = last.text, color = Color.White, isUser = false, isStreaming = false, alpha = 0.55f)
                    }
                }
                LaunchedEffect(currentResponse, transcript.size, uiState) {
                    scrollState.animateScrollTo(scrollState.maxValue)
                }
            }

            Spacer(Modifier.height(14.dp))

            // Mode chips — Describe / Answer / Solve. Lays out three pills
            // with each mode's emoji + label, the active one tinted in
            // its accent. Disabled while inflight so the user can't flip
            // mid-stream.
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.padding(bottom = 12.dp),
            ) {
                ThinkMode2.entries.forEach { m ->
                    ModeChip(
                        emoji = m.emoji,
                        label = m.label,
                        active = m == mode,
                        accent = m.accent,
                        enabled = !queryInFlight.get(),
                        onClick = { mode = m },
                    )
                }
            }

            // Trigger button (or Stop while in flight)
            Box(contentAlignment = Alignment.Center) {
                if (uiState is LensLiveUiState.Scanning && animatedStillProgress > 0.01f && autoOnStill) {
                    Canvas(modifier = Modifier.size(88.dp)) {
                        drawArc(
                            color = accent.copy(alpha = 0.6f),
                            startAngle = -90f,
                            sweepAngle = 360f * animatedStillProgress,
                            useCenter = false,
                            style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round),
                        )
                    }
                }

                val inFlight = uiState is LensLiveUiState.Thinking || uiState is LensLiveUiState.Speaking
                Box(
                    modifier = Modifier
                        .size(76.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                if (inFlight)
                                    listOf(Color(0xFFFF5252), Color(0xFFD32F2F))
                                else
                                    listOf(accent, accent.copy(alpha = 0.7f))
                            )
                        )
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null,
                        ) {
                            if (inFlight) {
                                tts?.stop()
                                inflightJob?.cancel()
                                DiaEngine.cancelLensQuery()
                                queryInFlight.set(false)
                                uiState = LensLiveUiState.Scanning
                                currentResponse = ""
                            } else {
                                inflightJob = doThink(
                                    mode = mode,
                                    thinking = thinkingEnabled,
                                    queryInFlight = queryInFlight,
                                    tts = tts.takeIf { ttsEnabled && ttsReady },
                                    imageCapture = imageCapture,
                                    captureExecutor = captureExecutor,
                                    onStateChange = { uiState = it },
                                    onResponseUpdate = { currentResponse = it },
                                    transcript = transcript,
                                    scope = scope,
                                )
                            }
                        },
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        imageVector = when {
                            inFlight -> Icons.Rounded.Stop
                            mode == ThinkMode2.ANSWER -> Icons.Rounded.Lightbulb
                            mode == ThinkMode2.SOLVE -> Icons.Rounded.Calculate
                            else -> Icons.Rounded.Visibility
                        },
                        contentDescription = if (inFlight) "停止" else "执行${mode.label}",
                        tint = Color.White,
                        modifier = Modifier.size(34.dp),
                    )
                }
            }

            Spacer(Modifier.height(10.dp))
            Text(
                text = when (uiState) {
                    is LensLiveUiState.Scanning ->
                        if (autoOnStill && isPhoneStill) "保持静止即可${mode.label}…"
                        else "点击${mode.label} · 自动${if (autoOnStill) "开" else "关"} · 深度思考${if (thinkingEnabled) "开" else "关"}"
                    is LensLiveUiState.Thinking -> "处理中 — 点击停止"
                    is LensLiveUiState.Speaking -> "播报中 — 点击停止"
                    else -> ""
                },
                style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 0.5.sp),
                color = Color.White.copy(alpha = 0.65f),
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth(),
            )
        }

        if (uiState is LensLiveUiState.Initializing) InitializingOverlay()
    }
}

@Composable
private fun HudIconButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    contentDesc: String,
    tint: Color = Color.White.copy(alpha = 0.85f),
    onClick: () -> Unit,
) {
    IconButton(
        onClick = onClick,
        modifier = Modifier
            .size(40.dp)
            .clip(CircleShape)
            .background(Color.White.copy(alpha = 0.12f))
            .border(1.dp, Color.White.copy(alpha = 0.15f), CircleShape),
    ) {
        Icon(icon, contentDesc, tint = tint, modifier = Modifier.size(20.dp))
    }
}

@Composable
private fun ModeChip(
    emoji: String,
    label: String,
    active: Boolean,
    accent: Color,
    enabled: Boolean = true,
    onClick: () -> Unit,
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(if (active) accent.copy(alpha = 0.18f) else Color.Black.copy(alpha = 0.5f))
            .border(
                1.dp,
                if (active) accent.copy(alpha = 0.6f) else Color.White.copy(alpha = 0.12f),
                RoundedCornerShape(20.dp),
            )
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 7.dp),
    ) {
        Text(
            "$emoji  $label",
            style = MaterialTheme.typography.labelMedium.copy(
                fontWeight = if (active) FontWeight.SemiBold else FontWeight.Medium,
                letterSpacing = 0.4.sp,
            ),
            color = if (active) accent else Color.White.copy(alpha = if (enabled) 0.65f else 0.3f),
        )
    }
}

@Composable
private fun ModeTag(mode: ThinkMode2, thinking: Boolean) {
    Text(
        "${mode.emoji} ${mode.label}${if (thinking) " · 深度思考" else ""}",
        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, letterSpacing = 0.8.sp),
        color = mode.accent.copy(alpha = 0.95f),
        modifier = Modifier
            .padding(start = 4.dp, bottom = 4.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(mode.accent.copy(alpha = 0.15f))
            .padding(horizontal = 8.dp, vertical = 2.dp),
    )
}

/**
 * Run inference for the current [action]. Returns the [Job] so the UI can
 * cancel it from the Stop button. Speak via [tts] iff non-null.
 */
private fun doThink(
    mode: ThinkMode2,
    thinking: Boolean,
    queryInFlight: AtomicBoolean,
    tts: TextToSpeech?,
    imageCapture: ImageCapture,
    captureExecutor: java.util.concurrent.Executor,
    onStateChange: (LensLiveUiState) -> Unit,
    onResponseUpdate: (String) -> Unit,
    transcript: MutableList<TranscriptEntry>,
    scope: kotlinx.coroutines.CoroutineScope,
): Job? {
    if (!queryInFlight.compareAndSet(false, true)) return null

    tts?.stop()
    DiaEngine.cancelLensQuery()

    onStateChange(LensLiveUiState.Thinking(ThinkMode.DEEP))
    onResponseUpdate("")

    val accumulated = StringBuilder()

    return scope.launch(Dispatchers.IO) {
        val frame = try {
            captureFrameScaled(imageCapture, captureExecutor, mirror = false)
        } catch (e: Exception) {
            Log.e(TAG, "Frame capture failed", e)
            null
        }

        BackendRouter.sendLensTurn(
            text = mode.userFor(thinking),
            image = frame,
            systemInstruction = mode.systemFor(thinking),
            extraContext = if (thinking) mapOf("enable_thinking" to "true") else emptyMap(),
            onToken = { partial, done ->
                if (!done) {
                    accumulated.append(partial)
                    val snapshot = accumulated.toString()
                    scope.launch(Dispatchers.Main) { onResponseUpdate(snapshot) }
                } else {
                    queryInFlight.set(false)
                    val finalResponse = accumulated.toString().trim()
                    scope.launch(Dispatchers.Main) {
                        if (finalResponse.isNotBlank()) {
                            transcript.add(0, TranscriptEntry("assistant", finalResponse, mode.label.lowercase()))
                            if (tts != null) {
                                onStateChange(LensLiveUiState.Speaking(finalResponse))
                                tts.speak(finalResponse, TextToSpeech.QUEUE_FLUSH, null, "lens_${mode.name.lowercase()}")
                            } else {
                                onStateChange(LensLiveUiState.Scanning)
                            }
                        } else {
                            onStateChange(LensLiveUiState.Scanning)
                        }
                    }
                }
            },
            onError = { msg ->
                queryInFlight.set(false)
                Log.e(TAG, "Lens think error: $msg")
                scope.launch(Dispatchers.Main) {
                    onResponseUpdate("出错：$msg")
                    onStateChange(LensLiveUiState.Scanning)
                }
            },
        )
    }
}
