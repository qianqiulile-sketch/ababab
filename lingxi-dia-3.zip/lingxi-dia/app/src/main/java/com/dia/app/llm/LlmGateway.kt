package com.dia.app.llm

import android.graphics.Bitmap
import android.util.Base64
import com.dia.app.pilot.cloud.CloudLlmClient
import com.dia.app.prefs.DiaPrefs
import com.dia.app.prefs.DiaSettings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.ByteArrayOutputStream

/**
 * 灵犀对话使用的统一大模型入口：
 *  - 本地（LiteRT-LM / Gemma）走 [DiaEngine.generate]，流式输出
 *  - 云端（OpenAI 兼容接口）走 [CloudLlmClient]，一次性返回
 *
 * 所有调用经过同一把锁串行执行，避免本地引擎被并发调用。
 */
object LlmGateway {

    private val mutex = Mutex()
    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    /** 当前是否走云端。 */
    fun usingCloud(): Boolean = DiaPrefs.cloudEnabled.value && DiaPrefs.cloudIsConfigured()

    /** 是否有可用的大模型（本地已加载 或 云端已配置）。 */
    fun isAvailable(): Boolean = usingCloud() || DiaEngine.isReady

    /** 当前模型的显示名称。 */
    fun label(): String = if (usingCloud()) {
        "云端 · ${DiaPrefs.cloudModel.value}"
    } else {
        val path = DiaEngine.currentModelPath
        if (path == null) "未加载模型" else "本地 · ${java.io.File(path).nameWithoutExtension}"
    }

    /**
     * 拼接提示词时可用的字符预算（粗略按 1 字 ≈ 1 token 估算，
     * 预留约 1100 token 给模型输出）。
     */
    fun promptCharBudget(): Int = if (usingCloud()) {
        24_000
    } else {
        (DiaSettings.contextTokens.value - 1100).coerceAtLeast(1500)
    }

    suspend fun complete(
        system: String,
        prompt: String,
        images: List<Bitmap> = emptyList(),
        audio: List<AudioClip> = emptyList(),
        temperature: Double = 0.6,
        thinking: Boolean = false,
        timeoutMs: Long = 180_000L,
        onDelta: (delta: String, thought: String?) -> Unit = { _, _ -> },
    ): String = mutex.withLock {
        if (usingCloud()) {
            val client = CloudLlmClient(
                baseUrl = DiaPrefs.cloudBaseUrl.value,
                apiKey = DiaPrefs.cloudApiKey.value,
                model = DiaPrefs.cloudModel.value,
            )
            val imageB64 = images.firstOrNull()?.let { encodePng(it) }
            val userPrompt = if (audio.isNotEmpty()) {
                "$prompt\n（注意：用户发送了语音，但云端模型无法收听音频，请提示用户改用文字或切换到本地模型。）"
            } else prompt
            // 用 async + await：取消时立即返回，不必等 HTTP 超时。
            val deferred = ioScope.async {
                client.chat(
                    systemPrompt = system,
                    userPrompt = userPrompt,
                    screenshotPngBase64 = imageB64,
                    history = emptyList(),
                    temperature = temperature,
                    maxTokens = 4096,
                )
            }
            val res = deferred.await()
            val content = res.content
            if (content.isNullOrBlank()) {
                throw IllegalStateException(res.error ?: "云端返回为空")
            }
            onDelta(content, null)
            content
        } else {
            if (!DiaEngine.isReady) throw IllegalStateException("本地模型未加载，请先在顶部选择模型")
            DiaEngine.generate(
                systemInstruction = system,
                text = prompt,
                images = images,
                audioClips = audio,
                temperature = temperature,
                thinking = thinking,
                timeoutMs = timeoutMs,
                onDelta = onDelta,
            )
        }
    }

    /** 立即中止正在进行的本地推理。 */
    fun cancelCurrent() {
        DiaEngine.cancelGenerate()
    }

    private fun encodePng(bitmap: Bitmap): String? = try {
        val baos = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, baos)
        Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)
    } catch (_: Throwable) {
        null
    }
}
