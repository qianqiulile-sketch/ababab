package com.dia.app.screen

import android.content.Context
import android.util.Log
import com.dia.app.DiaAccessibilityService
import com.dia.app.llm.BackendRouter
import com.dia.app.llm.DiaEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/**
 * Screen-level AI actions: Translate and Summarize.
 *
 * Unlike Lens Live (which uses the camera), this reads the CURRENT SCREEN's
 * accessibility tree text and sends it to the model. Works on any app, any
 * screen, without needing the camera.
 *
 * Exposed as a singleton so it can be triggered from:
 *   - The floating quick-action bubble
 *   - A notification tile
 *   - The Pilot tool set
 */
object ScreenAssistant {

    private const val TAG = "ScreenAssistant"

    enum class Mode { TRANSLATE, SUMMARIZE }
    enum class Status { IDLE, WORKING, DONE, ERROR }

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private val _status = MutableStateFlow(Status.IDLE)
    val status: StateFlow<Status> = _status.asStateFlow()

    private val _result = MutableStateFlow("")
    val result: StateFlow<String> = _result.asStateFlow()

    private val _mode = MutableStateFlow(Mode.SUMMARIZE)
    val mode: StateFlow<Mode> = _mode.asStateFlow()

    @Volatile
    private var appContext: Context? = null

    fun attach(context: Context) {
        if (appContext == null) appContext = context.applicationContext
    }

    /**
     * Launch the selective screen translate — user draws a rectangle around
     * the text they want translated, we screenshot that region and send the
     * image to Gemma.
     */
    fun translateScreen() {
        val ctx = appContext ?: run { reportError("App context not available"); return }
        com.dia.app.translate.ScreenTranslateService.start(
            ctx,
            com.dia.app.translate.ScreenTranslateService.Mode.TRANSLATE,
        )
    }

    /**
     * Region-pick → screenshot → image-based summary. The original
     * [summarizeScreen] uses the accessibility-tree (text-only) which
     * misses charts, layouts, etc. This is image-aware via Gemma vision.
     */
    fun summarizeScreenImage() {
        val ctx = appContext ?: run { reportError("App context not available"); return }
        com.dia.app.translate.ScreenTranslateService.start(
            ctx,
            com.dia.app.translate.ScreenTranslateService.Mode.SUMMARIZE,
        )
    }

    /**
     * Region-pick → screenshot → "answer the question in this image".
     * Useful for quizzes, MCQ, fill-in-the-blanks visible on any app.
     */
    fun answerScreen() {
        val ctx = appContext ?: run { reportError("App context not available"); return }
        com.dia.app.translate.ScreenTranslateService.start(
            ctx,
            com.dia.app.translate.ScreenTranslateService.Mode.ANSWER,
        )
    }

    /**
     * Region-pick → screenshot → "solve the problem in this image".
     * Math, code, equations — shows steps + final answer.
     */
    fun solveScreen() {
        val ctx = appContext ?: run { reportError("App context not available"); return }
        com.dia.app.translate.ScreenTranslateService.start(
            ctx,
            com.dia.app.translate.ScreenTranslateService.Mode.SOLVE,
        )
    }

    private fun reportError(msg: String) {
        _result.value = msg
        _status.value = Status.ERROR
    }

    /**
     * Read the current screen's text content and produce a concise summary.
     */
    fun summarizeScreen() {
        run(Mode.SUMMARIZE)
    }

    fun dismiss() {
        _status.value = Status.IDLE
        _result.value = ""
    }

    private fun run(m: Mode) {
        if (_status.value == Status.WORKING) return
        _mode.value = m
        _status.value = Status.WORKING
        _result.value = ""

        scope.launch {
            try {
                val screenText = extractScreenText()
                if (screenText.isBlank()) {
                    _result.value = "No readable text on this screen."
                    _status.value = Status.ERROR
                    return@launch
                }

                val prompt = when (m) {
                    Mode.TRANSLATE -> buildTranslatePrompt(screenText)
                    Mode.SUMMARIZE -> buildSummarizePrompt(screenText)
                }

                val systemInstruction = when (m) {
                    Mode.TRANSLATE ->
                        "You are a translator. Translate the given text to English. " +
                            "If it's already in English, say 'Already in English' and provide a brief summary instead. " +
                            "Output ONLY the translation, nothing else."
                    Mode.SUMMARIZE ->
                        "You are a summarizer. Given text from a phone screen, produce a clear, " +
                            "concise summary in 2-4 sentences. Focus on the key information the user " +
                            "would want to know. No preamble, no 'Here is a summary' — just the summary."
                }

                val response = callModel(systemInstruction, prompt)
                _result.value = response.ifBlank { "Could not process the screen text." }
                _status.value = if (response.isNotBlank()) Status.DONE else Status.ERROR
            } catch (e: Exception) {
                Log.e(TAG, "Screen assistant failed", e)
                _result.value = "Error: ${e.message}"
                _status.value = Status.ERROR
            }
        }
    }

    /**
     * Extract all visible text from the current screen using the accessibility
     * tree. This is the same tree Pilot/Guide use, but here we only care about
     * the text content, not the interactive structure.
     */
    private fun extractScreenText(): String {
        val service = DiaAccessibilityService.getInstance() ?: return ""
        val root = service.rootInActiveWindow ?: return ""
        val sb = StringBuilder()
        collectText(root, sb)
        return sb.toString().trim().take(3000) // cap to fit token budget
    }

    private fun collectText(node: android.view.accessibility.AccessibilityNodeInfo, sb: StringBuilder) {
        val text = node.text?.toString()?.trim()
        val desc = node.contentDescription?.toString()?.trim()
        if (!text.isNullOrBlank()) {
            sb.append(text).append('\n')
        } else if (!desc.isNullOrBlank()) {
            sb.append(desc).append('\n')
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            collectText(child, sb)
        }
    }

    private fun buildTranslatePrompt(screenText: String): String {
        return "Translate the following screen text to English:\n\n$screenText"
    }

    private fun buildSummarizePrompt(screenText: String): String {
        return "Summarize the following screen content:\n\n$screenText"
    }

    private suspend fun callModel(systemInstruction: String, prompt: String): String =
        suspendCancellableCoroutine { cont ->
            val sb = StringBuilder()
            BackendRouter.sendPilotTurn(
                systemInstruction = systemInstruction,
                text = prompt,
                onToken = { partial, done ->
                    if (partial.isNotEmpty()) sb.append(partial)
                    if (done && cont.isActive) cont.resume(sb.toString().trim())
                },
                onError = { msg ->
                    Log.e(TAG, "Model error: $msg")
                    if (cont.isActive) cont.resume("")
                }
            )
        }
}
