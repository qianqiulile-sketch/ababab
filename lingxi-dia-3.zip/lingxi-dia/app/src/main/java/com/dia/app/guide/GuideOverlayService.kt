package com.dia.app.guide

import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.RectF
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import android.view.Gravity
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import com.dia.app.MainActivity
import com.dia.app.R
import com.dia.app.guide.ui.CaptionOverlayView
import com.dia.app.guide.ui.PointerOverlayView
import com.dia.app.guide.ui.TargetHighlightView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Locale

/**
 * Foreground service that owns Guide's system overlays.
 *
 * Responsibilities:
 *   - Add / remove WindowManager views for the pointer, highlight, caption.
 *   - Observe GuideEngine state and re-render when the current step changes.
 *   - Animate the pointer from its current position to the next target.
 *   - Speak captions via TextToSpeech.
 */
class GuideOverlayService : Service(), CaptionOverlayView.Listener {

    companion object {
        private const val TAG = "GuideOverlay"
        private const val CHANNEL_ID = "dia_guide_channel"
        private const val NOTIFICATION_ID = 4712
        private const val ACTION_START = "com.dia.app.guide.START"
        private const val ACTION_STOP = "com.dia.app.guide.STOP"
        private const val EXTRA_QUESTION = "question"

        @Volatile
        private var running = false
        fun isRunning(): Boolean = running

        fun hasOverlayPermission(context: Context): Boolean {
            return Build.VERSION.SDK_INT < Build.VERSION_CODES.M ||
                Settings.canDrawOverlays(context)
        }

        fun start(context: Context, question: String) {
            val intent = Intent(context, GuideOverlayService::class.java).apply {
                action = ACTION_START
                putExtra(EXTRA_QUESTION, question)
            }
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else context.startService(intent)
            } catch (e: Exception) { Log.w(TAG, "start error: ${e.message}") }
        }

        fun stop(context: Context) {
            try {
                context.stopService(Intent(context, GuideOverlayService::class.java))
            } catch (_: Exception) {}
        }
    }

    private lateinit var windowManager: WindowManager
    private var pointer: PointerOverlayView? = null
    private var highlight: TargetHighlightView? = null
    private var caption: CaptionOverlayView? = null

    private var pointerParams: WindowManager.LayoutParams? = null
    private var pointerAnim: ValueAnimator? = null

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var lastSpoken: String? = null
    private var lastSpokenAt: Long = 0L

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var observeJob: Job? = null

    /** Snapshot of accessibility prefs taken when the service starts. */
    private var bigText: Boolean = false
    private var highContrast: Boolean = false
    private var slowVoice: Boolean = false
    private var reduceMotion: Boolean = false

    /** Auto-hides the caption a few seconds after a TYPE step renders so
     *  the bubble doesn't block the user's keyboard / input field. */
    private var captionAutoHideJob: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        // Snapshot accessibility prefs once — we don't hot-reload the
        // overlay if the user toggles them mid-tutorial.
        bigText = com.dia.app.prefs.DiaPrefs.bigText.value
        highContrast = com.dia.app.prefs.DiaPrefs.highContrast.value
        slowVoice = com.dia.app.prefs.DiaPrefs.slowVoice.value
        reduceMotion = com.dia.app.prefs.DiaPrefs.reduceMotion.value

        createChannel()
        val notification = buildNotification("灵犀指南", "随时为你提供帮助…")
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else startForeground(NOTIFICATION_ID, notification)
        } catch (e: Exception) {
            Log.w(TAG, "startForeground failed: ${e.message}")
        }
        running = true
        tts = TextToSpeech(applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.SIMPLIFIED_CHINESE
                // Slow Guide voice is friendlier for elderly users.
                tts?.setSpeechRate(if (slowVoice) 0.85f else 1.05f)
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(p0: String?) {}
                    override fun onDone(p0: String?) {}
                    override fun onError(p0: String?) {}
                })
                ttsReady = true
            }
        }
        observe()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        if (action == ACTION_START) {
            val q = intent.getStringExtra(EXTRA_QUESTION).orEmpty()
            if (q.isNotBlank()) {
                updateNotification("灵犀指南", "正在规划：$q")
                GuideEngine.start(q)
            }
        } else if (action == ACTION_STOP) {
            GuideEngine.stop()
            stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        running = false
        observeJob?.cancel()
        observeJob = null
        highlightStrobeJob?.cancel()
        captionAutoHideJob?.cancel()
        try { tts?.stop(); tts?.shutdown() } catch (_: Exception) {}
        tts = null
        removePointer(); removeHighlight(); removeCaption()
        pointerAnim?.cancel()
        super.onDestroy()
    }

    // ─── Engine observation ───

    private fun observe() {
        observeJob = scope.launch {
            launch {
                GuideEngine.state.collectLatest { st ->
                    when (st) {
                        GuideState.ANALYZING -> {
                            updateNotification("灵犀指南", "正在分析屏幕…")
                            showCaption(0, 0, "正在分析屏幕…")
                        }
                        GuideState.GUIDING -> {
                            // A step render will follow via currentStep flow.
                            updateNotification("灵犀指南", "正在逐步为你指引")
                        }
                        GuideState.COMPLETE -> {
                            updateNotification("灵犀指南", "教程已完成 ✓")
                            showCaption(0, 0, "全部完成。点击 × 关闭。")
                            speak("全部完成！")
                            highlightStrobeJob?.cancel()
                            removePointer(); removeHighlight()
                        }
                        GuideState.PAUSED -> {
                            updateNotification("灵犀指南", "已暂停")
                            highlightStrobeJob?.cancel()
                        }
                        GuideState.IDLE -> {
                            highlightStrobeJob?.cancel()
                            removePointer(); removeHighlight(); removeCaption()
                            stopSelf()
                        }
                    }
                }
            }
            launch {
                GuideEngine.currentStep.collectLatest { step ->
                    if (step == null) return@collectLatest
                    renderStep(step)
                }
            }
            launch {
                GuideEngine.messages.collect { msg ->
                    showCaption(0, 0, msg)
                    speak(msg)
                }
            }
        }
    }

    private var highlightHideJob: Job? = null
    /** Loops the show/hide strobe until the next step or stop. */
    private var highlightStrobeJob: Job? = null

    private fun renderStep(step: GuideStep) {
        val bounds = step.targetBounds
        // Cancel any previous strobe loop before starting a new one.
        highlightHideJob?.cancel()
        highlightStrobeJob?.cancel()

        if (bounds != null) {
            // Strobe pattern: show the highlight + pointer for 1s, hide
            // them entirely for 5s so the user can tap unobstructed, then
            // flash again. Repeats until the next step or until the user
            // closes Guide. This is much friendlier than the old behaviour
            // where the cue stuck around at 30 % alpha — touchable but
            // visually distracting on top of dense UIs.
            highlightStrobeJob = scope.launch {
                if (reduceMotion) {
                    // Static dim cue — no flashing for users sensitive to motion.
                    showHighlight(bounds)
                    animatePointerTo(bounds.centerX(), bounds.centerY())
                    kotlinx.coroutines.delay(1200)
                    highlight?.animate()?.alpha(0.35f)?.setDuration(220)?.start()
                    pointer?.animate()?.alpha(0.45f)?.setDuration(220)?.start()
                    return@launch
                }
                while (this.isActive) {
                    // ── Visible phase ──
                    showHighlight(bounds)
                    animatePointerTo(bounds.centerX(), bounds.centerY())
                    highlight?.alpha = 1f
                    pointer?.alpha = 1f
                    kotlinx.coroutines.delay(1000)

                    if (!this.isActive) break

                    // ── Hidden phase ──
                    val fadeOut = highlight?.animate()?.alpha(0f)?.setDuration(180)
                    fadeOut?.start()
                    pointer?.animate()?.alpha(0f)?.setDuration(180)?.start()
                    kotlinx.coroutines.delay(220)

                    // Fully remove during the dark phase so the views truly
                    // can't intercept any touches near the target.
                    removeHighlight()
                    removePointer()

                    kotlinx.coroutines.delay(5000)
                }
            }
        } else {
            removeHighlight()
            removePointer()
        }
        showCaption(step.stepNumber, step.totalSteps, step.caption)
        speak(step.caption)
        // Haptic pulse so a user with the volume off still gets a cue that a
        // new step has appeared.
        pulseHaptic()
        updateNotification("灵犀指南 · 第 ${step.stepNumber}/${step.totalSteps} 步", step.caption)

        // ── TYPE-step caption auto-hide ──
        // When the next action requires the user to type, the caption bubble
        // can sit on top of the EditText / IME panel and absorb taps. Hide
        // it 3.5s after rendering so the keyboard area is clean. The user
        // can replay it with the floating notification.
        captionAutoHideJob?.cancel()
        if (step.action == GuideAction.TYPE) {
            captionAutoHideJob = scope.launch {
                kotlinx.coroutines.delay(3500)
                caption?.animate()?.alpha(0.0f)?.setDuration(280)?.withEndAction {
                    removeCaption()
                }?.start()
            }
        } else {
            // Make sure caption is fully visible for non-typing steps even
            // if a previous TYPE step had faded it out.
            caption?.alpha = 1f
        }
    }

    private fun pulseHaptic() {
        try {
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = getSystemService(Context.VIBRATOR_MANAGER_SERVICE)
                    as android.os.VibratorManager
                vm.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                getSystemService(Context.VIBRATOR_SERVICE) as android.os.Vibrator
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(
                    android.os.VibrationEffect.createOneShot(
                        50L,
                        android.os.VibrationEffect.DEFAULT_AMPLITUDE,
                    )
                )
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(50L)
            }
        } catch (_: Exception) {}
    }

    // ─── Overlays ───

    private var captionParams: WindowManager.LayoutParams? = null

    /**
     * Samsung One UI 6+ (Android 14) blocks touches through overlays that use
     * FLAG_NOT_TOUCHABLE and shows "app not optimized" toast. The fix:
     * - Do NOT use FLAG_NOT_TOUCHABLE.
     * - Use FLAG_NOT_FOCUSABLE + FLAG_NOT_TOUCH_MODAL so the window doesn't
     *   steal focus or modal touches.
     * - Make the views themselves pass-through by overriding dispatchTouchEvent
     *   to return false (done in PointerOverlayView and TargetHighlightView).
     * - Set window width/height to exactly the view size (no extra padding).
     */
    private fun passThroughFlags(): Int =
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN

    private fun showCaption(step: Int, total: Int, text: String) {
        if (caption == null) {
            caption = CaptionOverlayView(this, bigText = bigText, highContrast = highContrast).apply {
                listener = this@GuideOverlayService
            }
            // Caption needs to be touchable for its buttons — so we cannot
            // use FLAG_NOT_TOUCHABLE. But we DO use FLAG_NOT_TOUCH_MODAL
            // and FLAG_LAYOUT_IN_SCREEN so taps OUTSIDE the bubble fall
            // through to the app below (otherwise the user couldn't tap an
            // EditText that happened to be under the caption rectangle).
            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                    WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                y = dp(48)
            }
            captionParams = params
            try { windowManager.addView(caption, params) }
            catch (e: Exception) { Log.w(TAG, "caption add failed: ${e.message}") }
        }
        // Always show the user's original goal so older users don't lose
        // context after a few steps.
        val goalText = GuideEngine.guide.value?.question
        caption?.bind(step, total, text, goalText)
        caption?.alpha = 1f
        repositionCaption()
    }

    /** Move caption to the top or bottom of the screen, whichever is farther from the target.
     *  For TYPE steps we always pin to the top — the keyboard occupies the
     *  bottom half and any caption there gets covered or eats touches. */
    private fun repositionCaption() {
        val params = captionParams ?: return
        val step = GuideEngine.currentStep.value
        val screenH = resources.displayMetrics.heightPixels
        val targetCenterY = step?.targetBounds?.centerY() ?: (screenH / 2f)

        if (step?.action == GuideAction.TYPE) {
            // Always go top — keyboard takes the bottom half.
            params.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            params.y = dp(48)
        } else if (targetCenterY > screenH / 2f) {
            params.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            params.y = dp(48)
        } else {
            params.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            params.y = dp(48)
        }
        try { windowManager.updateViewLayout(caption, params) } catch (_: Exception) {}
    }

    private fun removeCaption() {
        caption?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        caption = null
        captionParams = null
    }

    private fun showHighlight(bounds: RectF) {
        removeHighlight()
        val pad = dp(8)
        val view = TargetHighlightView(this, highContrast = highContrast)
        val params = WindowManager.LayoutParams(
            (bounds.width() + pad * 2).toInt(),
            (bounds.height() + pad * 2).toInt(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            passThroughFlags(),
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (bounds.left - pad).toInt()
            y = (bounds.top - pad).toInt()
        }
        try {
            windowManager.addView(view, params)
            highlight = view
        } catch (e: Exception) {
            Log.w(TAG, "highlight add failed: ${e.message}")
        }
    }

    private fun removeHighlight() {
        highlight?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        highlight = null
    }

    private fun ensurePointer(initialCx: Float, initialCy: Float) {
        if (pointer != null) return
        val size = dp(80)
        val p = PointerOverlayView(this)
        val params = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            passThroughFlags(),
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (initialCx - size / 2).toInt()
            y = (initialCy - size / 2).toInt()
        }
        try {
            windowManager.addView(p, params)
            pointer = p
            pointerParams = params
            if (!reduceMotion) p.startPulse()
        } catch (e: Exception) {
            Log.w(TAG, "pointer add failed: ${e.message}")
        }
    }

    private fun removePointer() {
        pointer?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        pointer = null
        pointerParams = null
    }

    private fun animatePointerTo(tx: Float, ty: Float) {
        val size = dp(80)
        if (pointer == null) {
            ensurePointer(tx, ty)
            return
        }
        val params = pointerParams ?: return

        // Reduce-motion: snap to the new position instead of animating.
        if (reduceMotion) {
            params.x = (tx - size / 2).toInt()
            params.y = (ty - size / 2).toInt()
            try { windowManager.updateViewLayout(pointer, params) } catch (_: Exception) {}
            return
        }

        val startX = params.x + size / 2f
        val startY = params.y + size / 2f
        val dx = tx - startX
        val dy = ty - startY
        val dist = Math.sqrt((dx * dx + dy * dy).toDouble()).toFloat()
        val duration = (300 + (dist / 2).coerceAtMost(450f)).toLong()

        pointerAnim?.cancel()
        pointerAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            this.duration = duration
            addUpdateListener { animator ->
                val t = animator.animatedValue as Float
                val cx = startX + (tx - startX) * t
                val cy = startY + (ty - startY) * t
                params.x = (cx - size / 2).toInt()
                params.y = (cy - size / 2).toInt()
                try { windowManager.updateViewLayout(pointer, params) } catch (_: Exception) {}
            }
            start()
        }
    }

    // ─── Caption listener ───

    override fun onNext() { GuideEngine.next() }
    override fun onPrevious() { GuideEngine.previous() }
    override fun onReplay() { GuideEngine.replay() }
    override fun onClose() { GuideEngine.stop(); stopSelf() }
    override fun onTranslate() {
        // Not used from Guide overlay — translate lives on the QuickAction bubble
    }

    // ─── TTS ───

    private fun speak(text: String) {
        if (!ttsReady) return
        // Don't repeat the exact same caption if it was just spoken — the
        // model occasionally emits the same step twice during a re-plan.
        val now = System.currentTimeMillis()
        if (text == lastSpoken && (now - lastSpokenAt) < 5000) return
        lastSpoken = text
        lastSpokenAt = now
        try {
            tts?.stop()
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "guide_$now")
        } catch (_: Exception) {}
    }

    // ─── Notification ───

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "灵犀指南", NotificationManager.IMPORTANCE_LOW).apply {
                description = "指南逐步指引你操作时显示"
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(title: String, text: String): Notification {
        val intent = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        val pending = PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(text.take(140))
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setSmallIcon(R.drawable.ic_dia_logo)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(pending)
            .build()
    }

    private fun updateNotification(title: String, text: String) {
        try {
            val mgr = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            mgr.notify(NOTIFICATION_ID, buildNotification(title, text))
        } catch (_: Exception) {}
    }

    private fun dp(v: Int): Int =
        (v * resources.displayMetrics.density).toInt()
}
