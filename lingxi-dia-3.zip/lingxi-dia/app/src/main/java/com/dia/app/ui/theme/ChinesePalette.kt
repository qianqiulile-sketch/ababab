package com.dia.app.ui.theme

import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

/**
 * 中国风配色。两套：
 *  - 墨夜 [InkPalette]：墨色底、宣纸白字、朱砂与古金点缀
 *  - 宣纸 [PaperPalette]：米黄宣纸底、浓墨字、朱砂印章
 */
@Immutable
data class DiaPalette(
    val isDark: Boolean,
    /** 页面底色 */
    val background: Color,
    /** 底色渐变的第二色（做出水墨晕染感） */
    val backgroundAlt: Color,
    /** 卡片 / 气泡 */
    val surface: Color,
    val surfaceAlt: Color,
    /** 朱砂（主色） */
    val cinnabar: Color,
    /** 主色上的文字 */
    val onCinnabar: Color,
    /** 古金（描边 / 次要强调） */
    val gold: Color,
    /** 黛青（第三色） */
    val indigo: Color,
    /** 竹青（成功） */
    val bamboo: Color,
    val text: Color,
    val textSecondary: Color,
    val textTertiary: Color,
    val border: Color,
    val error: Color,
    /** 用户气泡底色 */
    val userBubble: Color,
    val onUserBubble: Color,
    /** 水墨远山的颜色 */
    val mountain: Color,
)

val InkPalette = DiaPalette(
    isDark = true,
    background = Color(0xFF15110E),
    backgroundAlt = Color(0xFF231C16),
    surface = Color(0xFF211B16),
    surfaceAlt = Color(0xFF2B231C),
    cinnabar = Color(0xFFE0533F),
    onCinnabar = Color(0xFFFFF6EA),
    gold = Color(0xFFD4A85A),
    indigo = Color(0xFF5FA392),
    bamboo = Color(0xFF7FB069),
    text = Color(0xFFF0E8D8),
    textSecondary = Color(0xFFB5A88F),
    textTertiary = Color(0xFF7F7462),
    border = Color(0x33D4A85A),
    error = Color(0xFFE5534B),
    userBubble = Color(0xFF7A2E22),
    onUserBubble = Color(0xFFFFF1E2),
    mountain = Color(0xFFF0E8D8),
)

val PaperPalette = DiaPalette(
    isDark = false,
    background = Color(0xFFF4EEDF),
    backgroundAlt = Color(0xFFEAE0CA),
    surface = Color(0xFFFBF7EC),
    surfaceAlt = Color(0xFFF1E8D4),
    cinnabar = Color(0xFFB5372B),
    onCinnabar = Color(0xFFFFF8EE),
    gold = Color(0xFF9A7B3C),
    indigo = Color(0xFF3E6E64),
    bamboo = Color(0xFF5B8A3E),
    text = Color(0xFF2B2520),
    textSecondary = Color(0xFF5E5246),
    textTertiary = Color(0xFF8C7E6C),
    border = Color(0x4D9A7B3C),
    error = Color(0xFFB3261E),
    userBubble = Color(0xFFB5372B),
    onUserBubble = Color(0xFFFFF8EE),
    mountain = Color(0xFF2B2520),
)

fun paletteFor(mode: String): DiaPalette = if (mode == "paper") PaperPalette else InkPalette

val LocalDiaPalette = staticCompositionLocalOf { InkPalette }

/** 在 Composable 中取当前配色：`val p = DiaPal.current` */
object DiaPal {
    val current: DiaPalette
        @Composable
        @ReadOnlyComposable
        get() = LocalDiaPalette.current
}
