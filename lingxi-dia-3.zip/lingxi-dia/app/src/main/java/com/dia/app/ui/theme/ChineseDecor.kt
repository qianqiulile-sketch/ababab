package com.dia.app.ui.theme

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * 水墨背景：底色竖向晕染 + 两团淡墨 + 底部远山剪影。
 * 只用 drawBehind 画，不占布局，性能开销很小。
 */
fun Modifier.inkWashBackground(p: DiaPalette): Modifier = this.drawBehind {
    drawRect(
        brush = Brush.verticalGradient(
            colors = listOf(p.background, p.backgroundAlt, p.background),
        ),
    )
    val inkAlpha = if (p.isDark) 0.05f else 0.06f
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(p.mountain.copy(alpha = inkAlpha), Color.Transparent),
            center = Offset(size.width * 0.85f, size.height * 0.12f),
            radius = size.width * 0.6f,
        ),
        radius = size.width * 0.6f,
        center = Offset(size.width * 0.85f, size.height * 0.12f),
    )
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(p.cinnabar.copy(alpha = inkAlpha * 0.6f), Color.Transparent),
            center = Offset(size.width * 0.1f, size.height * 0.55f),
            radius = size.width * 0.5f,
        ),
        radius = size.width * 0.5f,
        center = Offset(size.width * 0.1f, size.height * 0.55f),
    )
    // 远山：两层不同深浅的山峦
    val w = size.width
    val h = size.height
    val far = Path().apply {
        moveTo(0f, h * 0.86f)
        cubicTo(w * 0.12f, h * 0.78f, w * 0.22f, h * 0.80f, w * 0.32f, h * 0.84f)
        cubicTo(w * 0.42f, h * 0.76f, w * 0.55f, h * 0.74f, w * 0.66f, h * 0.83f)
        cubicTo(w * 0.78f, h * 0.79f, w * 0.90f, h * 0.77f, w, h * 0.82f)
        lineTo(w, h)
        lineTo(0f, h)
        close()
    }
    drawPath(far, color = p.mountain.copy(alpha = if (p.isDark) 0.035f else 0.045f))
    val near = Path().apply {
        moveTo(0f, h * 0.93f)
        cubicTo(w * 0.18f, h * 0.87f, w * 0.30f, h * 0.90f, w * 0.45f, h * 0.92f)
        cubicTo(w * 0.60f, h * 0.86f, w * 0.75f, h * 0.88f, w, h * 0.91f)
        lineTo(w, h)
        lineTo(0f, h)
        close()
    }
    drawPath(near, color = p.mountain.copy(alpha = if (p.isDark) 0.05f else 0.06f))
}

/**
 * 卷轴卡片描边：细金线 + 四角回纹小折角。
 */
fun Modifier.scrollFrame(p: DiaPalette, corner: Dp = 14.dp): Modifier = this
    .border(0.8.dp, p.border, RoundedCornerShape(corner))
    .drawBehind {
        val len = 10.dp.toPx()
        val inset = 4.dp.toPx()
        val sw = 1.2.dp.toPx()
        val c = p.gold.copy(alpha = 0.55f)
        // 左上
        drawLine(c, Offset(inset, inset), Offset(inset + len, inset), sw)
        drawLine(c, Offset(inset, inset), Offset(inset, inset + len), sw)
        // 右上
        drawLine(c, Offset(size.width - inset, inset), Offset(size.width - inset - len, inset), sw)
        drawLine(c, Offset(size.width - inset, inset), Offset(size.width - inset, inset + len), sw)
        // 左下
        drawLine(c, Offset(inset, size.height - inset), Offset(inset + len, size.height - inset), sw)
        drawLine(c, Offset(inset, size.height - inset), Offset(inset, size.height - inset - len), sw)
        // 右下
        drawLine(c, Offset(size.width - inset, size.height - inset), Offset(size.width - inset - len, size.height - inset), sw)
        drawLine(c, Offset(size.width - inset, size.height - inset), Offset(size.width - inset, size.height - inset - len), sw)
    }

/** 朱砂印章（方形红底白字），用作头像 / 标志。 */
@Composable
fun SealMark(
    text: String,
    size: Dp = 36.dp,
    color: Color = DiaPal.current.cinnabar,
    textColor: Color = DiaPal.current.onCinnabar,
    modifier: Modifier = Modifier,
) {
    Box(
        modifier = modifier
            .size(size)
            .clip(RoundedCornerShape(size * 0.18f))
            .background(color)
            .border(1.dp, textColor.copy(alpha = 0.35f), RoundedCornerShape(size * 0.18f)),
        contentAlignment = Alignment.Center,
    ) {
        Box(
            modifier = Modifier
                .size(size * 0.82f)
                .border(0.8.dp, textColor.copy(alpha = 0.55f), RoundedCornerShape(size * 0.12f)),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                text = text,
                color = textColor,
                fontFamily = DiaSerif,
                fontWeight = FontWeight.Bold,
                fontSize = (size.value * 0.46f).sp,
            )
        }
    }
}

/** 祥云回纹分隔线。 */
@Composable
fun CloudDivider(p: DiaPalette, modifier: Modifier = Modifier) {
    Canvas(modifier = modifier.fillMaxWidth().height(10.dp)) {
        val y = size.height / 2f
        val c = p.gold.copy(alpha = 0.45f)
        val sw = 1.dp.toPx()
        val unit = 22.dp.toPx()
        val r = 3.dp.toPx()
        drawLine(c.copy(alpha = 0.25f), Offset(0f, y), Offset(size.width, y), sw * 0.8f)
        var x = unit / 2f
        while (x < size.width) {
            // 一朵小祥云：两个相切的小圆弧
            drawCircle(c, radius = r, center = Offset(x - r * 0.9f, y), style = Stroke(width = sw))
            drawCircle(c, radius = r * 0.75f, center = Offset(x + r * 0.7f, y - r * 0.2f), style = Stroke(width = sw))
            x += unit
        }
    }
}
