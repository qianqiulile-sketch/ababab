package com.dia.app.memory

import android.content.Context
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

/**
 * 一条长期记忆。
 * @param source "auto" = 对话中自动提取；"manual" = 用户手写
 */
data class MemoryItem(
    val id: String = UUID.randomUUID().toString(),
    val content: String,
    val category: String = "其他",
    val source: String = "manual",
    val pinned: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val hits: Int = 0,
)

/**
 * 记忆库：`filesDir/memory.json`。
 *
 * - 自动去重：新内容与已有内容高度相似时更新旧条目而不是新增
 * - [relevant] 按「关键词重合度 + 置顶 + 最近使用」挑出与当前问题最相关的几条，
 *   注入到系统提示词里，让模型「记得」用户。
 */
object MemoryStore {

    private const val TAG = "MemoryStore"
    private const val FILE_NAME = "memory.json"
    private const val MAX_ITEMS = 300

    val CATEGORIES = listOf("个人信息", "偏好", "工作学习", "人际关系", "计划待办", "其他")

    @Volatile
    private var file: File? = null
    private val lock = Any()

    private val _items = MutableStateFlow<List<MemoryItem>>(emptyList())
    val items: StateFlow<List<MemoryItem>> = _items.asStateFlow()

    fun init(context: Context) {
        if (file != null) return
        val f = File(context.applicationContext.filesDir, FILE_NAME)
        file = f
        _items.value = load(f)
    }

    private fun load(f: File): List<MemoryItem> {
        if (!f.exists()) return emptyList()
        return try {
            val arr = JSONArray(f.readText())
            (0 until arr.length()).mapNotNull { i ->
                val o = arr.optJSONObject(i) ?: return@mapNotNull null
                val content = o.optString("content").trim()
                if (content.isEmpty()) return@mapNotNull null
                MemoryItem(
                    id = o.optString("id").ifEmpty { UUID.randomUUID().toString() },
                    content = content,
                    category = o.optString("category").ifEmpty { "其他" },
                    source = o.optString("source").ifEmpty { "manual" },
                    pinned = o.optBoolean("pinned", false),
                    createdAt = o.optLong("createdAt", System.currentTimeMillis()),
                    updatedAt = o.optLong("updatedAt", System.currentTimeMillis()),
                    hits = o.optInt("hits", 0),
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "load failed", e)
            emptyList()
        }
    }

    private fun persist(list: List<MemoryItem>) {
        val f = file ?: return
        val arr = JSONArray()
        for (m in list) {
            arr.put(
                JSONObject()
                    .put("id", m.id)
                    .put("content", m.content)
                    .put("category", m.category)
                    .put("source", m.source)
                    .put("pinned", m.pinned)
                    .put("createdAt", m.createdAt)
                    .put("updatedAt", m.updatedAt)
                    .put("hits", m.hits)
            )
        }
        try {
            val tmp = File(f.parentFile, "$FILE_NAME.tmp")
            tmp.writeText(arr.toString())
            if (!tmp.renameTo(f)) {
                f.writeText(arr.toString())
                tmp.delete()
            }
        } catch (e: Exception) {
            Log.e(TAG, "persist failed", e)
        }
    }

    private fun update(block: (List<MemoryItem>) -> List<MemoryItem>) {
        synchronized(lock) {
            val next = block(_items.value)
            _items.value = next
            persist(next)
        }
    }

    /**
     * 新增一条记忆（自动去重）。
     * @return 新增或被更新的条目
     */
    fun add(content: String, category: String = "其他", source: String = "manual"): MemoryItem? {
        val text = content.trim().trimEnd('。', '.', '；', ';').trim()
        if (text.length < 2) return null
        var result: MemoryItem? = null
        update { list ->
            val dup = list.firstOrNull { MemoryText.similar(it.content, text) }
            if (dup != null) {
                // 内容更长 / 更新的覆盖旧的
                val merged = dup.copy(
                    content = if (text.length >= dup.content.length) text else dup.content,
                    category = if (category != "其他") category else dup.category,
                    updatedAt = System.currentTimeMillis(),
                )
                result = merged
                list.map { if (it.id == dup.id) merged else it }
            } else {
                val item = MemoryItem(content = text, category = normalizeCategory(category), source = source)
                result = item
                val next = listOf(item) + list
                if (next.size > MAX_ITEMS) {
                    // 优先淘汰：非置顶、自动提取、最久未更新
                    val removable = next.filter { !it.pinned }.sortedBy { it.updatedAt }
                    val drop = removable.take(next.size - MAX_ITEMS).map { it.id }.toSet()
                    next.filter { it.id !in drop }
                } else next
            }
        }
        return result
    }

    fun edit(id: String, content: String, category: String) {
        val text = content.trim()
        if (text.isEmpty()) { delete(id); return }
        update { list ->
            list.map {
                if (it.id == id) it.copy(content = text, category = normalizeCategory(category), updatedAt = System.currentTimeMillis())
                else it
            }
        }
    }

    fun togglePin(id: String) {
        update { list -> list.map { if (it.id == id) it.copy(pinned = !it.pinned) else it } }
    }

    fun delete(id: String) {
        update { list -> list.filter { it.id != id } }
    }

    /** 按关键词删除，返回删除条数。 */
    fun forget(keyword: String): Int {
        val k = keyword.trim()
        if (k.isEmpty()) return 0
        var removed = 0
        update { list ->
            val keep = list.filter { !it.content.contains(k, ignoreCase = true) }
            removed = list.size - keep.size
            keep
        }
        return removed
    }

    fun clear() {
        update { emptyList() }
    }

    /** 挑出与 [query] 最相关的若干条记忆。置顶的总会入选。 */
    fun relevant(query: String, limit: Int = 8, maxChars: Int = 700): List<MemoryItem> {
        val all = _items.value
        if (all.isEmpty()) return emptyList()
        val now = System.currentTimeMillis()
        val scored = all.map { m ->
            val overlap = MemoryText.overlapScore(query, m.content)
            val recency = 1.0 / (1.0 + (now - m.updatedAt) / (1000.0 * 60 * 60 * 24 * 7))
            val base = when {
                m.pinned -> 10.0
                m.category == "个人信息" -> 0.6
                m.category == "偏好" -> 0.4
                else -> 0.0
            }
            m to (base + overlap * 3.0 + recency * 0.5)
        }.sortedByDescending { it.second }

        val out = ArrayList<MemoryItem>()
        var chars = 0
        for ((m, score) in scored) {
            if (out.size >= limit) break
            if (score < 0.35 && out.size >= 3) break
            if (chars + m.content.length > maxChars) continue
            out.add(m)
            chars += m.content.length
        }
        return out
    }

    /** 记录这些记忆被使用了一次（影响排序）。 */
    fun markUsed(ids: Collection<String>) {
        if (ids.isEmpty()) return
        val set = ids.toSet()
        synchronized(lock) {
            val next = _items.value.map { if (it.id in set) it.copy(hits = it.hits + 1) else it }
            _items.value = next
            persist(next)
        }
    }

    private fun normalizeCategory(c: String): String {
        val t = c.trim()
        return CATEGORIES.firstOrNull { it == t } ?: when {
            t.contains("偏好") || t.contains("喜好") || t.contains("习惯") -> "偏好"
            t.contains("个人") || t.contains("身份") || t.contains("基本") -> "个人信息"
            t.contains("工作") || t.contains("学习") || t.contains("职业") -> "工作学习"
            t.contains("关系") || t.contains("家人") || t.contains("朋友") -> "人际关系"
            t.contains("计划") || t.contains("待办") || t.contains("日程") -> "计划待办"
            else -> "其他"
        }
    }
}

/** 记忆文本相似度工具（纯 Kotlin，便于单元测试）。 */
object MemoryText {

    /** 中文按「双字」切分，英文按单词切分。 */
    fun tokens(s: String): Set<String> {
        val out = HashSet<String>()
        val lower = s.lowercase()
        val word = StringBuilder()
        var prevCjk: Char? = null
        for (ch in lower) {
            val isCjk = ch.code in 0x4E00..0x9FFF
            if (isCjk) {
                if (word.isNotEmpty()) { if (word.length > 1) out.add(word.toString()); word.setLength(0) }
                val p = prevCjk
                if (p != null) out.add("$p$ch")
                out.add(ch.toString())
                prevCjk = ch
            } else {
                prevCjk = null
                if (ch.isLetterOrDigit()) word.append(ch) else {
                    if (word.length > 1) out.add(word.toString())
                    word.setLength(0)
                }
            }
        }
        if (word.length > 1) out.add(word.toString())
        return out
    }

    private val STOP = setOf("我", "的", "是", "了", "在", "和", "也", "就", "都", "你", "他", "她", "吗", "呢", "啊", "吧", "有", "个", "这", "那", "不")

    /** 0..1，查询与记忆的重合度（只看双字词和英文词，单字权重低）。 */
    fun overlapScore(query: String, memory: String): Double {
        val q = tokens(query).filter { it !in STOP }
        if (q.isEmpty()) return 0.0
        val m = tokens(memory)
        var hit = 0.0
        var total = 0.0
        for (t in q) {
            val w = if (t.length >= 2) 1.0 else 0.25
            total += w
            if (t in m) hit += w
        }
        return if (total == 0.0) 0.0 else hit / total
    }

    /** 判断两条记忆是否基本是同一件事。 */
    fun similar(a: String, b: String): Boolean {
        val x = a.trim()
        val y = b.trim()
        if (x == y) return true
        if (x.length >= 4 && y.length >= 4 && (x.contains(y) || y.contains(x))) return true
        val ta = tokens(x).filter { it.length >= 2 }.toSet()
        val tb = tokens(y).filter { it.length >= 2 }.toSet()
        if (ta.isEmpty() || tb.isEmpty()) return false
        val inter = ta.intersect(tb).size.toDouble()
        val union = ta.union(tb).size.toDouble()
        return inter / union >= 0.72
    }
}
