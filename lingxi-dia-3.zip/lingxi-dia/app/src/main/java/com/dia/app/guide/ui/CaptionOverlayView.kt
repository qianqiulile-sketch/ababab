package com.dia.app.guide.ui

import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Caption bubble shown above / below the highlighted target. Layout:
 *
 *   [GOAL]  "How do I send a photo to my granddaughter?"          [×]
 *   STEP 3  Tap the camera button at the top
 *   [◀]                       [↻]                       [✏]   [▶]
 *
 * The "GOAL" banner is fixed at the top so older users don't lose context
 * after a few steps. Caption controls are 56dp (WCAG-compliant touch
 * targets). Big-text and high-contrast modes scale the entire bubble.
 */
class CaptionOverlayView(
    context: Context,
    private val bigText: Boolean = false,
    private val highContrast: Boolean = false,
) : FrameLayout(context) {

    interface Listener {
        fun onNext()
        fun onPrevious()
        fun onClose()
        fun onReplay()
        fun onTranslate()
    }

    var listener: Listener? = null

    private val goalText: TextView
    private val stepPill: TextView
    private val captionText: TextView
    private val prevBtn: ImageButton
    private val nextBtn: ImageButton
    private val closeBtn: ImageButton
    private val replayBtn: ImageButton

    /** Font scale: 1.5× when big-text mode is on. */
    private val scale: Float = if (bigText) 1.5f else 1.0f

    /** Caption-to-canvas color contrast — punchier in high-contrast mode. */
    private val bubbleStartColor = if (highContrast) 0xFF000000.toInt() else 0xF0121220.toInt()
    private val bubbleEndColor = if (highContrast) 0xFF000000.toInt() else 0xE0171724.toInt()
    private val bubbleStrokeColor = if (highContrast) 0xFFFFD600.toInt() else 0x3300E676
    private val accentColor = if (highContrast) 0xFFFFD600.toInt() else 0xFF00E676.toInt()
    private val captionColor = if (highContrast) 0xFFFFFFFF.toInt() else 0xFFF0F0F5.toInt()

    init {
        val bubble = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(bubbleStartColor, bubbleEndColor)
            ).apply {
                cornerRadius = dp(18).toFloat()
                setStroke(dp(if (highContrast) 2 else 1), bubbleStrokeColor)
            }
            elevation = dp(10).toFloat()
        }

        // Row 0 — goal banner (fixed reminder of what the user asked for)
        val row0 = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, dp(8))
        }
        val goalPill = TextView(context).apply {
            text = "目标"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 9f * scale)
            setTextColor(accentColor)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            background = GradientDrawable().apply {
                cornerRadius = dp(8).toFloat()
                setStroke(dp(1), accentColor and 0x66FFFFFF.toInt())
                setColor(accentColor and 0x33FFFFFF.toInt())
            }
            setPadding(dp(7), dp(3), dp(7), dp(3))
        }
        row0.addView(goalPill)

        goalText = TextView(context).apply {
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f * scale)
            setTextColor(captionColor and 0x99FFFFFF.toInt())
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            maxWidth = dp(if (bigText) 320 else 260)
            setPadding(dp(8), 0, 0, 0)
            setLineSpacing(0f, 1.05f)
            isSingleLine = false
            maxLines = 2
            ellipsize = android.text.TextUtils.TruncateAt.END
            visibility = View.GONE // hidden until bind() supplies a goal
        }
        row0.addView(
            goalText,
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        )
        bubble.addView(row0)

        // Row 1 — step pill + caption + close
        val row1 = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        stepPill = TextView(context).apply {
            text = "第 1 步"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f * scale)
            setTextColor(accentColor)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            background = GradientDrawable().apply {
                cornerRadius = dp(10).toFloat()
                setStroke(dp(1), accentColor and 0x66FFFFFF.toInt())
                setColor(accentColor and 0x22FFFFFF.toInt())
            }
            setPadding(dp(8), dp(4), dp(8), dp(4))
        }
        row1.addView(stepPill)

        captionText = TextView(context).apply {
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14.5f * scale)
            setTextColor(captionColor)
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            maxWidth = dp(if (bigText) 320 else 260)
            setPadding(dp(10), 0, dp(10), 0)
            setLineSpacing(0f, 1.15f)
        }
        row1.addView(
            captionText,
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        )

        closeBtn = iconButton(context, android.R.drawable.ic_menu_close_clear_cancel) { listener?.onClose() }
        row1.addView(closeBtn)
        bubble.addView(row1)

        // Row 2 — nav controls
        val row2 = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(10), 0, 0)
        }
        prevBtn = iconButton(context, android.R.drawable.ic_media_previous) { listener?.onPrevious() }
        replayBtn = iconButton(context, android.R.drawable.ic_menu_rotate) { listener?.onReplay() }
        nextBtn = iconButton(context, android.R.drawable.ic_media_next) { listener?.onNext() }
        val translateBtn = iconButton(context, android.R.drawable.ic_menu_edit) { listener?.onTranslate() }
        translateBtn.setColorFilter(0xFF66BB6A.toInt())
        row2.addView(prevBtn)
        row2.addView(View(context), LinearLayout.LayoutParams(0, 0, 1f))
        row2.addView(replayBtn)
        row2.addView(View(context), LinearLayout.LayoutParams(0, 0, 1f))
        row2.addView(translateBtn)
        row2.addView(View(context), LinearLayout.LayoutParams(0, 0, 1f))
        row2.addView(nextBtn)
        bubble.addView(row2, LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))

        addView(bubble, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, Gravity.CENTER))
    }

    fun bind(step: Int, total: Int, caption: String, goal: String? = null) {
        if (goal.isNullOrBlank()) {
            goalText.visibility = View.GONE
        } else {
            goalText.visibility = View.VISIBLE
            goalText.text = goal
            goalText.contentDescription = "目标：$goal"
        }
        stepPill.text = if (total > 1) "第 $step / $total 步" else "第 $step 步"
        stepPill.visibility = View.VISIBLE
        captionText.text = caption
        captionText.contentDescription = "第 $step 步。$caption"
    }

    private fun iconButton(context: Context, res: Int, onClick: () -> Unit): ImageButton {
        return ImageButton(context).apply {
            setImageResource(res)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(if (highContrast) 0x44FFFFFF else 0x1AFFFFFF)
                setStroke(dp(1), if (highContrast) 0xFFFFFFFF.toInt() else 0x33FFFFFF)
            }
            setColorFilter(captionColor)
            // WCAG-compliant 48dp minimum, 56dp when big-text mode is on.
            val s = dp(if (bigText) 56 else 48)
            layoutParams = LinearLayout.LayoutParams(s, s)
            val pad = dp(if (bigText) 12 else 10)
            setPadding(pad, pad, pad, pad)
            setOnClickListener { onClick() }
        }
    }

    private fun dp(v: Int): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), context.resources.displayMetrics).toInt()
}
